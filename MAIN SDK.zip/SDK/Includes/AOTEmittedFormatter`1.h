#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AOTEmittedFormatter$1 : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AOTEmittedFormatter`1", BNM::Image("Sirenix.Serialization.dll"));
		}
		
		
		
	};
}
