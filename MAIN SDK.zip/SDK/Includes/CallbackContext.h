#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CallbackContext
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CallbackContext", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* m_State;
		int m_ActionIndex;
		
		
	};
}
