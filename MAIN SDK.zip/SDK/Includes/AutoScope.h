#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AutoScope
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AutoScope", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		BNM::Types::nuint m_Ptr;
		
		
	};
}
