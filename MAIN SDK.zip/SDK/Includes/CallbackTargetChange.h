#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CallbackTargetChange
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CallbackTargetChange", BNM::Image("PhotonUnityNetworking.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* obj;
		BNM::MonoType* type;
		bool $add;
		
		
	};
}
