#pragma once
#include <BNMIncludes.hpp>

#undef CacheResult
#undef EvaluateOnEveryRead
namespace GlobalNamespace {
	enum class CachingPolicy : int
	{
		CacheResult = 0,
		EvaluateOnEveryRead = 1
	};
}
