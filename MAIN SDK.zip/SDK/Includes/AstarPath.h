#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AstarPath : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AstarPath", BNM::Image("AstarPathfindingProject.dll"));
		}
		
		/* @brief Orig Type: System.Version */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T Version() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Version");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Version */
		static void set_Version(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Version");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: AstarPath/AstarDistribution */
		template <typename T = int> static T Distribution() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Distribution");
			return __bnm__field__();
		}
		/* @param value Orig Type: AstarPath/AstarDistribution */
		static void set_Distribution(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("Distribution");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T Branch() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Branch");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_Branch(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Branch");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.AstarData */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T data() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("data");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.AstarData */
		void set_data(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("data");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: AstarPath */
		template <typename T = GlobalNamespace::AstarPath*> static T active() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("active");
			return __bnm__field__();
		}
		/* @param value Orig Type: AstarPath */
		static void set_active(GlobalNamespace::AstarPath* value) {
			static BNM::Field<GlobalNamespace::AstarPath*> __bnm__field__ = StaticClass().GetField("active");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T showNavGraphs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("showNavGraphs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_showNavGraphs(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("showNavGraphs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T showUnwalkableNodes() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("showUnwalkableNodes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_showUnwalkableNodes(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("showUnwalkableNodes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.GraphDebugMode */
		template <typename T = int> T debugMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("debugMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.GraphDebugMode */
		void set_debugMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("debugMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T debugFloor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("debugFloor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_debugFloor(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("debugFloor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T debugRoof() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("debugRoof");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_debugRoof(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("debugRoof");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T manualDebugFloorRoof() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("manualDebugFloorRoof");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_manualDebugFloorRoof(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("manualDebugFloorRoof");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T showSearchTree() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("showSearchTree");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_showSearchTree(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("showSearchTree");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T unwalkableNodeDebugSize() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("unwalkableNodeDebugSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_unwalkableNodeDebugSize(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("unwalkableNodeDebugSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.PathLog */
		template <typename T = int> T logPathResults() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("logPathResults");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.PathLog */
		void set_logPathResults(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("logPathResults");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T maxNearestNodeDistance() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("maxNearestNodeDistance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_maxNearestNodeDistance(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("maxNearestNodeDistance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T scanOnStartup() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("scanOnStartup");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_scanOnStartup(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("scanOnStartup");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T fullGetNearestSearch() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("fullGetNearestSearch");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_fullGetNearestSearch(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("fullGetNearestSearch");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T prioritizeGraphs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("prioritizeGraphs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_prioritizeGraphs(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("prioritizeGraphs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T prioritizeGraphsLimit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("prioritizeGraphsLimit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_prioritizeGraphsLimit(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("prioritizeGraphsLimit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.AstarColor */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T colorSettings() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("colorSettings");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.AstarColor */
		void set_colorSettings(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("colorSettings");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T tagNames() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("tagNames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String[] */
		void set_tagNames(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("tagNames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.Heuristic */
		template <typename T = int> T heuristic() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("heuristic");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.Heuristic */
		void set_heuristic(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("heuristic");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T heuristicScale() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("heuristicScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_heuristicScale(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("heuristicScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.ThreadCount */
		template <typename T = int> T threadCount() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("threadCount");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.ThreadCount */
		void set_threadCount(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("threadCount");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T maxFrameTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("maxFrameTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_maxFrameTime(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("maxFrameTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T batchGraphUpdates() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("batchGraphUpdates");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_batchGraphUpdates(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("batchGraphUpdates");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T graphUpdateBatchingInterval() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("graphUpdateBatchingInterval");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_graphUpdateBatchingInterval(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("graphUpdateBatchingInterval");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T $lastScanTime$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$lastScanTime$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_$lastScanTime$(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("$lastScanTime$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.PathHandler */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T debugPathData() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("debugPathData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.PathHandler */
		void set_debugPathData(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("debugPathData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.UInt16 */
		template <typename T = BNM::Types::ushort> T debugPathID() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("debugPathID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.UInt16 */
		void set_debugPathID(BNM::Types::ushort value) {
			static BNM::Field<BNM::Types::ushort> __bnm__field__ = StaticClass().GetField("debugPathID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T inGameDebugPath() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("inGameDebugPath");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_inGameDebugPath(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("inGameDebugPath");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T isScanningBacking() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isScanningBacking");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_isScanningBacking(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("isScanningBacking");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnAwakeSettings() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnAwakeSettings");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action */
		static void set_OnAwakeSettings(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnAwakeSettings");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.OnGraphDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnGraphPreScan() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnGraphPreScan");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.OnGraphDelegate */
		static void set_OnGraphPreScan(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnGraphPreScan");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.OnGraphDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnGraphPostScan() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnGraphPostScan");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.OnGraphDelegate */
		static void set_OnGraphPostScan(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnGraphPostScan");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.OnPathDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnPathPreSearch() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnPathPreSearch");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.OnPathDelegate */
		static void set_OnPathPreSearch(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnPathPreSearch");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.OnPathDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnPathPostSearch() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnPathPostSearch");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.OnPathDelegate */
		static void set_OnPathPostSearch(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnPathPostSearch");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.OnScanDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnPreScan() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnPreScan");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.OnScanDelegate */
		static void set_OnPreScan(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnPreScan");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.OnScanDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnPostScan() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnPostScan");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.OnScanDelegate */
		static void set_OnPostScan(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnPostScan");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.OnScanDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnLatePostScan() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnLatePostScan");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.OnScanDelegate */
		static void set_OnLatePostScan(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnLatePostScan");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.OnScanDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnGraphsUpdated() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnGraphsUpdated");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.OnScanDelegate */
		static void set_OnGraphsUpdated(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnGraphsUpdated");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T On65KOverflow() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("On65KOverflow");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action */
		static void set_On65KOverflow(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("On65KOverflow");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T OnGraphsWillBeUpdated() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnGraphsWillBeUpdated");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action */
		void set_OnGraphsWillBeUpdated(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnGraphsWillBeUpdated");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T OnGraphsWillBeUpdated2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnGraphsWillBeUpdated2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action */
		void set_OnGraphsWillBeUpdated2(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnGraphsWillBeUpdated2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.GraphUpdateProcessor */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T graphUpdates() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("graphUpdates");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.GraphUpdateProcessor */
		void set_graphUpdates(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("graphUpdates");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.HierarchicalGraph */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T hierarchicalGraph() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("hierarchicalGraph");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.HierarchicalGraph */
		void set_hierarchicalGraph(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("hierarchicalGraph");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.NavmeshUpdates */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T navmeshUpdates() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("navmeshUpdates");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.NavmeshUpdates */
		void set_navmeshUpdates(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("navmeshUpdates");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.WorkItemProcessor */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T workItems() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("workItems");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.WorkItemProcessor */
		void set_workItems(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("workItems");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.PathProcessor */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T pathProcessor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("pathProcessor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.PathProcessor */
		void set_pathProcessor(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("pathProcessor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T graphUpdateRoutineRunning() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("graphUpdateRoutineRunning");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_graphUpdateRoutineRunning(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("graphUpdateRoutineRunning");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T graphUpdatesWorkItemAdded() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("graphUpdatesWorkItemAdded");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_graphUpdatesWorkItemAdded(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("graphUpdatesWorkItemAdded");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T lastGraphUpdate() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lastGraphUpdate");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_lastGraphUpdate(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("lastGraphUpdate");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.PathProcessor/GraphUpdateLock */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T workItemLock() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("workItemLock");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.PathProcessor/GraphUpdateLock */
		void set_workItemLock(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("workItemLock");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.PathReturnQueue */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T pathReturnQueue() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("pathReturnQueue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.PathReturnQueue */
		void set_pathReturnQueue(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("pathReturnQueue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.EuclideanEmbedding */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T euclideanEmbedding() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("euclideanEmbedding");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.EuclideanEmbedding */
		void set_euclideanEmbedding(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("euclideanEmbedding");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T showGraphs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("showGraphs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_showGraphs(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("showGraphs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.UInt16 */
		template <typename T = BNM::Types::ushort> T nextFreePathID() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("nextFreePathID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.UInt16 */
		void set_nextFreePathID(BNM::Types::ushort value) {
			static BNM::Field<BNM::Types::ushort> __bnm__field__ = StaticClass().GetField("nextFreePathID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.Util.RetainedGizmos */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T gizmos() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("gizmos");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.Util.RetainedGizmos */
		void set_gizmos(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("gizmos");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T waitForPathDepth() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("waitForPathDepth");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_waitForPathDepth(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("waitForPathDepth");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Pathfinding.NNConstraint */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T NNConstraintNone() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("NNConstraintNone");
			return __bnm__field__();
		}
		/* @param value Orig Type: Pathfinding.NNConstraint */
		static void set_NNConstraintNone(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("NNConstraintNone");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Type[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T get_graphTypes() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_graphTypes", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: Pathfinding.AstarData */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_astarData() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_astarData", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: Pathfinding.NavGraph[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T get_graphs() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_graphs", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T get_maxNearestNodeDistanceSqr() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_maxNearestNodeDistanceSqr", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_limitGraphUpdates() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_limitGraphUpdates", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_limitGraphUpdates(bool $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_limitGraphUpdates", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T get_maxGraphUpdateFreq() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_maxGraphUpdateFreq", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_maxGraphUpdateFreq(float $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_maxGraphUpdateFreq", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T get_lastScanTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_lastScanTime", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_lastScanTime(float $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_lastScanTime", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_isScanning() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_isScanning", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_isScanning(bool $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_isScanning", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T get_NumParallelThreads() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NumParallelThreads", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsUsingMultithreading() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsUsingMultithreading", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsAnyGraphUpdatesQueued() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsAnyGraphUpdatesQueued", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsAnyGraphUpdateQueued() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsAnyGraphUpdateQueued", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsAnyGraphUpdateInProgress() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsAnyGraphUpdateInProgress", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsAnyWorkItemInProgress() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsAnyWorkItemInProgress", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsInsideWorkItem() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsInsideWorkItem", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.String[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T GetTagNames() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetTagNames", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T FindAstarPath() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FindAstarPath", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.String[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T FindTagNames() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FindTagNames", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.UInt16 */
		template <typename T = BNM::Types::ushort> T GetNextPathID() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetNextPathID", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T RecalculateDebugLimits() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RecalculateDebugLimits", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDrawGizmos() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDrawGizmos", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnGUI() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnGUI", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T LogPathResults(BNM::IL2CPP::Il2CppObject* path) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LogPathResults", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](path);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PerformBlockingActions(bool force) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PerformBlockingActions", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](force);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T QueueWorkItemFloodFill() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("QueueWorkItemFloodFill", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EnsureValidFloodFill() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnsureValidFloodFill", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AddWorkItem(BNM::IL2CPP::Il2CppObject* callback) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddWorkItem", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](callback);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AddWorkItem_1(void* /*GENERICTYPE*/ callback) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddWorkItem", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](callback);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AddWorkItem_2(BNM::IL2CPP::Il2CppObject* item) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddWorkItem", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](item);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T QueueGraphUpdates() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("QueueGraphUpdates", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Collections.IEnumerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T DelayedGraphUpdate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DelayedGraphUpdate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateGraphs(BNM::IL2CPP::Il2CppObject* bounds, float delay) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateGraphs", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](bounds, delay);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateGraphs_1(BNM::IL2CPP::Il2CppObject* ob, float delay) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateGraphs", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](ob, delay);
		}
		/* @brief Orig Type: System.Collections.IEnumerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T UpdateGraphsInternal(BNM::IL2CPP::Il2CppObject* ob, float delay) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateGraphsInternal", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](ob, delay);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateGraphs_2(BNM::IL2CPP::Il2CppObject* bounds) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateGraphs", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](bounds);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateGraphs_3(BNM::IL2CPP::Il2CppObject* ob) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateGraphs", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](ob);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FlushGraphUpdates() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FlushGraphUpdates", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FlushWorkItems() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FlushWorkItems", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FlushWorkItems_1(bool unblockOnComplete, bool block) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FlushWorkItems", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](unblockOnComplete, block);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FlushThreadSafeCallbacks() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FlushThreadSafeCallbacks", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T CalculateThreadCount(int count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CalculateThreadCount", 1);
			return __bnm__method__(count);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Awake() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Awake", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T InitializePathProcessor() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("InitializePathProcessor", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T VerifyIntegrity() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("VerifyIntegrity", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ConfigureReferencesInternal() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ConfigureReferencesInternal", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T InitializeProfiler() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("InitializeProfiler", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T InitializeAstarData() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("InitializeAstarData", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDisable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDestroy() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDestroy", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FloodFill(BNM::IL2CPP::Il2CppObject* seed) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FloodFill", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](seed);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FloodFill_1(BNM::IL2CPP::Il2CppObject* seed, BNM::Types::uint area) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FloodFill", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](seed, area);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FloodFill_2() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FloodFill", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T GetNewNodeIndex() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetNewNodeIndex", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T InitializeNode(BNM::IL2CPP::Il2CppObject* node) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("InitializeNode", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](node);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T DestroyNode(BNM::IL2CPP::Il2CppObject* node) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DestroyNode", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](node);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T BlockUntilPathQueueBlocked() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BlockUntilPathQueueBlocked", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: Pathfinding.PathProcessor/GraphUpdateLock */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T PausePathfinding() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PausePathfinding", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: Pathfinding.PathProcessor/GraphUpdateLock */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T PausePathfindingSoon() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PausePathfindingSoon", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Scan(BNM::IL2CPP::Il2CppObject* graphToScan) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Scan", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](graphToScan);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Scan_1(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* graphsToScan) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Scan", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](graphsToScan);
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Pathfinding.Progress> */
		template <typename T = void* /*GENERICTYPE*/> T ScanAsync(BNM::IL2CPP::Il2CppObject* graphToScan) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ScanAsync", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](graphToScan);
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Pathfinding.Progress> */
		template <typename T = void* /*GENERICTYPE*/> T ScanAsync_1(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* graphsToScan) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ScanAsync", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](graphsToScan);
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Pathfinding.Progress> */
		template <typename T = void* /*GENERICTYPE*/> T ScanGraph(BNM::IL2CPP::Il2CppObject* graph) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ScanGraph", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](graph);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T WaitForPath(BNM::IL2CPP::Il2CppObject* path) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WaitForPath", 1);
			return __bnm__method__(path);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T BlockUntilCalculated(BNM::IL2CPP::Il2CppObject* path) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BlockUntilCalculated", 1);
			return __bnm__method__(path);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T RegisterSafeUpdate(BNM::IL2CPP::Il2CppObject* callback) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RegisterSafeUpdate", 1);
			return __bnm__method__(callback);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T StartPath(BNM::IL2CPP::Il2CppObject* path, bool pushToFront) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StartPath", 2);
			return __bnm__method__(path, pushToFront);
		}
		/* @brief Orig Type: Pathfinding.NNInfo */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetNearest(BNM::Structures::Unity::Vector3 position) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetNearest", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](position);
		}
		/* @brief Orig Type: Pathfinding.NNInfo */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetNearest_1(BNM::Structures::Unity::Vector3 position, BNM::IL2CPP::Il2CppObject* constraint) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetNearest", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](position, constraint);
		}
		/* @brief Orig Type: Pathfinding.NNInfo */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetNearest_2(BNM::Structures::Unity::Vector3 position, BNM::IL2CPP::Il2CppObject* constraint, BNM::IL2CPP::Il2CppObject* hint) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetNearest", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](position, constraint, hint);
		}
		/* @brief Orig Type: Pathfinding.GraphNode */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetNearest_3(BNM::Structures::Unity::Ray ray) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetNearest", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](ray);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T _ctorb__92_0() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("<.ctor>b__92_0", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T InitializePathProcessorb__122_1(BNM::IL2CPP::Il2CppObject* path) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("<InitializePathProcessor>b__122_1", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](path);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T InitializePathProcessorb__122_2() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("<InitializePathProcessor>b__122_2", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
