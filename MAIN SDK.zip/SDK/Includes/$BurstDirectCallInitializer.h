#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class $BurstDirectCallInitializer

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "$BurstDirectCallInitializer", BNM::Image("Unity.XR.Interaction.Toolkit.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Initialize() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 0);
			return __bnm__method__();
		}
		
	};
}
