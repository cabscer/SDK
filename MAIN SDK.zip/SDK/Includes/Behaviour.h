#pragma once
#include <BNMIncludes.hpp>

#undef RelativePositionWithStaticOrigin
#undef ExactPositionWithStaticOrigin
#undef ExactPositionWithDynamicOrigin
namespace GlobalNamespace {
	enum class Behaviour : int
	{
		RelativePositionWithStaticOrigin = 0,
		ExactPositionWithStaticOrigin = 1,
		ExactPositionWithDynamicOrigin = 2
	};
}
