#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BananaOSMenuButton : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BananaOSMenuButton", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.GameObject> */
		template <typename T = void* /*GENERICTYPE*/> T ObjectsToDisable() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ObjectsToDisable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.GameObject> */
		void set_ObjectsToDisable(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("ObjectsToDisable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.GameObject> */
		template <typename T = void* /*GENERICTYPE*/> T ObjectsToEnable() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ObjectsToEnable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.GameObject> */
		void set_ObjectsToEnable(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("ObjectsToEnable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T buttonFadeTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("buttonFadeTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_buttonFadeTime(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("buttonFadeTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ButtonActivation() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ButtonActivation", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Collections.IEnumerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ButtonColorUpdate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ButtonColorUpdate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
