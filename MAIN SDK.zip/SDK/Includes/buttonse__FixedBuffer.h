#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $buttons$e__FixedBuffer
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "<buttons>e__FixedBuffer", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::Types::uint FixedElementField;
		
		
	};
}
