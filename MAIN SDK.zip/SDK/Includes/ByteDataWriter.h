#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ByteDataWriter : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ByteDataWriter", BNM::Image("Meta.WitAi.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Invoke(void* buffer, int offset, int length) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](buffer, offset, length);
		}
		/* @brief Orig Type: System.IAsyncResult */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T BeginInvoke(void* buffer, int offset, int length, BNM::IL2CPP::Il2CppObject* callback, BNM::IL2CPP::Il2CppObject* $object) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BeginInvoke", 5);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](buffer, offset, length, callback, $object);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EndInvoke(BNM::IL2CPP::Il2CppObject* result) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EndInvoke", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](result);
		}
		
	};
}
