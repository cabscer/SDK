#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef PrimaryAxis2D
#undef SecondaryAxis2D
namespace GlobalNamespace {
	enum class Axis2D : int
	{
		None = 0,
		PrimaryAxis2D = 1,
		SecondaryAxis2D = 2
	};
}
