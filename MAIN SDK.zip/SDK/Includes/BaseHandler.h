#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BaseHandler : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BaseHandler", BNM::Image("Assembly-CSharp.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T IsReadyHandler(int code, BNM::Structures::Mono::String* message) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsReadyHandler", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](code, message);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T StartHandler(int code, BNM::Structures::Mono::String* message) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StartHandler", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](code, message);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T StopHandler(int code, BNM::Structures::Mono::String* message) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StopHandler", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](code, message);
		}
		
	};
}
