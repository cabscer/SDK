#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BodyJointLocation
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BodyJointLocation", BNM::Image("Oculus.VR.dll"));
		}
		
		BNM::Types::ulong LocationFlags;
		BNM::IL2CPP::Il2CppObject* Pose;
		
		
	};
}
