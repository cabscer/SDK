#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CallbackWithState$1
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CallbackWithState`1", BNM::Image("Oculus.VR.dll"));
		}
		
		static void* /*GENERICTYPE*/ Callbacks;
		void* _data;
		void* /*GENERICTYPE*/ _delegate;
		static void* /*GENERICTYPE*/ Invoker;
		static void* /*GENERICTYPE*/ Remover;
		static BNM::IL2CPP::Il2CppObject* Clearer;
		
		
	};
}
