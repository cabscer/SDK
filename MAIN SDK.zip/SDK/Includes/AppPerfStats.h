#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AppPerfStats
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AppPerfStats", BNM::Image("Oculus.VR.dll"));
		}
		
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* FrameStats;
		int FrameStatsCount;
		int AnyFrameStatsDropped;
		float AdaptiveGpuPerformanceScale;
		
		
	};
}
