#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ActivationStep : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ActivationStep", BNM::Image("Oculus.Interaction.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.Object */
		template <typename T = BNM::UnityEngine::Object*> T _activeState() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_activeState");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Object */
		void set__activeState(BNM::UnityEngine::Object* value) {
			static BNM::Field<BNM::UnityEngine::Object*> __bnm__field__ = StaticClass().GetField("_activeState");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Oculus.Interaction.IActiveState */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $ActiveState$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$ActiveState$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Oculus.Interaction.IActiveState */
		void set_$ActiveState$(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$ActiveState$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T _minActiveTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_minActiveTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set__minActiveTime(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("_minActiveTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T _maxStepTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_maxStepTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set__maxStepTime(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("_maxStepTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: Oculus.Interaction.IActiveState */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_ActiveState() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ActiveState", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_ActiveState(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ActiveState", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T get_MinActiveTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MinActiveTime", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T get_MaxStepTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaxStepTime", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
