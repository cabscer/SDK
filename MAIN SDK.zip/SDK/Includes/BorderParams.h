#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BorderParams
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BorderParams", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		BNM::Structures::Unity::Rect rect;
		BNM::Structures::Unity::Color playmodeTintColor;
		BNM::Structures::Unity::Color leftColor;
		BNM::Structures::Unity::Color topColor;
		BNM::Structures::Unity::Color rightColor;
		BNM::Structures::Unity::Color bottomColor;
		float leftWidth;
		float topWidth;
		float rightWidth;
		float bottomWidth;
		BNM::Structures::Unity::Vector2 topLeftRadius;
		BNM::Structures::Unity::Vector2 topRightRadius;
		BNM::Structures::Unity::Vector2 bottomRightRadius;
		BNM::Structures::Unity::Vector2 bottomLeftRadius;
		BNM::IL2CPP::Il2CppObject* material;
		BNM::IL2CPP::Il2CppObject* leftColorPage;
		BNM::IL2CPP::Il2CppObject* topColorPage;
		BNM::IL2CPP::Il2CppObject* rightColorPage;
		BNM::IL2CPP::Il2CppObject* bottomColorPage;
		
		
	};
}
