#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AttributeOverride
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AttributeOverride", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		BNM::Structures::Mono::String* m_ElementName;
		BNM::Structures::Mono::String* m_AttributeName;
		BNM::Structures::Mono::String* m_Value;
		
		
	};
}
