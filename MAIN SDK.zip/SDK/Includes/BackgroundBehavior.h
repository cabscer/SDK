#pragma once
#include <BNMIncludes.hpp>

#undef ResetAndDisableNonBackgroundDevices
#undef ResetAndDisableAllDevices
#undef IgnoreFocus
namespace GlobalNamespace {
	enum class BackgroundBehavior : int
	{
		ResetAndDisableNonBackgroundDevices = 0,
		ResetAndDisableAllDevices = 1,
		IgnoreFocus = 2
	};
}
