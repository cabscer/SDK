#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BalloonDynamics : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BalloonDynamics", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.Rigidbody */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T rb() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rb");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Rigidbody */
		void set_rb(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("rb");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Collider */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T balloonCollider() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("balloonCollider");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Collider */
		void set_balloonCollider(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("balloonCollider");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Bounds */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T bounds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Bounds */
		void set_bounds(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("bounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T bouyancyForce() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bouyancyForce");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_bouyancyForce(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("bouyancyForce");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T bouyancyMinHeight() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bouyancyMinHeight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_bouyancyMinHeight(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("bouyancyMinHeight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T bouyancyMaxHeight() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bouyancyMaxHeight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_bouyancyMaxHeight(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("bouyancyMaxHeight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T bouyancyActualHeight() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bouyancyActualHeight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_bouyancyActualHeight(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("bouyancyActualHeight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T varianceMaxheight() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("varianceMaxheight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_varianceMaxheight(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("varianceMaxheight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T airResistance() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("airResistance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_airResistance(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("airResistance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T knot() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("knot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject */
		void set_knot(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("knot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Rigidbody */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T knotRb() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("knotRb");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Rigidbody */
		void set_knotRb(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("knotRb");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T grabPt() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("grabPt");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_grabPt(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("grabPt");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T grabPtInitParent() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("grabPtInitParent");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_grabPtInitParent(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("grabPtInitParent");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T stringLength() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("stringLength");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_stringLength(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("stringLength");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T stringStrength() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("stringStrength");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_stringStrength(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("stringStrength");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T stringStretch() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("stringStretch");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_stringStretch(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("stringStretch");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T maximumVelocity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("maximumVelocity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_maximumVelocity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("maximumVelocity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T upRightTorque() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("upRightTorque");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_upRightTorque(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("upRightTorque");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T enableDynamics() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("enableDynamics");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_enableDynamics(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("enableDynamics");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T enableDistanceConstraints() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("enableDistanceConstraints");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_enableDistanceConstraints(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("enableDistanceConstraints");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_ColliderEnabled() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ColliderEnabled", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Awake() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Awake", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ReParent() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReParent", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ApplyBouyancyForce() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ApplyBouyancyForce", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ApplyUpRightForce() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ApplyUpRightForce", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ApplyAirResistance() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ApplyAirResistance", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ApplyDistanceConstraint() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ApplyDistanceConstraint", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EnableDynamics(bool enable, bool kinematic) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableDynamics", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](enable, kinematic);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EnableDistanceConstraints(bool enable) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableDistanceConstraints", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](enable);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FixedUpdate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FixedUpdate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
