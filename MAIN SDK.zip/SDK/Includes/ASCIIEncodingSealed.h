#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ASCIIEncodingSealed : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ASCIIEncodingSealed", BNM::Image("mscorlib.dll"));
		}
		
		
		
	};
}
