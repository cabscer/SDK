#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Bubbling
namespace GlobalNamespace {
	enum class BubblerState : int
	{
		None = 1,
		Bubbling = 2
	};
}
