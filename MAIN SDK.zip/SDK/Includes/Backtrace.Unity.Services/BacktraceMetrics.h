#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Services {
			class BacktraceMetrics : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Services", "BacktraceMetrics", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Guid */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SessionId() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SessionId");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Guid */
				void set_SessionId(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("SessionId");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T DefaultSubmissionUrl() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultSubmissionUrl");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_DefaultSubmissionUrl(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("DefaultSubmissionUrl");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> static T DefaultTimeIntervalInMin() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultTimeIntervalInMin");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.UInt32 */
				static void set_DefaultTimeIntervalInMin(BNM::Types::uint value) {
					static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("DefaultTimeIntervalInMin");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> static T DefaultTimeIntervalInSec() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultTimeIntervalInSec");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.UInt32 */
				static void set_DefaultTimeIntervalInSec(BNM::Types::uint value) {
					static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("DefaultTimeIntervalInSec");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T DefaultUniqueAttributeName() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultUniqueAttributeName");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_DefaultUniqueAttributeName(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("DefaultUniqueAttributeName");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T $StartupUniqueAttributeName$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$StartupUniqueAttributeName$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_$StartupUniqueAttributeName$(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$StartupUniqueAttributeName$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T MaxTimeBetweenRequests() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxTimeBetweenRequests");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_MaxTimeBetweenRequests(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("MaxTimeBetweenRequests");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T MaxNumberOfAttempts() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxNumberOfAttempts");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_MaxNumberOfAttempts(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("MaxNumberOfAttempts");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T ApplicationSessionKey() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ApplicationSessionKey");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_ApplicationSessionKey(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ApplicationSessionKey");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Metrics.UniqueEventsSubmissionQueue */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _uniqueEventsSubmissionQueue() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_uniqueEventsSubmissionQueue");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.Metrics.UniqueEventsSubmissionQueue */
				void set__uniqueEventsSubmissionQueue(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_uniqueEventsSubmissionQueue");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Metrics.SummedEventsSubmissionQueue */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _summedEventsSubmissionQueue() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_summedEventsSubmissionQueue");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.Metrics.SummedEventsSubmissionQueue */
				void set__summedEventsSubmissionQueue(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_summedEventsSubmissionQueue");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T StartupEventName() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("StartupEventName");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_StartupEventName(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("StartupEventName");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T _timeIntervalInSec() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_timeIntervalInSec");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int64 */
				void set__timeIntervalInSec(int64_t value) {
					static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("_timeIntervalInSec");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Single */
				template <typename T = float> T _lastUpdateTime() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_lastUpdateTime");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Single */
				void set__lastUpdateTime(float value) {
					static BNM::Field<float> __bnm__field__ = StaticClass().GetField("_lastUpdateTime");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.JsonData.AttributeProvider */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _attributeProvider() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_attributeProvider");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.JsonData.AttributeProvider */
				void set__attributeProvider(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_attributeProvider");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Object */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _object() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_object");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Object */
				void set__object(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_object");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T _sessionId() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_sessionId");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set__sessionId(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_sessionId");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_StartupUniqueAttributeName() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_StartupUniqueAttributeName", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_StartupUniqueAttributeName(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_StartupUniqueAttributeName", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T get_MaximumUniqueEvents() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaximumUniqueEvents", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_MaximumUniqueEvents(BNM::Types::uint $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_MaximumUniqueEvents", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T get_MaximumSummedEvents() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaximumSummedEvents", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_MaximumSummedEvents(BNM::Types::uint $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_MaximumSummedEvents", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_UniqueEventsSubmissionUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_UniqueEventsSubmissionUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_UniqueEventsSubmissionUrl(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_UniqueEventsSubmissionUrl", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_SummedEventsSubmissionUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_SummedEventsSubmissionUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_SummedEventsSubmissionUrl(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_SummedEventsSubmissionUrl", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_IgnoreSslValidation(bool $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_IgnoreSslValidation", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Collections.Generic.LinkedList`1<Backtrace.Unity.Model.Metrics.UniqueEvent> */
				template <typename T = void* /*GENERICTYPE*/> T get_UniqueEvents() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_UniqueEvents", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Collections.Generic.LinkedList`1<Backtrace.Unity.Model.Metrics.SummedEvent> */
				template <typename T = void* /*GENERICTYPE*/> T get_SummedEvents() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_SummedEvents", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T OverrideHttpClient(BNM::IL2CPP::Il2CppObject* client) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OverrideHttpClient", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](client);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SendStartupEvent() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendStartupEvent", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Tick(float time) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Tick", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](time);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Send() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AddUniqueEvent(BNM::Structures::Mono::String* attributeName) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddUniqueEvent", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributeName);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AddUniqueEvent_1(BNM::Structures::Mono::String* attributeName, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddUniqueEvent", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributeName, attributes);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T Count() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Count", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AddSummedEvent(BNM::Structures::Mono::String* metricsGroupName) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddSummedEvent", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](metricsGroupName);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AddSummedEvent_1(BNM::Structures::Mono::String* metricsGroupName, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddSummedEvent", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](metricsGroupName, attributes);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SendPendingSubmissionJobs(float time) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendPendingSubmissionJobs", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](time);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GetDefaultUniqueEventsUrl(BNM::Structures::Mono::String* universeName, BNM::Structures::Mono::String* token) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetDefaultUniqueEventsUrl", 2);
					return __bnm__method__(universeName, token);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GetDefaultSummedEventsUrl(BNM::Structures::Mono::String* universeName, BNM::Structures::Mono::String* token) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetDefaultSummedEventsUrl", 2);
					return __bnm__method__(universeName, token);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GetDefaultSubmissionUrl(BNM::Structures::Mono::String* serviceName, BNM::Structures::Mono::String* universeName, BNM::Structures::Mono::String* token) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetDefaultSubmissionUrl", 3);
					return __bnm__method__(serviceName, universeName, token);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T GetAttributes(void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttributes", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
				}
				
			};
		}
	}
}
