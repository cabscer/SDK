#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Services {
			class BacktraceApi : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Services", "BacktraceApi", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceHttpClient */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _httpClient() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_httpClient");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.BacktraceHttpClient */
				void set__httpClient(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_httpClient");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Func`3<System.String,Backtrace.Unity.Model.BacktraceData,Backtrace.Unity.Model.BacktraceResult> */
				template <typename T = void* /*GENERICTYPE*/> T $RequestHandler$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$RequestHandler$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Func`3<System.String,Backtrace.Unity.Model.BacktraceData,Backtrace.Unity.Model.BacktraceResult> */
				void set_$RequestHandler$(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$RequestHandler$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T _shouldDisplayFailureMessage() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_shouldDisplayFailureMessage");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set__shouldDisplayFailureMessage(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_shouldDisplayFailureMessage");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Action`1<System.Exception> */
				template <typename T = void* /*GENERICTYPE*/> T $OnServerError$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$OnServerError$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Action`1<System.Exception> */
				void set_$OnServerError$(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$OnServerError$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Action`1<Backtrace.Unity.Model.BacktraceResult> */
				template <typename T = void* /*GENERICTYPE*/> T $OnServerResponse$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$OnServerResponse$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Action`1<Backtrace.Unity.Model.BacktraceResult> */
				void set_$OnServerResponse$(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$OnServerResponse$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Uri */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _serverUrl() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_serverUrl");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Uri */
				void set__serverUrl(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_serverUrl");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T $EnablePerformanceStatistics$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$EnablePerformanceStatistics$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_$EnablePerformanceStatistics$(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$EnablePerformanceStatistics$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T _minidumpUrl() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_minidumpUrl");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set__minidumpUrl(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_minidumpUrl");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceCredentials */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _credentials() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_credentials");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.BacktraceCredentials */
				void set__credentials(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_credentials");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Func`3<System.String,Backtrace.Unity.Model.BacktraceData,Backtrace.Unity.Model.BacktraceResult> */
				template <typename T = void* /*GENERICTYPE*/> T get_RequestHandler() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RequestHandler", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_RequestHandler(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_RequestHandler", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Action`1<System.Exception> */
				template <typename T = void* /*GENERICTYPE*/> T get_OnServerError() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_OnServerError", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_OnServerError(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_OnServerError", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Action`1<Backtrace.Unity.Model.BacktraceResult> */
				template <typename T = void* /*GENERICTYPE*/> T get_OnServerResponse() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_OnServerResponse", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_OnServerResponse(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_OnServerResponse", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T get_EnablePerformanceStatistics() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_EnablePerformanceStatistics", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_EnablePerformanceStatistics(bool $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_EnablePerformanceStatistics", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_ServerUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ServerUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Collections.IEnumerator */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SendMinidump(BNM::Structures::Mono::String* minidumpPath, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ attributes, void* /*GENERICTYPE*/ callback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendMinidump", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](minidumpPath, attachments, attributes, callback);
				}
				/* @brief Orig Type: System.Collections.IEnumerator */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Send(BNM::IL2CPP::Il2CppObject* data, void* /*GENERICTYPE*/ callback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data, callback);
				}
				/* @brief Orig Type: System.Collections.IEnumerator */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Send_1(BNM::Structures::Mono::String* json, void* /*GENERICTYPE*/ attachments, int deduplication, void* /*GENERICTYPE*/ callback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](json, attachments, deduplication, callback);
				}
				/* @brief Orig Type: System.Collections.IEnumerator */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Send_2(BNM::Structures::Mono::String* json, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ attributes, void* /*GENERICTYPE*/ callback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](json, attachments, attributes, callback);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T PrintLog(BNM::IL2CPP::Il2CppObject* request) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PrintLog", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](request);
				}
				
			};
		}
	}
}
