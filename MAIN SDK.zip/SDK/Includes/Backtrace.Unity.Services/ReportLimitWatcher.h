#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Services {
			class ReportLimitWatcher : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Services", "ReportLimitWatcher", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Collections.Generic.Queue`1<System.Int64> */
				template <typename T = void* /*GENERICTYPE*/> T _reportQueue() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_reportQueue");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.Queue`1<System.Int64> */
				void set__reportQueue(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_reportQueue");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Object */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _object() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_object");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Object */
				void set__object(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_object");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T _queueReportTime() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_queueReportTime");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int64 */
				void set__queueReportTime(int64_t value) {
					static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("_queueReportTime");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T _watcherEnable() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_watcherEnable");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set__watcherEnable(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_watcherEnable");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T _reportPerMin() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_reportPerMin");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set__reportPerMin(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_reportPerMin");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T _displayMessage() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_displayMessage");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set__displayMessage(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_displayMessage");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T _limitHit() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_limitHit");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set__limitHit(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_limitHit");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetClientReportLimit(BNM::Types::uint reportPerMin) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetClientReportLimit", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](reportPerMin);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T WatchReport(int64_t timestamp, bool displayMessageOnLimitHit) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WatchReport", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](timestamp, displayMessageOnLimitHit);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T WatchReport_1(BNM::IL2CPP::Il2CppObject* report, bool displayMessageOnLimitHit) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WatchReport", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report, displayMessageOnLimitHit);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ShouldDisplayMessage() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldDisplayMessage", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T DisplayReportLimitHitMessage() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DisplayReportLimitHitMessage", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Clear() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Reset() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reset", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
