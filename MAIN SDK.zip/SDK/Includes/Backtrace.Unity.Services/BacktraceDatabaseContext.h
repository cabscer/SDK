#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Services {
			class BacktraceDatabaseContext : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Services", "BacktraceDatabaseContext", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.Int32,System.Collections.Generic.List`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord>> */
				template <typename T = void* /*GENERICTYPE*/> T $BatchRetry$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$BatchRetry$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.IDictionary`2<System.Int32,System.Collections.Generic.List`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord>> */
				void set_$BatchRetry$(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$BatchRetry$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T TotalSize() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TotalSize");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int64 */
				void set_TotalSize(int64_t value) {
					static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("TotalSize");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T TotalRecords() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TotalRecords");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_TotalRecords(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("TotalRecords");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T _retryNumber() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_retryNumber");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set__retryNumber(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_retryNumber");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.RetryOrder */
				template <typename T = int> T $RetryOrder$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$RetryOrder$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.RetryOrder */
				void set_$RetryOrder$(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$RetryOrder$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				template <typename T = int> T $DeduplicationStrategy$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$DeduplicationStrategy$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				void set_$DeduplicationStrategy$(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$DeduplicationStrategy$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.Int32,System.Collections.Generic.List`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord>> */
				template <typename T = void* /*GENERICTYPE*/> T get_BatchRetry() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BatchRetry", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_BatchRetry(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BatchRetry", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.RetryOrder */
				template <typename T = int> T get_RetryOrder() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RetryOrder", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_RetryOrder(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_RetryOrder", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				template <typename T = int> T get_DeduplicationStrategy() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DeduplicationStrategy", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_DeduplicationStrategy(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DeduplicationStrategy", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetupBatch() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetupBatch", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetHash(BNM::IL2CPP::Il2CppObject* backtraceData) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetHash", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceData);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetRecordByHash(BNM::Structures::Mono::String* hash) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetRecordByHash", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](hash);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Add(BNM::IL2CPP::Il2CppObject* backtraceRecord) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceRecord);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Any(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Any", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Any_1() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Any", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Delete(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T IncrementBatchRetry() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IncrementBatchRetry", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T IncrementBatches() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IncrementBatches", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T RemoveMaxRetries() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RemoveMaxRetries", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord> */
				template <typename T = void* /*GENERICTYPE*/> T Get() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Get", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T Count() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Count", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Dispose() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Dispose", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Clear() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T LastOrDefault() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LastOrDefault", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T FirstOrDefault() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FirstOrDefault", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T FirstOrDefault_1(void* /*GENERICTYPE*/ predicate) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FirstOrDefault", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](predicate);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetFirstRecord() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetFirstRecord", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetLastRecord() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetLastRecord", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T GetSize() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSize", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T GetTotalNumberOfRecords() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetTotalNumberOfRecords", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord> */
				template <typename T = void* /*GENERICTYPE*/> T GetRecordsToDelete() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetRecordsToDelete", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AddDuplicate(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddDuplicate", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				
			};
		}
	}
}
