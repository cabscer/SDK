#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Services {
			class BacktraceDatabaseFileContext : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Services", "BacktraceDatabaseFileContext", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String[] */
				template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T _possibleDatabaseExtension() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_possibleDatabaseExtension");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String[] */
				void set__possibleDatabaseExtension(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
					static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("_possibleDatabaseExtension");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T _maxDatabaseSize() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_maxDatabaseSize");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int64 */
				void set__maxDatabaseSize(int64_t value) {
					static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("_maxDatabaseSize");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T _maxRecordNumber() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_maxRecordNumber");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.UInt32 */
				void set__maxRecordNumber(BNM::Types::uint value) {
					static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("_maxRecordNumber");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.IO.DirectoryInfo */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _databaseDirectoryInfo() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_databaseDirectoryInfo");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.IO.DirectoryInfo */
				void set__databaseDirectoryInfo(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_databaseDirectoryInfo");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T RecordFilterRegex() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RecordFilterRegex");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_RecordFilterRegex(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("RecordFilterRegex");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseAttachmentManager */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _attachmentManager() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_attachmentManager");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseAttachmentManager */
				void set__attachmentManager(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_attachmentManager");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T _path() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_path");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set__path(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_path");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T get_ScreenshotQuality() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotQuality", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_ScreenshotQuality(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotQuality", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T get_ScreenshotMaxHeight() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotMaxHeight", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_ScreenshotMaxHeight(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotMaxHeight", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<System.IO.FileInfo> */
				template <typename T = void* /*GENERICTYPE*/> T GetAll() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAll", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<System.IO.FileInfo> */
				template <typename T = void* /*GENERICTYPE*/> T GetRecords() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetRecords", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T RemoveOrphaned(void* /*GENERICTYPE*/ existingRecords) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RemoveOrphaned", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](existingRecords);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ValidFileConsistency() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidFileConsistency", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Clear() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Delete(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T IsDatabaseDependency(BNM::Structures::Mono::String* path) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsDatabaseDependency", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](path);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Delete_1(BNM::Structures::Mono::String* path) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](path);
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<System.String> */
				template <typename T = void* /*GENERICTYPE*/> T GenerateRecordAttachments(BNM::IL2CPP::Il2CppObject* data) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateRecordAttachments", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Save(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Save", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T Save_1(BNM::Structures::Mono::String* json, BNM::Structures::Mono::String* destPath) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Save", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](json, destPath);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T IsValidRecord(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsValidRecord", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				
			};
		}
	}
}
