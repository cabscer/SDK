#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BoundaryGeometry
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BoundaryGeometry", BNM::Image("Oculus.VR.dll"));
		}
		
		int BoundaryType;
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* Points;
		int PointsCount;
		
		
	};
}
