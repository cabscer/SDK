#pragma once
#include <BNMIncludes.hpp>

#undef Up
#undef Down
#undef Left
#undef Right
namespace GlobalNamespace {
	enum class ButtonBits : int
	{
		Up = 0,
		Down = 1,
		Left = 2,
		Right = 3
	};
}
