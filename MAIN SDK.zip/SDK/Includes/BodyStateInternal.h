#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BodyStateInternal
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BodyStateInternal", BNM::Image("Oculus.VR.dll"));
		}
		
		int IsActive;
		float Confidence;
		BNM::Types::uint SkeletonChangedCount;
		double Time;
		BNM::IL2CPP::Il2CppObject* JointLocation_0;
		BNM::IL2CPP::Il2CppObject* JointLocation_1;
		BNM::IL2CPP::Il2CppObject* JointLocation_2;
		BNM::IL2CPP::Il2CppObject* JointLocation_3;
		BNM::IL2CPP::Il2CppObject* JointLocation_4;
		BNM::IL2CPP::Il2CppObject* JointLocation_5;
		BNM::IL2CPP::Il2CppObject* JointLocation_6;
		BNM::IL2CPP::Il2CppObject* JointLocation_7;
		BNM::IL2CPP::Il2CppObject* JointLocation_8;
		BNM::IL2CPP::Il2CppObject* JointLocation_9;
		BNM::IL2CPP::Il2CppObject* JointLocation_10;
		BNM::IL2CPP::Il2CppObject* JointLocation_11;
		BNM::IL2CPP::Il2CppObject* JointLocation_12;
		BNM::IL2CPP::Il2CppObject* JointLocation_13;
		BNM::IL2CPP::Il2CppObject* JointLocation_14;
		BNM::IL2CPP::Il2CppObject* JointLocation_15;
		BNM::IL2CPP::Il2CppObject* JointLocation_16;
		BNM::IL2CPP::Il2CppObject* JointLocation_17;
		BNM::IL2CPP::Il2CppObject* JointLocation_18;
		BNM::IL2CPP::Il2CppObject* JointLocation_19;
		BNM::IL2CPP::Il2CppObject* JointLocation_20;
		BNM::IL2CPP::Il2CppObject* JointLocation_21;
		BNM::IL2CPP::Il2CppObject* JointLocation_22;
		BNM::IL2CPP::Il2CppObject* JointLocation_23;
		BNM::IL2CPP::Il2CppObject* JointLocation_24;
		BNM::IL2CPP::Il2CppObject* JointLocation_25;
		BNM::IL2CPP::Il2CppObject* JointLocation_26;
		BNM::IL2CPP::Il2CppObject* JointLocation_27;
		BNM::IL2CPP::Il2CppObject* JointLocation_28;
		BNM::IL2CPP::Il2CppObject* JointLocation_29;
		BNM::IL2CPP::Il2CppObject* JointLocation_30;
		BNM::IL2CPP::Il2CppObject* JointLocation_31;
		BNM::IL2CPP::Il2CppObject* JointLocation_32;
		BNM::IL2CPP::Il2CppObject* JointLocation_33;
		BNM::IL2CPP::Il2CppObject* JointLocation_34;
		BNM::IL2CPP::Il2CppObject* JointLocation_35;
		BNM::IL2CPP::Il2CppObject* JointLocation_36;
		BNM::IL2CPP::Il2CppObject* JointLocation_37;
		BNM::IL2CPP::Il2CppObject* JointLocation_38;
		BNM::IL2CPP::Il2CppObject* JointLocation_39;
		BNM::IL2CPP::Il2CppObject* JointLocation_40;
		BNM::IL2CPP::Il2CppObject* JointLocation_41;
		BNM::IL2CPP::Il2CppObject* JointLocation_42;
		BNM::IL2CPP::Il2CppObject* JointLocation_43;
		BNM::IL2CPP::Il2CppObject* JointLocation_44;
		BNM::IL2CPP::Il2CppObject* JointLocation_45;
		BNM::IL2CPP::Il2CppObject* JointLocation_46;
		BNM::IL2CPP::Il2CppObject* JointLocation_47;
		BNM::IL2CPP::Il2CppObject* JointLocation_48;
		BNM::IL2CPP::Il2CppObject* JointLocation_49;
		BNM::IL2CPP::Il2CppObject* JointLocation_50;
		BNM::IL2CPP::Il2CppObject* JointLocation_51;
		BNM::IL2CPP::Il2CppObject* JointLocation_52;
		BNM::IL2CPP::Il2CppObject* JointLocation_53;
		BNM::IL2CPP::Il2CppObject* JointLocation_54;
		BNM::IL2CPP::Il2CppObject* JointLocation_55;
		BNM::IL2CPP::Il2CppObject* JointLocation_56;
		BNM::IL2CPP::Il2CppObject* JointLocation_57;
		BNM::IL2CPP::Il2CppObject* JointLocation_58;
		BNM::IL2CPP::Il2CppObject* JointLocation_59;
		BNM::IL2CPP::Il2CppObject* JointLocation_60;
		BNM::IL2CPP::Il2CppObject* JointLocation_61;
		BNM::IL2CPP::Il2CppObject* JointLocation_62;
		BNM::IL2CPP::Il2CppObject* JointLocation_63;
		BNM::IL2CPP::Il2CppObject* JointLocation_64;
		BNM::IL2CPP::Il2CppObject* JointLocation_65;
		BNM::IL2CPP::Il2CppObject* JointLocation_66;
		BNM::IL2CPP::Il2CppObject* JointLocation_67;
		BNM::IL2CPP::Il2CppObject* JointLocation_68;
		BNM::IL2CPP::Il2CppObject* JointLocation_69;
		
		
	};
}
