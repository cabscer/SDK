#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ActionQueryMatcher : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ActionQueryMatcher", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		/* @brief Orig Type: System.Action`1<T> */
		template <typename T = void* /*GENERICTYPE*/> T $callBack$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$callBack$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`1<T> */
		void set_$callBack$(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$callBack$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Action`1<T> */
		template <typename T = void* /*GENERICTYPE*/> T get_callBack() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_callBack", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T OnRuleMatchedElement(BNM::IL2CPP::Il2CppObject* matcher, BNM::IL2CPP::Il2CppObject* element) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnRuleMatchedElement", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](matcher, element);
		}
		
	};
}
