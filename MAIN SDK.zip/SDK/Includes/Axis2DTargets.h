#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Position
#undef Primary2DAxis
#undef Secondary2DAxis
namespace GlobalNamespace {
	enum class Axis2DTargets : int
	{
		None = 0,
		Position = 1,
		Primary2DAxis = 2,
		Secondary2DAxis = 4
	};
}
