#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class CameraCallback : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "CameraCallback", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Invoke(BNM::IL2CPP::Il2CppObject* cam) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](cam);
		}
		
	};
}
