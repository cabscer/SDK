#pragma once
#include <BNMIncludes.hpp>

#undef Line
#undef Pyramid
#undef Box
namespace GlobalNamespace {
	enum class BoneShape : int
	{
		Line = 0,
		Pyramid = 1,
		Box = 2
	};
}
