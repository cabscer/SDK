#pragma once
#include <BNMIncludes.hpp>

#undef WantsInitialStateCheck
namespace GlobalNamespace {
	enum class ActionFlags : int
	{
		WantsInitialStateCheck = 1
	};
}
