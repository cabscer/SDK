#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		class BacktraceDatabase : public BNM::UnityEngine::MonoBehaviour
		{
			public:
			static BNM::Class StaticClass() {
				return BNM::Class("Backtrace.Unity", "BacktraceDatabase", BNM::Image("Backtrace.Unity.dll"));
			}
			
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T _timerBackgroundWork() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_timerBackgroundWork");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Boolean */
			void set__timerBackgroundWork(bool value) {
				static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_timerBackgroundWork");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.BacktraceConfiguration */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T Configuration() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Configuration");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Model.BacktraceConfiguration */
			void set_Configuration(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Configuration");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbs */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _breadcrumbs() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_breadcrumbs");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbs */
			void set__breadcrumbs(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_breadcrumbs");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceClient */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _client() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_client");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.BacktraceClient */
			void set__client(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_client");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Single */
			template <typename T = float> static T LastFrameTime() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LastFrameTime");
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Single */
			static void set_LastFrameTime(float value) {
				static BNM::Field<float> __bnm__field__ = StaticClass().GetField("LastFrameTime");
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.String */
			template <typename T = BNM::Structures::Mono::String*> T $DatabasePath$() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$DatabasePath$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.String */
			void set_$DatabasePath$(BNM::Structures::Mono::String* value) {
				static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$DatabasePath$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceDatabase */
			template <typename T = Backtrace::Unity::BacktraceDatabase*> static T _instance() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_instance");
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.BacktraceDatabase */
			static void set__instance(Backtrace::Unity::BacktraceDatabase* value) {
				static BNM::Field<Backtrace::Unity::BacktraceDatabase*> __bnm__field__ = StaticClass().GetField("_instance");
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseSettings */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T $DatabaseSettings$() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$DatabaseSettings$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseSettings */
			void set_$DatabaseSettings$(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$DatabaseSettings$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Single */
			template <typename T = float> T _lastConnection() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_lastConnection");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Single */
			void set__lastConnection(float value) {
				static BNM::Field<float> __bnm__field__ = StaticClass().GetField("_lastConnection");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceApi */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T $BacktraceApi$() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$BacktraceApi$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Interfaces.IBacktraceApi */
			void set_$BacktraceApi$(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$BacktraceApi$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceDatabaseContext */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T $BacktraceDatabaseContext$() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$BacktraceDatabaseContext$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Interfaces.IBacktraceDatabaseContext */
			void set_$BacktraceDatabaseContext$(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$BacktraceDatabaseContext$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceDatabaseFileContext */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T $BacktraceDatabaseFileContext$() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$BacktraceDatabaseFileContext$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Interfaces.IBacktraceDatabaseFileContext */
			void set_$BacktraceDatabaseFileContext$(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$BacktraceDatabaseFileContext$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T $Enable$() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Enable$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Boolean */
			void set_$Enable$(bool value) {
				static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$Enable$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Services.ReportLimitWatcher */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _reportLimitWatcher() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_reportLimitWatcher");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Services.ReportLimitWatcher */
			void set__reportLimitWatcher(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_reportLimitWatcher");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			
			/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.IBacktraceBreadcrumbs */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Breadcrumbs() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Breadcrumbs", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.String */
			template <typename T = BNM::Structures::Mono::String*> T get_DatabasePath() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DatabasePath", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_DatabasePath(BNM::Structures::Mono::String* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DatabasePath", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: System.Int32 */
			template <typename T = int> T get_ScreenshotQuality() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotQuality", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_ScreenshotQuality(int $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotQuality", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: System.Int32 */
			template <typename T = int> T get_ScreenshotMaxHeight() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotMaxHeight", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_ScreenshotMaxHeight(int $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotMaxHeight", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceDatabase */
			template <typename T = Backtrace::Unity::BacktraceDatabase*> static T get_Instance() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Instance", 0);
				return __bnm__method__();
			}
			/* @brief Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
			template <typename T = int> T get_DeduplicationStrategy() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DeduplicationStrategy", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_DeduplicationStrategy(int $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DeduplicationStrategy", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseSettings */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_DatabaseSettings() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DatabaseSettings", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_DatabaseSettings(BNM::IL2CPP::Il2CppObject* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DatabaseSettings", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceApi */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_BacktraceApi() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BacktraceApi", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_BacktraceApi(BNM::IL2CPP::Il2CppObject* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BacktraceApi", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceDatabaseContext */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_BacktraceDatabaseContext() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BacktraceDatabaseContext", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_BacktraceDatabaseContext(BNM::IL2CPP::Il2CppObject* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BacktraceDatabaseContext", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceDatabaseFileContext */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_BacktraceDatabaseFileContext() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BacktraceDatabaseFileContext", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_BacktraceDatabaseFileContext(BNM::IL2CPP::Il2CppObject* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BacktraceDatabaseFileContext", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T get_Enable() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Enable", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_Enable(bool $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Enable", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Reload() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reload", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T OnDisable() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Awake() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Awake", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Update() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Start() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T SetApi(BNM::IL2CPP::Il2CppObject* backtraceApi) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetApi", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceApi);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T Enabled() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Enabled", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseSettings */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T GetSettings() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSettings", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Clear() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T Add(BNM::IL2CPP::Il2CppObject* data, bool $lock) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 2);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data, $lock);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T Add_1(BNM::IL2CPP::Il2CppObject* backtraceReport, void* /*GENERICTYPE*/ attributes, BNM::Types::uint miniDumpType) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 3);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceReport, attributes, miniDumpType);
			}
			/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord> */
			template <typename T = void* /*GENERICTYPE*/> T Get() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Get", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Delete(BNM::IL2CPP::Il2CppObject* record) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Flush() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Flush", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Send() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T FlushRecord(BNM::IL2CPP::Il2CppObject* record) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FlushRecord", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T SendData(BNM::IL2CPP::Il2CppObject* record) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendData", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
			}
			/* @brief Orig Type: System.Int32 */
			template <typename T = int> T Count() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Count", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T RemoveOrphaned() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RemoveOrphaned", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T SetupMultisceneSupport() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetupMultisceneSupport", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T InitializeDatabasePaths() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("InitializeDatabasePaths", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T LoadReports(BNM::Structures::Mono::String* breadcrumbPath, BNM::Structures::Mono::String* breadcrumbArchive) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LoadReports", 2);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](breadcrumbPath, breadcrumbArchive);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ValidateDatabaseSize() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidateDatabaseSize", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ReachedDiskSpaceLimit() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReachedDiskSpaceLimit", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ReachedMaximumNumberOfRecords() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReachedMaximumNumberOfRecords", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ValidConsistency() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidConsistency", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Int64 */
			template <typename T = int64_t> T GetDatabaseSize() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetDatabaseSize", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T SetReportWatcher(BNM::IL2CPP::Il2CppObject* reportLimitWatcher) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetReportWatcher", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](reportLimitWatcher);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T IncrementBatchRetry() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IncrementBatchRetry", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.String */
			template <typename T = BNM::Structures::Mono::String*> T GetBreadcrumbsPath() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetBreadcrumbsPath", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T EnableBreadcrumbsSupport() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableBreadcrumbsSupport", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			
		};
	}
}
