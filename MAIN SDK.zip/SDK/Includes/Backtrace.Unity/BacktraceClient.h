#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		class BacktraceClient : public BNM::UnityEngine::MonoBehaviour
		{
			public:
			static BNM::Class StaticClass() {
				return BNM::Class("Backtrace.Unity", "BacktraceClient", BNM::Image("Backtrace.Unity.dll"));
			}
			
			/* @brief Orig Type: System.String */
			template <typename T = BNM::Structures::Mono::String*> static T VERSION() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("VERSION");
				return __bnm__field__();
			}
			/* @param value Orig Type: System.String */
			static void set_VERSION(BNM::Structures::Mono::String* value) {
				static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("VERSION");
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.String */
			template <typename T = BNM::Structures::Mono::String*> static T DefaultBacktraceGameObjectName() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultBacktraceGameObjectName");
				return __bnm__field__();
			}
			/* @param value Orig Type: System.String */
			static void set_DefaultBacktraceGameObjectName(BNM::Structures::Mono::String* value) {
				static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("DefaultBacktraceGameObjectName");
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.BacktraceConfiguration */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T Configuration() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Configuration");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Model.BacktraceConfiguration */
			void set_Configuration(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Configuration");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbs */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _breadcrumbs() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_breadcrumbs");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbs */
			void set__breadcrumbs(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_breadcrumbs");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T $Enabled$() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Enabled$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Boolean */
			void set_$Enabled$(bool value) {
				static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$Enabled$");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.JsonData.AttributeProvider */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _attributeProvider() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_attributeProvider");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Model.JsonData.AttributeProvider */
			void set__attributeProvider(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_attributeProvider");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Services.BacktraceMetrics */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _metrics() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_metrics");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Services.BacktraceMetrics */
			void set__metrics(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_metrics");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Random */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _random() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_random");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Random */
			void set__random(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_random");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Collections.Generic.Stack`1<Backtrace.Unity.Model.BacktraceReport> */
			template <typename T = void* /*GENERICTYPE*/> T BackgroundExceptions() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BackgroundExceptions");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Collections.Generic.Stack`1<Backtrace.Unity.Model.BacktraceReport> */
			void set_BackgroundExceptions(void* /*GENERICTYPE*/ value) {
				static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("BackgroundExceptions");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Collections.Generic.HashSet`1<System.String> */
			template <typename T = void* /*GENERICTYPE*/> T _clientReportAttachments() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_clientReportAttachments");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Collections.Generic.HashSet`1<System.String> */
			void set__clientReportAttachments(void* /*GENERICTYPE*/ value) {
				static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_clientReportAttachments");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceClient */
			template <typename T = Backtrace::Unity::BacktraceClient*> static T _instance() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_instance");
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.BacktraceClient */
			static void set__instance(Backtrace::Unity::BacktraceClient* value) {
				static BNM::Field<Backtrace::Unity::BacktraceClient*> __bnm__field__ = StaticClass().GetField("_instance");
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceDatabase */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T Database() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Database");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Interfaces.IBacktraceDatabase */
			void set_Database(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Database");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceApi */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _backtraceApi() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_backtraceApi");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Interfaces.IBacktraceApi */
			void set__backtraceApi(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_backtraceApi");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Services.ReportLimitWatcher */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _reportLimitWatcher() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_reportLimitWatcher");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Services.ReportLimitWatcher */
			void set__reportLimitWatcher(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_reportLimitWatcher");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.BacktraceLogManager */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _backtraceLogManager() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_backtraceLogManager");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Model.BacktraceLogManager */
			void set__backtraceLogManager(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_backtraceLogManager");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Action`1<Backtrace.Unity.Model.BacktraceReport> */
			template <typename T = void* /*GENERICTYPE*/> T _onClientReportLimitReached() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_onClientReportLimitReached");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Action`1<Backtrace.Unity.Model.BacktraceReport> */
			void set__onClientReportLimitReached(void* /*GENERICTYPE*/ value) {
				static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_onClientReportLimitReached");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Func`2<Backtrace.Unity.Model.BacktraceData,Backtrace.Unity.Model.BacktraceData> */
			template <typename T = void* /*GENERICTYPE*/> T BeforeSend() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BeforeSend");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Func`2<Backtrace.Unity.Model.BacktraceData,Backtrace.Unity.Model.BacktraceData> */
			void set_BeforeSend(void* /*GENERICTYPE*/ value) {
				static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("BeforeSend");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Func`4<Backtrace.Unity.Types.ReportFilterType,System.Exception,System.String,System.Boolean> */
			template <typename T = void* /*GENERICTYPE*/> T SkipReport() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SkipReport");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Func`4<Backtrace.Unity.Types.ReportFilterType,System.Exception,System.String,System.Boolean> */
			void set_SkipReport(void* /*GENERICTYPE*/ value) {
				static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("SkipReport");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Action`1<System.Exception> */
			template <typename T = void* /*GENERICTYPE*/> T OnUnhandledApplicationException() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnUnhandledApplicationException");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Action`1<System.Exception> */
			void set_OnUnhandledApplicationException(void* /*GENERICTYPE*/ value) {
				static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("OnUnhandledApplicationException");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: Backtrace.Unity.Runtime.Native.INativeClient */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _nativeClient() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_nativeClient");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: Backtrace.Unity.Runtime.Native.INativeClient */
			void set__nativeClient(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_nativeClient");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			/* @brief Orig Type: System.Threading.Thread */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T _current() {
				static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_current");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				return __bnm__field__();
			}
			/* @param value Orig Type: System.Threading.Thread */
			void set__current(BNM::IL2CPP::Il2CppObject* value) {
				static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_current");
				__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
				__bnm__field__.Set(value);
			}
			
			/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.IBacktraceBreadcrumbs */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Breadcrumbs() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Breadcrumbs", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T get_Enabled() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Enabled", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_Enabled(bool $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Enabled", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.JsonData.AttributeProvider */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_AttributeProvider() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_AttributeProvider", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_AttributeProvider(BNM::IL2CPP::Il2CppObject* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_AttributeProvider", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceMetrics */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Metrics() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Metrics", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Random */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Random() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Random", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.String */
			template <typename T = BNM::Structures::Mono::String*> T get_Item(BNM::Structures::Mono::String* index) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Item", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](index);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_Item(BNM::Structures::Mono::String* index, BNM::Structures::Mono::String* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Item", 2);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](index, $value);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T AddAttachment(BNM::Structures::Mono::String* pathToAttachment) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddAttachment", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](pathToAttachment);
			}
			/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<System.String> */
			template <typename T = void* /*GENERICTYPE*/> T GetAttachments() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttachments", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T SetAttributes(void* /*GENERICTYPE*/ attributes) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetAttributes", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
			}
			/* @brief Orig Type: System.Int32 */
			template <typename T = int> T GetAttributesCount() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttributesCount", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceClient */
			template <typename T = Backtrace::Unity::BacktraceClient*> static T get_Instance() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Instance", 0);
				return __bnm__method__();
			}
			/* @brief Orig Type: System.Action`1<System.Exception> */
			template <typename T = void* /*GENERICTYPE*/> T get_OnServerError() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_OnServerError", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_OnServerError(void* /*GENERICTYPE*/ $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_OnServerError", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: System.Func`3<System.String,Backtrace.Unity.Model.BacktraceData,Backtrace.Unity.Model.BacktraceResult> */
			template <typename T = void* /*GENERICTYPE*/> T get_RequestHandler() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RequestHandler", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_RequestHandler(void* /*GENERICTYPE*/ $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_RequestHandler", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: System.Action`1<Backtrace.Unity.Model.BacktraceResult> */
			template <typename T = void* /*GENERICTYPE*/> T get_OnServerResponse() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_OnServerResponse", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_OnServerResponse(void* /*GENERICTYPE*/ $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_OnServerResponse", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_OnClientReportLimitReached(void* /*GENERICTYPE*/ $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_OnClientReportLimitReached", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: System.Action`1<Backtrace.Unity.Model.BacktraceReport> */
			template <typename T = void* /*GENERICTYPE*/> T get_OnClientReportLimitReached() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_OnClientReportLimitReached", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: Backtrace.Unity.Runtime.Native.INativeClient */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_NativeClient() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NativeClient", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T get_EnablePerformanceStatistics() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_EnablePerformanceStatistics", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Int32 */
			template <typename T = int> T get_GameObjectDepth() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_GameObjectDepth", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceApi */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_BacktraceApi() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BacktraceApi", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_BacktraceApi(BNM::IL2CPP::Il2CppObject* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BacktraceApi", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.Services.ReportLimitWatcher */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T get_ReportLimitWatcher() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ReportLimitWatcher", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T set_ReportLimitWatcher(BNM::IL2CPP::Il2CppObject* $value) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ReportLimitWatcher", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceClient */
			template <typename T = Backtrace::Unity::BacktraceClient*> static T Initialize(BNM::IL2CPP::Il2CppObject* configuration, void* /*GENERICTYPE*/ attributes, BNM::Structures::Mono::String* gameObjectName) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 3);
				return __bnm__method__(configuration, attributes, gameObjectName);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceClient */
			template <typename T = Backtrace::Unity::BacktraceClient*> static T Initialize_1(BNM::Structures::Mono::String* url, BNM::Structures::Mono::String* databasePath, void* /*GENERICTYPE*/ attributes, BNM::Structures::Mono::String* gameObjectName) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 4);
				return __bnm__method__(url, databasePath, attributes, gameObjectName);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceClient */
			template <typename T = Backtrace::Unity::BacktraceClient*> static T Initialize_2(BNM::Structures::Mono::String* url, BNM::Structures::Mono::String* databasePath, void* /*GENERICTYPE*/ attributes, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* attachments, BNM::Structures::Mono::String* gameObjectName) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 5);
				return __bnm__method__(url, databasePath, attributes, attachments, gameObjectName);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceClient */
			template <typename T = Backtrace::Unity::BacktraceClient*> static T Initialize_3(BNM::Structures::Mono::String* url, void* /*GENERICTYPE*/ attributes, BNM::Structures::Mono::String* gameObjectName) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 3);
				return __bnm__method__(url, attributes, gameObjectName);
			}
			/* @brief Orig Type: Backtrace.Unity.BacktraceClient */
			template <typename T = Backtrace::Unity::BacktraceClient*> static T Initialize_4(BNM::Structures::Mono::String* url, void* /*GENERICTYPE*/ attributes, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* attachments, BNM::Structures::Mono::String* gameObjectName) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 4);
				return __bnm__method__(url, attributes, attachments, gameObjectName);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T OnDisable() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Refresh() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Refresh", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T EnableBreadcrumbsSupport() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableBreadcrumbsSupport", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T EnableMetrics() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableMetrics", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T EnableMetrics_1(bool enableIfConfigurationIsDisabled) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableMetrics", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](enableIfConfigurationIsDisabled);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T EnableMetrics_2(BNM::Structures::Mono::String* uniqueAttributeName) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableMetrics", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](uniqueAttributeName);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T EnableMetrics_3(BNM::Structures::Mono::String* uniqueEventsSubmissionUrl, BNM::Structures::Mono::String* summedEventsSubmissionUrl, BNM::Types::uint timeIntervalInSec, BNM::Structures::Mono::String* uniqueAttributeName) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableMetrics", 4);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](uniqueEventsSubmissionUrl, summedEventsSubmissionUrl, timeIntervalInSec, uniqueAttributeName);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T StartupMetrics() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StartupMetrics", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T OnApplicationQuit() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnApplicationQuit", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Awake() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Awake", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T LateUpdate() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LateUpdate", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T OnDestroy() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDestroy", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T SetClientReportLimit(BNM::Types::uint reportPerMin) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetClientReportLimit", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](reportPerMin);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Send(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attachmentPaths, void* /*GENERICTYPE*/ attributes) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 3);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attachmentPaths, attributes);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Send_1(BNM::IL2CPP::Il2CppObject* exception, void* /*GENERICTYPE*/ attachmentPaths, void* /*GENERICTYPE*/ attributes) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 3);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](exception, attachmentPaths, attributes);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T Send_2(BNM::IL2CPP::Il2CppObject* report, void* /*GENERICTYPE*/ sendCallback) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 2);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report, sendCallback);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T SendReport(BNM::IL2CPP::Il2CppObject* report, void* /*GENERICTYPE*/ sendCallback) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendReport", 2);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report, sendCallback);
			}
			/* @brief Orig Type: System.Collections.IEnumerator */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T CollectDataAndSend(BNM::IL2CPP::Il2CppObject* report, void* /*GENERICTYPE*/ sendCallback) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CollectDataAndSend", 2);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report, sendCallback);
			}
			/* @brief Orig Type: Backtrace.Unity.Model.BacktraceData */
			template <typename T = BNM::IL2CPP::Il2CppObject*> T SetupBacktraceData(BNM::IL2CPP::Il2CppObject* report) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetupBacktraceData", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T CaptureUnityMessages() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CaptureUnityMessages", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T OnApplicationPause(bool pause) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnApplicationPause", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](pause);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T HandleUnityBackgroundException(BNM::Structures::Mono::String* message, BNM::Structures::Mono::String* stackTrace, int type) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleUnityBackgroundException", 3);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, stackTrace, type);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T HandleUnityMessage(BNM::Structures::Mono::String* message, BNM::Structures::Mono::String* stackTrace, int type) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleUnityMessage", 3);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, stackTrace, type);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T SamplingShouldSkip() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SamplingShouldSkip", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T SendUnhandledException(BNM::IL2CPP::Il2CppObject* exception, bool invokeSkipApi) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendUnhandledException", 2);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](exception, invokeSkipApi);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ShouldSendReport(BNM::IL2CPP::Il2CppObject* exception, void* /*GENERICTYPE*/ attachmentPaths, void* /*GENERICTYPE*/ attributes, bool invokeSkipApi) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldSendReport", 4);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](exception, attachmentPaths, attributes, invokeSkipApi);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ShouldSendReport_1(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attachmentPaths, void* /*GENERICTYPE*/ attributes) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldSendReport", 3);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attachmentPaths, attributes);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ShouldSendReport_2(BNM::IL2CPP::Il2CppObject* report) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldSendReport", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report);
			}
			/* @brief Orig Type: System.Void */
			template <typename T = void> T HandleInnerException(BNM::IL2CPP::Il2CppObject* report) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleInnerException", 1);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report);
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ValidClientConfiguration() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidClientConfiguration", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			/* @brief Orig Type: System.Boolean */
			template <typename T = bool> T ShouldSkipReport(int type, BNM::IL2CPP::Il2CppObject* exception, BNM::Structures::Mono::String* message) {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldSkipReport", 3);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](type, exception, message);
			}
			/* @brief Orig Type: System.Collections.Generic.IList`1<System.String> */
			template <typename T = void* /*GENERICTYPE*/> T GetNativeAttachments() {
				static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetNativeAttachments", 0);
				return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
			}
			
		};
	}
}
