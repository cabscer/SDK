#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Runtime {
			namespace Native {
				class NativeClientFactory

				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Runtime.Native", "NativeClientFactory", BNM::Image("Backtrace.Unity.dll"));
					}
					
					
					/* @brief Orig Type: Backtrace.Unity.Runtime.Native.INativeClient */
					template <typename T = BNM::IL2CPP::Il2CppObject*> static T CreateNativeClient(BNM::IL2CPP::Il2CppObject* configuration, BNM::Structures::Mono::String* gameObjectName, BNM::IL2CPP::Il2CppObject* breadcrumbs, void* /*GENERICTYPE*/ attributes, void* /*GENERICTYPE*/ attachments) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateNativeClient", 5);
						return __bnm__method__(configuration, gameObjectName, breadcrumbs, attributes, attachments);
					}
					
				};
			}
		}
	}
}
