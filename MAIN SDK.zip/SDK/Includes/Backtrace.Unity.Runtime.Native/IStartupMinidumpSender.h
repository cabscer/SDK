#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Runtime {
			namespace Native {
				class IStartupMinidumpSender
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Runtime.Native", "IStartupMinidumpSender", BNM::Image("Backtrace.Unity.dll"));
					}
					
					
					/* @brief Orig Type: System.Collections.IEnumerator */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T SendMinidumpOnStartup(void* /*GENERICTYPE*/ clientAttachments, BNM::IL2CPP::Il2CppObject* backtraceApi) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendMinidumpOnStartup", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clientAttachments, backtraceApi);
					}
					
				};
			}
		}
	}
}
