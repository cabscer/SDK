#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Runtime {
			namespace Native {
				class INativeClient
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Runtime.Native", "INativeClient", BNM::Image("Backtrace.Unity.dll"));
					}
					
					
					/* @brief Orig Type: System.Void */
					template <typename T = void> T HandleAnr() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleAnr", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T SetAttribute(BNM::Structures::Mono::String* key, BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetAttribute", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T OnOOM() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnOOM", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Update(float time) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](time);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Disable() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Disable", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T PauseAnrThread(bool state) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PauseAnrThread", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](state);
					}
					
				};
			}
		}
	}
}
