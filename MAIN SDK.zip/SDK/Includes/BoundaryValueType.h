#pragma once
#include <BNMIncludes.hpp>

#undef MaxHeightmapRes
#undef MinDetailResPerPatch
#undef MaxDetailResPerPatch
#undef MaxDetailPatchCount
#undef MaxDetailsPerRes
#undef MinAlphamapRes
#undef MaxAlphamapRes
#undef MinBaseMapRes
#undef MaxBaseMapRes
namespace GlobalNamespace {
	enum class BoundaryValueType : int
	{
		MaxHeightmapRes = 0,
		MinDetailResPerPatch = 1,
		MaxDetailResPerPatch = 2,
		MaxDetailPatchCount = 3,
		MaxDetailsPerRes = 4,
		MinAlphamapRes = 5,
		MaxAlphamapRes = 6,
		MinBaseMapRes = 7,
		MaxBaseMapRes = 8
	};
}
