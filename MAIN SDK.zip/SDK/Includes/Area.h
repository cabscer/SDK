#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Area : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Area", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.RectInt */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T rect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.RectInt */
		void set_rect(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("rect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T allocator() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("allocator");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator */
		void set_allocator(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("allocator");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		
	};
}
