#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Capability
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Capability", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::Structures::Mono::String* path;
		BNM::Structures::Mono::String* $value;
		
		
	};
}
