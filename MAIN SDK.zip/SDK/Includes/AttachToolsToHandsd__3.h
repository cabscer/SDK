#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class $AttachToolsToHands$d__3 : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "<AttachToolsToHands>d__3", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T $$1__state() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$1__state");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_$$1__state(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$$1__state");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $$2__current() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$2__current");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Object */
		void set_$$2__current(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$$2__current");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T toolObjects() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("toolObjects");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform[] */
		void set_toolObjects(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("toolObjects");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T isRightHand() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isRightHand");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_isRightHand(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("isRightHand");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: OculusSampleFramework.InteractableToolsCreator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $$4__this() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$4__this");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: OculusSampleFramework.InteractableToolsCreator */
		void set_$$4__this(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$$4__this");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: OculusSampleFramework.HandsManager */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $handsManagerObj$5__2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$handsManagerObj$5__2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: OculusSampleFramework.HandsManager */
		void set_$handsManagerObj$5__2(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$handsManagerObj$5__2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.HashSet`1/Enumerator<UnityEngine.Transform> */
		template <typename T = void* /*GENERICTYPE*/> T $$7__wrap2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$7__wrap2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.HashSet`1/Enumerator<UnityEngine.Transform> */
		void set_$$7__wrap2(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$$7__wrap2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $toolObject$5__4() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$toolObject$5__4");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_$toolObject$5__4(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$toolObject$5__4");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: OVRSkeleton */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $handSkeletonToAttachTo$5__5() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$handSkeletonToAttachTo$5__5");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: OVRSkeleton */
		void set_$handSkeletonToAttachTo$5__5(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$handSkeletonToAttachTo$5__5");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_IDisposable_Dispose() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.IDisposable.Dispose", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T MoveNext() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MoveNext", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T m__Finally1() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("<>m__Finally1", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T System_Collections_Generic_IEnumeratorSystem_Object_get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.Generic.IEnumerator<System.Object>.get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_Collections_IEnumerator_Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.IEnumerator.Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T System_Collections_IEnumerator_get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.IEnumerator.get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
