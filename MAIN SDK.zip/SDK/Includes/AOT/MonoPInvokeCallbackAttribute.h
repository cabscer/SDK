#pragma once
#include <BNMIncludes.hpp>

namespace AOT {
	class MonoPInvokeCallbackAttribute : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("AOT", "MonoPInvokeCallbackAttribute", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		
	};
}
