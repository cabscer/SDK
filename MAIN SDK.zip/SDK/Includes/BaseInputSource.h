#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BaseInputSource : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BaseInputSource", BNM::Image("Oculus.VR.dll"));
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T _operatingWithoutOVRCameraRig() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_operatingWithoutOVRCameraRig");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set__operatingWithoutOVRCameraRig(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_operatingWithoutOVRCameraRig");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: OVRCameraRig */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _rig() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_rig");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: OVRCameraRig */
		void set__rig(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_rig");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnUpdatedAnchors(BNM::IL2CPP::Il2CppObject* obj) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnUpdatedAnchors", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](obj);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateInput() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateInput", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Dispose() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Dispose", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
