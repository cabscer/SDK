#pragma once
#include <BNMIncludes.hpp>

#undef False
#undef True
#undef Unspecified
namespace GlobalNamespace {
	enum class AutoDetectValues : int
	{
		False = 0,
		True = 1,
		Unspecified = -1
	};
}
