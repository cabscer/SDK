#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BindingState
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BindingState", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::Types::byte m_ControlCount;
		BNM::Types::byte m_InteractionCount;
		BNM::Types::byte m_ProcessorCount;
		BNM::Types::byte m_MapIndex;
		BNM::Types::byte m_Flags;
		BNM::Types::byte m_PartIndex;
		BNM::Types::ushort m_ActionIndex;
		BNM::Types::ushort m_CompositeOrCompositeBindingIndex;
		BNM::Types::ushort m_ProcessorStartIndex;
		BNM::Types::ushort m_InteractionStartIndex;
		BNM::Types::ushort m_ControlStartIndex;
		double m_PressTime;
		int m_TriggerEventIdForComposite;
		int __padding;
		
		
	};
}
