#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Activated
#undef Deactivated
namespace GlobalNamespace {
	enum class ActivateClickAnimationMode : int
	{
		None = 0,
		Activated = 1,
		Deactivated = 2
	};
}
