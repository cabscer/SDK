#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Campfire : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Campfire", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T baseFire() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("baseFire");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_baseFire(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("baseFire");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T middleFire() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("middleFire");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_middleFire(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("middleFire");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T topFire() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("topFire");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_topFire(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("topFire");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T baseMultiplier() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("baseMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_baseMultiplier(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("baseMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T middleMultiplier() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("middleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_middleMultiplier(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("middleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T topMultiplier() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("topMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_topMultiplier(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("topMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T bottomRange() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bottomRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_bottomRange(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("bottomRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T middleRange() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("middleRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_middleRange(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("middleRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T topRange() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("topRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_topRange(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("topRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T lastAngleBottom() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lastAngleBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_lastAngleBottom(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("lastAngleBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T lastAngleMiddle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lastAngleMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_lastAngleMiddle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("lastAngleMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T lastAngleTop() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lastAngleTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_lastAngleTop(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("lastAngleTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T perlinStepBottom() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("perlinStepBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_perlinStepBottom(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("perlinStepBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T perlinStepMiddle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("perlinStepMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_perlinStepMiddle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("perlinStepMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T perlinStepTop() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("perlinStepTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_perlinStepTop(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("perlinStepTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T perlinBottom() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("perlinBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_perlinBottom(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("perlinBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T perlinMiddle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("perlinMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_perlinMiddle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("perlinMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T perlinTop() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("perlinTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_perlinTop(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("perlinTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T startingRotationBottom() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("startingRotationBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_startingRotationBottom(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("startingRotationBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T startingRotationMiddle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("startingRotationMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_startingRotationMiddle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("startingRotationMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T startingRotationTop() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("startingRotationTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_startingRotationTop(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("startingRotationTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T slerp() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("slerp");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_slerp(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("slerp");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T mergedBottom() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("mergedBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_mergedBottom(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("mergedBottom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T mergedMiddle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("mergedMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_mergedMiddle(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("mergedMiddle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T mergedTop() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("mergedTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_mergedTop(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("mergedTop");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T lastTimeOfDay() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lastTimeOfDay");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_lastTimeOfDay(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("lastTimeOfDay");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Material */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T mat() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("mat");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Material */
		void set_mat(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("mat");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T h() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("h");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_h(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("h");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T s() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_s(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("s");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T v() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("v");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_v(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("v");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T overrideDayNight() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("overrideDayNight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_overrideDayNight(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("overrideDayNight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T tempVec() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("tempVec");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_tempVec(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("tempVec");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T isActive() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isActive");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean[] */
		void set_isActive(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("isActive");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T wasActive() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("wasActive");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_wasActive(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("wasActive");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T LateUpdate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LateUpdate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Flap(BNM::IL2CPP::Il2CppObject* perlinValue, float perlinStep, BNM::IL2CPP::Il2CppObject* lastAngle, BNM::IL2CPP::Il2CppObject* flameTransform, float range, float multiplier, BNM::IL2CPP::Il2CppObject* isMerged) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Flap", 7);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](perlinValue, perlinStep, lastAngle, flameTransform, range, multiplier, isMerged);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ReturnToOff(BNM::IL2CPP::Il2CppObject* startTransform, float targetAngle, BNM::IL2CPP::Il2CppObject* isMerged) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReturnToOff", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](startTransform, targetAngle, isMerged);
		}
		
	};
}
