#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ATypeName : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ATypeName", BNM::Image("mscorlib.dll"));
		}
		
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T get_DisplayName() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DisplayName", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T Equals(BNM::IL2CPP::Il2CppObject* other) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Equals", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](other);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T GetHashCode() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetHashCode", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T Equals_1(BNM::IL2CPP::Il2CppObject* other) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Equals", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](other);
		}
		
	};
}
