#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Avx2

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Avx2", BNM::Image("Unity.Burst.dll"));
		}
		
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T get_IsAvx2Supported() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsAvx2Supported", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_movemask_epi8(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_movemask_epi8", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_extract_epi8(BNM::IL2CPP::Il2CppObject* a, int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_extract_epi8", 2);
			return __bnm__method__(a, index);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_extract_epi16(BNM::IL2CPP::Il2CppObject* a, int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_extract_epi16", 2);
			return __bnm__method__(a, index);
		}
		/* @brief Orig Type: System.Double */
		template <typename T = double> static T mm256_cvtsd_f64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtsd_f64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_cvtsi256_si32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtsi256_si32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.Int64 */
		template <typename T = int64_t> static T mm256_cvtsi256_si64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtsi256_si64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmpeq_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmpeq_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmpeq_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmpeq_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmpeq_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmpeq_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmpeq_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmpeq_epi64", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmpgt_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmpgt_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmpgt_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmpgt_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmpgt_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmpgt_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmpgt_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmpgt_epi64", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_max_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_max_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_max_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_max_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_max_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_max_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_max_epu8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_max_epu8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_max_epu16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_max_epu16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_max_epu32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_max_epu32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_min_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_min_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_min_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_min_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_min_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_min_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_min_epu8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_min_epu8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_min_epu16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_min_epu16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_min_epu32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_min_epu32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_and_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_and_si256", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_andnot_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_andnot_si256", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_or_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_or_si256", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_xor_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_xor_si256", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_abs_epi8(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_abs_epi8", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_abs_epi16(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_abs_epi16", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_abs_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_abs_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_add_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_add_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_add_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_add_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_add_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_add_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_add_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_add_epi64", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_adds_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_adds_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_adds_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_adds_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_adds_epu8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_adds_epu8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_adds_epu16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_adds_epu16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sub_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sub_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sub_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sub_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sub_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sub_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sub_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sub_epi64", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_subs_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_subs_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_subs_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_subs_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_subs_epu8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_subs_epu8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_subs_epu16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_subs_epu16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_avg_epu8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_avg_epu8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_avg_epu16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_avg_epu16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hadd_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hadd_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hadd_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hadd_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hadds_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hadds_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hsub_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hsub_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hsub_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hsub_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hsubs_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hsubs_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_madd_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_madd_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_maddubs_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maddubs_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mulhi_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mulhi_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mulhi_epu16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mulhi_epu16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mullo_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mullo_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mullo_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mullo_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mul_epu32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mul_epu32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mul_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mul_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sign_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sign_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sign_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sign_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sign_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sign_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mulhrs_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mulhrs_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sad_epu8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sad_epu8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mpsadbw_epu8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mpsadbw_epu8", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_slli_si256(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_slli_si256", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_bslli_epi128(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_bslli_epi128", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srli_si256(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srli_si256", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_bsrli_epi128(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_bsrli_epi128", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sll_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sll_epi16", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sll_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sll_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sll_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sll_epi64", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_slli_epi16(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_slli_epi16", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_slli_epi32(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_slli_epi32", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_slli_epi64(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_slli_epi64", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sllv_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sllv_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sllv_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sllv_epi64", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T sllv_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("sllv_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T sllv_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("sllv_epi64", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sra_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sra_epi16", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sra_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sra_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srai_epi16(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srai_epi16", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srai_epi32(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srai_epi32", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srav_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srav_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T srav_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("srav_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srl_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srl_epi16", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srl_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srl_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srl_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srl_epi64", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srli_epi16(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srli_epi16", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srli_epi32(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srli_epi32", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srli_epi64(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srli_epi64", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srlv_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srlv_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_srlv_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_srlv_epi64", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T srlv_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("srlv_epi32", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T srlv_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* count) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("srlv_epi64", 2);
			return __bnm__method__(a, count);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T blend_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("blend_epi32", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_blend_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_blend_epi32", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_alignr_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_alignr_epi8", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_blendv_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_blendv_epi8", 3);
			return __bnm__method__(a, b, mask);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_blend_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_blend_epi16", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_packs_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_packs_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_packs_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_packs_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_packus_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_packus_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_packus_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_packus_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpackhi_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpackhi_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpackhi_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpackhi_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpackhi_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpackhi_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpackhi_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpackhi_epi64", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpacklo_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpacklo_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpacklo_epi16(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpacklo_epi16", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpacklo_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpacklo_epi32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpacklo_epi64(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpacklo_epi64", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_shuffle_epi8(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_shuffle_epi8", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_shuffle_epi32(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_shuffle_epi32", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_shufflehi_epi16(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_shufflehi_epi16", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_shufflelo_epi16(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_shufflelo_epi16", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_extracti128_si256(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_extracti128_si256", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_inserti128_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_inserti128_si256", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T broadcastss_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("broadcastss_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcastss_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcastss_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T broadcastsd_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("broadcastsd_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcastsd_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcastsd_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T broadcastb_epi8(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("broadcastb_epi8", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T broadcastw_epi16(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("broadcastw_epi16", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T broadcastd_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("broadcastd_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T broadcastq_epi64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("broadcastq_epi64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcastb_epi8(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcastb_epi8", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcastw_epi16(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcastw_epi16", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcastd_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcastd_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcastq_epi64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcastq_epi64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcastsi128_si256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcastsi128_si256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepi8_epi16(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepi8_epi16", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepi8_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepi8_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepi8_epi64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepi8_epi64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepi16_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepi16_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepi16_epi64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepi16_epi64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepi32_epi64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepi32_epi64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepu8_epi16(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepu8_epi16", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepu8_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepu8_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepu8_epi64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepu8_epi64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepu16_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepu16_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepu16_epi64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepu16_epi64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepu32_epi64(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepu32_epi64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T maskload_epi32(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("maskload_epi32", 2);
			return __bnm__method__(mem_addr, mask);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T maskload_epi64(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("maskload_epi64", 2);
			return __bnm__method__(mem_addr, mask);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T maskstore_epi32(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("maskstore_epi32", 3);
			return __bnm__method__(mem_addr, mask, a);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T maskstore_epi64(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("maskstore_epi64", 3);
			return __bnm__method__(mem_addr, mask, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_maskload_epi32(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maskload_epi32", 2);
			return __bnm__method__(mem_addr, mask);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_maskload_epi64(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maskload_epi64", 2);
			return __bnm__method__(mem_addr, mask);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_maskstore_epi32(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maskstore_epi32", 3);
			return __bnm__method__(mem_addr, mask, a);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_maskstore_epi64(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maskstore_epi64", 3);
			return __bnm__method__(mem_addr, mask, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permutevar8x32_epi32(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* idx) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permutevar8x32_epi32", 2);
			return __bnm__method__(a, idx);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permutevar8x32_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* idx) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permutevar8x32_ps", 2);
			return __bnm__method__(a, idx);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permute4x64_epi64(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permute4x64_epi64", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permute4x64_pd(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permute4x64_pd", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permute2x128_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permute2x128_si256", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_stream_load_si256(void* /*POINTER*/ mem_addr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_stream_load_si256", 1);
			return __bnm__method__(mem_addr);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T EmulatedGather(void* /*POINTER*/ dptr, void* /*POINTER*/ base_addr, void* /*POINTER*/ indexPtr, int scale, int n, void* /*POINTER*/ mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EmulatedGather", 6);
			return __bnm__method__(dptr, base_addr, indexPtr, scale, n, mask);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T EmulatedGather_1(void* /*POINTER*/ dptr, void* /*POINTER*/ base_addr, void* /*POINTER*/ indexPtr, int scale, int n, void* /*POINTER*/ mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EmulatedGather", 6);
			return __bnm__method__(dptr, base_addr, indexPtr, scale, n, mask);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_i32gather_epi32(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_i32gather_epi32", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_i32gather_pd(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_i32gather_pd", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_i32gather_ps(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_i32gather_ps", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_i64gather_pd(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_i64gather_pd", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_i64gather_ps(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_i64gather_ps", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T i32gather_pd(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("i32gather_pd", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T i32gather_ps(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("i32gather_ps", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T i64gather_pd(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("i64gather_pd", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T i64gather_ps(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("i64gather_ps", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_i32gather_epi64(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_i32gather_epi64", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_i64gather_epi32(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_i64gather_epi32", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_i64gather_epi64(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_i64gather_epi64", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T i32gather_epi32(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("i32gather_epi32", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T i32gather_epi64(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("i32gather_epi64", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T i64gather_epi32(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("i64gather_epi32", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T i64gather_epi64(void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("i64gather_epi64", 3);
			return __bnm__method__(base_addr, vindex, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mask_i32gather_pd(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mask_i32gather_pd", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mask_i32gather_ps(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mask_i32gather_ps", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mask_i64gather_pd(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mask_i64gather_pd", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mask_i64gather_ps(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mask_i64gather_ps", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mask_i32gather_epi32(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mask_i32gather_epi32", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mask_i32gather_epi64(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mask_i32gather_epi64", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mask_i64gather_epi64(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mask_i64gather_epi64", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mask_i64gather_epi32(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mask_i64gather_epi32", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mask_i32gather_pd(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mask_i32gather_pd", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mask_i32gather_ps(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mask_i32gather_ps", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mask_i64gather_pd(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mask_i64gather_pd", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mask_i64gather_ps(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mask_i64gather_ps", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mask_i32gather_epi32(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mask_i32gather_epi32", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mask_i32gather_epi64(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mask_i32gather_epi64", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mask_i64gather_epi32(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mask_i64gather_epi32", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mask_i64gather_epi64(BNM::IL2CPP::Il2CppObject* src, void* /*POINTER*/ base_addr, BNM::IL2CPP::Il2CppObject* vindex, BNM::IL2CPP::Il2CppObject* mask, int scale) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mask_i64gather_epi64", 5);
			return __bnm__method__(src, base_addr, vindex, mask, scale);
		}
		
	};
}
