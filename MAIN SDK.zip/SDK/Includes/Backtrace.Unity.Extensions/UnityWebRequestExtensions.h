#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Extensions {
			class UnityWebRequestExtensions

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Extensions", "UnityWebRequestExtensions", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T ContentTypeHeader() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ContentTypeHeader");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_ContentTypeHeader(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ContentTypeHeader");
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: UnityEngine.Networking.UnityWebRequest */
				template <typename T = BNM::IL2CPP::Il2CppObject*> static T SetMultipartFormData(BNM::IL2CPP::Il2CppObject* source, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* boundaryId) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetMultipartFormData", 2);
					return __bnm__method__(source, boundaryId);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T ReceivedNetworkError(BNM::IL2CPP::Il2CppObject* request) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReceivedNetworkError", 1);
					return __bnm__method__(request);
				}
				/* @brief Orig Type: UnityEngine.Networking.UnityWebRequest */
				template <typename T = BNM::IL2CPP::Il2CppObject*> static T SetJsonContentType(BNM::IL2CPP::Il2CppObject* source) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetJsonContentType", 1);
					return __bnm__method__(source);
				}
				/* @brief Orig Type: UnityEngine.Networking.UnityWebRequest */
				template <typename T = BNM::IL2CPP::Il2CppObject*> static T IgnoreSsl(BNM::IL2CPP::Il2CppObject* source, bool shouldIgnore) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IgnoreSsl", 2);
					return __bnm__method__(source, shouldIgnore);
				}
				
			};
		}
	}
}
