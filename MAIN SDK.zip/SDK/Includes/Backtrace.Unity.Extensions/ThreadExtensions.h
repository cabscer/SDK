#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Extensions {
			class ThreadExtensions

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Extensions", "ThreadExtensions", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GenerateValidThreadName(BNM::IL2CPP::Il2CppObject* thread) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateValidThreadName", 1);
					return __bnm__method__(thread);
				}
				
			};
		}
	}
}
