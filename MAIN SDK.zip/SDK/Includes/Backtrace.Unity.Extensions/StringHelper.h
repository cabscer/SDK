#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Extensions {
			class StringHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Extensions", "StringHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T OnlyLetters(BNM::Structures::Mono::String* source) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnlyLetters", 1);
					return __bnm__method__(source);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GetSha(BNM::IL2CPP::Il2CppObject* source) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSha", 1);
					return __bnm__method__(source);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GetSha_1(BNM::Structures::Mono::String* source) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSha", 1);
					return __bnm__method__(source);
				}
				
			};
		}
	}
}
