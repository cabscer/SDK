#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Extensions {
			class StreamExtensions

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Extensions", "StreamExtensions", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T _DefaultCopyBufferSize() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_DefaultCopyBufferSize");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set__DefaultCopyBufferSize(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_DefaultCopyBufferSize");
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Void */
				template <typename T = void> static T CopyTo(BNM::IL2CPP::Il2CppObject* original, BNM::IL2CPP::Il2CppObject* destination) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CopyTo", 2);
					return __bnm__method__(original, destination);
				}
				
			};
		}
	}
}
