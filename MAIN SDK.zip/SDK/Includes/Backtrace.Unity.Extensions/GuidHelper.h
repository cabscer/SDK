#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Extensions {
			class GuidHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Extensions", "GuidHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.Guid */
				template <typename T = BNM::IL2CPP::Il2CppObject*> static T FromLong(int64_t source) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromLong", 1);
					return __bnm__method__(source);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T IsNullOrEmpty(BNM::Structures::Mono::String* guid) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsNullOrEmpty", 1);
					return __bnm__method__(guid);
				}
				
			};
		}
	}
}
