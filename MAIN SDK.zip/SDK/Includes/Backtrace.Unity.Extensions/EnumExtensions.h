#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Extensions {
			class EnumExtensions

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Extensions", "EnumExtensions", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T HasFlag(BNM::IL2CPP::Il2CppObject* variable, BNM::IL2CPP::Il2CppObject* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HasFlag", 2);
					return __bnm__method__(variable, $value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T HasAllFlags(void* rawSource) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HasAllFlags", 1);
					return __bnm__method__(rawSource);
				}
				
			};
		}
	}
}
