#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AdaptivePerformance

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AdaptivePerformance", BNM::Image("Unity.XR.Oculus.dll"));
		}
		
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_GPUAppTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_GPUAppTime", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_GPUCompositorTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_GPUCompositorTime", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_MotionToPhoton() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MotionToPhoton", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_RefreshRate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RefreshRate", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_BatteryTemp() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BatteryTemp", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_BatteryLevel() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BatteryLevel", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T get_PowerSavingMode() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_PowerSavingMode", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_AdaptivePerformanceScale() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_AdaptivePerformanceScale", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T get_CPULevel() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_CPULevel", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T get_GPULevel() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_GPULevel", 0);
			return __bnm__method__();
		}
		
	};
}
