#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AIUpdatePostScript
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AIUpdatePostScript", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		
	};
}
