#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct ActionEventPtr
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "ActionEventPtr", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* m_State;
		void* /*POINTER*/ m_Ptr;
		
		
	};
}
