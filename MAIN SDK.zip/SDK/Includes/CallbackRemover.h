#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class CallbackRemover : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "CallbackRemover", BNM::Image("Oculus.VR.dll"));
		}
		
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T Invoke(BNM::IL2CPP::Il2CppObject* guid) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](guid);
		}
		/* @brief Orig Type: System.IAsyncResult */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T BeginInvoke(BNM::IL2CPP::Il2CppObject* guid, BNM::IL2CPP::Il2CppObject* callback, BNM::IL2CPP::Il2CppObject* $object) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BeginInvoke", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](guid, callback, $object);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EndInvoke(BNM::IL2CPP::Il2CppObject* result) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EndInvoke", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](result);
		}
		
	};
}
