#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Awaiter
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Awaiter", BNM::Image("Oculus.VR.dll"));
		}
		
		void* /*GENERICTYPE*/ _task;
		
		
	};
}
