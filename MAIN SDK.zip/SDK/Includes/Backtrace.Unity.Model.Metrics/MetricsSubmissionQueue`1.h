#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Metrics {
				class MetricsSubmissionQueue$1 : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Metrics", "MetricsSubmissionQueue`1", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.UInt32 */
					template <typename T = BNM::Types::uint> T $MaximumEvents$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$MaximumEvents$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.UInt32 */
					void set_$MaximumEvents$(BNM::Types::uint value) {
						static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("$MaximumEvents$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> static T DefaultTimeInSecBetweenRequests() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultTimeInSecBetweenRequests");
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Int32 */
					static void set_DefaultTimeInSecBetweenRequests(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultTimeInSecBetweenRequests");
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T _name() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_name");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set__name(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_name");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.Metrics.MetricsSubmissionJob`1<T>> */
					template <typename T = void* /*GENERICTYPE*/> T _submissionJobs() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_submissionJobs");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.Metrics.MetricsSubmissionJob`1<T>> */
					void set__submissionJobs(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_submissionJobs");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Collections.Generic.LinkedList`1<T> */
					template <typename T = void* /*GENERICTYPE*/> T Events() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Events");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.LinkedList`1<T> */
					void set_Events(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("Events");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T _numberOfDroppedRequests() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_numberOfDroppedRequests");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Int32 */
					void set__numberOfDroppedRequests(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_numberOfDroppedRequests");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.IBacktraceHttpClient */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T RequestHandler() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RequestHandler");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.IBacktraceHttpClient */
					void set_RequestHandler(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("RequestHandler");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T $SubmissionUrl$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$SubmissionUrl$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_$SubmissionUrl$(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$SubmissionUrl$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T _applicationName() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_applicationName");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set__applicationName(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_applicationName");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T _applicationVersion() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_applicationVersion");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set__applicationVersion(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_applicationVersion");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T get_Count() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Count", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.UInt32 */
					template <typename T = BNM::Types::uint> T get_MaximumEvents() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaximumEvents", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_MaximumEvents(BNM::Types::uint $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_MaximumEvents", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_SubmissionUrl() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_SubmissionUrl", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_SubmissionUrl(BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_SubmissionUrl", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T ReachedLimit() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReachedLimit", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T ShouldProcessEvent(BNM::Structures::Mono::String* name) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldProcessEvent", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](name);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T StartWithEvent(BNM::Structures::Mono::String* eventName) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StartWithEvent", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](eventName);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Send() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T SendPayload(void* /*GENERICTYPE*/ events, BNM::Types::uint attempts) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendPayload", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](events, attempts);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T SendPendingEvents(float time) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendPendingEvents", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](time);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T OnMaximumAttemptsReached(void* /*GENERICTYPE*/ events) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnMaximumAttemptsReached", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](events);
					}
					/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Json.BacktraceJObject> */
					template <typename T = void* /*GENERICTYPE*/> T GetEventsPayload(void* /*GENERICTYPE*/ events) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetEventsPayload", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](events);
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T CreateJsonPayload(void* /*GENERICTYPE*/ events) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateJsonPayload", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](events);
					}
					/* @brief Orig Type: System.Double */
					template <typename T = double> T CalculateNextRetryTime(BNM::Types::uint attemps) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CalculateNextRetryTime", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attemps);
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T CreatePayloadMetadata() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreatePayloadMetadata", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T OnRequestCompleted() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnRequestCompleted", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
