#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Metrics {
				class SummedEvent : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Metrics", "SummedEvent", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> static T MetricGroupName() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MetricGroupName");
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					static void set_MetricGroupName(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("MetricGroupName");
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
					template <typename T = void* /*GENERICTYPE*/> T Attributes() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Attributes");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
					void set_Attributes(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("Attributes");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T ToJson(void* /*GENERICTYPE*/ scopedAttributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](scopedAttributes);
					}
					
				};
			}
		}
	}
}
