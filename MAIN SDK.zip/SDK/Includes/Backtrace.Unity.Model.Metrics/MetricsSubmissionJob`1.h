#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Metrics {
				class MetricsSubmissionJob$1 : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Metrics", "MetricsSubmissionJob`1", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.Double */
					template <typename T = double> T $NextInvokeTime$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$NextInvokeTime$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Double */
					void set_$NextInvokeTime$(double value) {
						static BNM::Field<double> __bnm__field__ = StaticClass().GetField("$NextInvokeTime$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Collections.Generic.ICollection`1<T> */
					template <typename T = void* /*GENERICTYPE*/> T $Events$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Events$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.ICollection`1<T> */
					void set_$Events$(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$Events$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.UInt32 */
					template <typename T = BNM::Types::uint> T $NumberOfAttempts$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$NumberOfAttempts$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.UInt32 */
					void set_$NumberOfAttempts$(BNM::Types::uint value) {
						static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("$NumberOfAttempts$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.Double */
					template <typename T = double> T get_NextInvokeTime() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NextInvokeTime", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_NextInvokeTime(double $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_NextInvokeTime", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Collections.Generic.ICollection`1<T> */
					template <typename T = void* /*GENERICTYPE*/> T get_Events() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Events", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Events(void* /*GENERICTYPE*/ $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Events", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.UInt32 */
					template <typename T = BNM::Types::uint> T get_NumberOfAttempts() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NumberOfAttempts", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_NumberOfAttempts(BNM::Types::uint $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_NumberOfAttempts", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					
				};
			}
		}
	}
}
