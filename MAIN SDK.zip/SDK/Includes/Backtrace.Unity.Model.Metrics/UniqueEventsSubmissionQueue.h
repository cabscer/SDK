#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Metrics {
				class UniqueEventsSubmissionQueue : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Metrics", "UniqueEventsSubmissionQueue", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> static T Name() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Name");
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					static void set_Name(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Name");
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.JsonData.AttributeProvider */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T _attributeProvider() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_attributeProvider");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.JsonData.AttributeProvider */
					void set__attributeProvider(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_attributeProvider");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.Void */
					template <typename T = void> T StartWithEvent(BNM::Structures::Mono::String* eventName) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StartWithEvent", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](eventName);
					}
					/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Json.BacktraceJObject> */
					template <typename T = void* /*GENERICTYPE*/> T GetEventsPayload(void* /*GENERICTYPE*/ events) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetEventsPayload", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](events);
					}
					/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
					template <typename T = void* /*GENERICTYPE*/> T GetUniqueEventAttributes() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetUniqueEventAttributes", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
