#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Metrics {
				class EventAggregationBase : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Metrics", "EventAggregationBase", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> static T TimestampName() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TimestampName");
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					static void set_TimestampName(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("TimestampName");
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> static T AttributesName() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AttributesName");
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					static void set_AttributesName(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("AttributesName");
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Int64 */
					template <typename T = int64_t> T $Timestamp$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Timestamp$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Int64 */
					void set_$Timestamp$(int64_t value) {
						static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("$Timestamp$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T $Name$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Name$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_$Name$(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$Name$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.Int64 */
					template <typename T = int64_t> T get_Timestamp() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Timestamp", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Timestamp(int64_t $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Timestamp", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_Name() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Name", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Name(BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Name", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T ToBaseObject(void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToBaseObject", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
					}
					
				};
			}
		}
	}
}
