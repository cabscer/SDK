#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AxisData : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AxisData", BNM::Image("Oculus.Interaction.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.Object */
		template <typename T = BNM::UnityEngine::Object*> T _activeState() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_activeState");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Object */
		void set__activeState(BNM::UnityEngine::Object* value) {
			static BNM::Field<BNM::UnityEngine::Object*> __bnm__field__ = StaticClass().GetField("_activeState");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Oculus.Interaction.IActiveState */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ActiveState() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ActiveState");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Oculus.Interaction.IActiveState */
		void set_ActiveState(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("ActiveState");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Object */
		template <typename T = BNM::UnityEngine::Object*> T _axis() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_axis");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Object */
		void set__axis(BNM::UnityEngine::Object* value) {
			static BNM::Field<BNM::UnityEngine::Object*> __bnm__field__ = StaticClass().GetField("_axis");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Oculus.Interaction.Input.IAxis1D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Axis() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Axis");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Oculus.Interaction.Input.IAxis1D */
		void set_Axis(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Axis");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Initialize() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Validate(BNM::IL2CPP::Il2CppObject* context) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Validate", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](context);
		}
		
	};
}
