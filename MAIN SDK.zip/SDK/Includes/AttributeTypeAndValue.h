#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AttributeTypeAndValue : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AttributeTypeAndValue", BNM::Image("Mono.Security.dll"));
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T oid() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("oid");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_oid(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("oid");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T attrValue() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("attrValue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_attrValue(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("attrValue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T upperBound() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("upperBound");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_upperBound(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("upperBound");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Byte */
		template <typename T = BNM::Types::byte> T encoding() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("encoding");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Byte */
		void set_encoding(BNM::Types::byte value) {
			static BNM::Field<BNM::Types::byte> __bnm__field__ = StaticClass().GetField("encoding");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T get_Value() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Value", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_Value(BNM::Structures::Mono::String* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Value", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: Mono.Security.ASN1 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_ASN1() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ASN1", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: Mono.Security.ASN1 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetASN1(BNM::Types::byte encoding) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetASN1", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](encoding);
		}
		/* @brief Orig Type: Mono.Security.ASN1 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetASN1_1() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetASN1", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Byte[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T GetBytes(BNM::Types::byte encoding) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetBytes", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](encoding);
		}
		/* @brief Orig Type: System.Byte[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T GetBytes_1() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetBytes", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Byte */
		template <typename T = BNM::Types::byte> T SelectBestEncoding() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SelectBestEncoding", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
