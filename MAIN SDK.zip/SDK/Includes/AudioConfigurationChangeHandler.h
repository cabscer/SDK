#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AudioConfigurationChangeHandler : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AudioConfigurationChangeHandler", BNM::Image("UnityEngine.AudioModule.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Invoke(bool deviceWasChanged) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](deviceWasChanged);
		}
		
	};
}
