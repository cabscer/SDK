#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AsyncUploadTimeSlicedUpdate
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AsyncUploadTimeSlicedUpdate", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		
	};
}
