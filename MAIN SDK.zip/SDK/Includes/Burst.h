#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Burst
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Burst", BNM::Image("UnityEngine.ParticleSystemModule.dll"));
		}
		
		float m_Time;
		BNM::IL2CPP::Il2CppObject* m_Count;
		int m_RepeatCount;
		float m_RepeatInterval;
		float m_InvProbability;
		
		
	};
}
