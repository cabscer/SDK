#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CameraDeviceIntrinsicsParameters
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CameraDeviceIntrinsicsParameters", BNM::Image("Oculus.VR.dll"));
		}
		
		float fx;
		float fy;
		float cx;
		float cy;
		double disto0;
		double disto1;
		double disto2;
		double disto3;
		double disto4;
		float v_fov;
		float h_fov;
		float d_fov;
		int w;
		int h;
		
		
	};
}
