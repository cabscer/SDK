#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $Bits$e__FixedBuffer
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "<Bits>e__FixedBuffer", BNM::Image("Unity.Burst.dll"));
		}
		
		BNM::Types::ushort FixedElementField;
		
		
	};
}
