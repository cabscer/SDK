#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Runtime {
			namespace Native {
				namespace Base {
					class NativeClientBase : public BNM::IL2CPP::Il2CppObject
					{
						public:
						static BNM::Class StaticClass() {
							return BNM::Class("Backtrace.Unity.Runtime.Native.Base", "NativeClientBase", BNM::Image("Backtrace.Unity.dll"));
						}
						
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T AnrMessage() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AnrMessage");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_AnrMessage(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("AnrMessage");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T HangType() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("HangType");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_HangType(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("HangType");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T CrashType() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CrashType");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_CrashType(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("CrashType");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T ErrorTypeAttribute() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ErrorTypeAttribute");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_ErrorTypeAttribute(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ErrorTypeAttribute");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Int32 */
						template <typename T = int> T AnrWatchdogTimeout() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AnrWatchdogTimeout");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Int32 */
						void set_AnrWatchdogTimeout(int value) {
							static BNM::Field<int> __bnm__field__ = StaticClass().GetField("AnrWatchdogTimeout");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T LogAnr() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LogAnr");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Boolean */
						void set_LogAnr(bool value) {
							static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("LogAnr");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Single */
						template <typename T = float> T LastUpdateTime() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LastUpdateTime");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Single */
						void set_LastUpdateTime(float value) {
							static BNM::Field<float> __bnm__field__ = StaticClass().GetField("LastUpdateTime");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T PreventAnr() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PreventAnr");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Boolean */
						void set_PreventAnr(bool value) {
							static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("PreventAnr");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T StopAnr() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("StopAnr");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Boolean */
						void set_StopAnr(bool value) {
							static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("StopAnr");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Threading.Thread */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T AnrThread() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AnrThread");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Threading.Thread */
						void set_AnrThread(BNM::IL2CPP::Il2CppObject* value) {
							static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("AnrThread");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T CaptureNativeCrashes() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CaptureNativeCrashes");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Boolean */
						void set_CaptureNativeCrashes(bool value) {
							static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("CaptureNativeCrashes");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T HandlerANR() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("HandlerANR");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Boolean */
						void set_HandlerANR(bool value) {
							static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("HandlerANR");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: Backtrace.Unity.Model.BacktraceConfiguration */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T _configuration() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_configuration");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: Backtrace.Unity.Model.BacktraceConfiguration */
						void set__configuration(BNM::IL2CPP::Il2CppObject* value) {
							static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_configuration");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbs */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T _breadcrumbs() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_breadcrumbs");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbs */
						void set__breadcrumbs(BNM::IL2CPP::Il2CppObject* value) {
							static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_breadcrumbs");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T _shouldLogAnrsInBreadcrumbs() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_shouldLogAnrsInBreadcrumbs");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Boolean */
						void set__shouldLogAnrsInBreadcrumbs(bool value) {
							static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_shouldLogAnrsInBreadcrumbs");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Object */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T _lockObject() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_lockObject");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Object */
						void set__lockObject(BNM::IL2CPP::Il2CppObject* value) {
							static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_lockObject");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						
						/* @brief Orig Type: System.Void */
						template <typename T = void> T Update(float time) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](time);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T OnAnrDetection() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnAnrDetection", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T PauseAnrThread(bool stopAnr) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PauseAnrThread", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](stopAnr);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T Disable() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Disable", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T ShouldStoreAnrBreadcrumbs() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldStoreAnrBreadcrumbs", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						
					};
				}
			}
		}
	}
}
