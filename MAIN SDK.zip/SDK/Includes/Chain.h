#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Chain : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Chain", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Root() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Root");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_Root(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Root");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T Exclusion() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Exclusion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform[] */
		void set_Exclusion(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("Exclusion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EffectorReaction() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EffectorReaction");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EffectorReaction(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EffectorReaction");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T LooseRoot() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LooseRoot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_LooseRoot(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("LooseRoot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.SharedBoingParams */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ParamsOverride() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ParamsOverride");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.SharedBoingParams */
		void set_ParamsOverride(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("ParamsOverride");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingBones/Chain/CurveType */
		template <typename T = int> T AnimationBlendCurveType() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AnimationBlendCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBones/Chain/CurveType */
		void set_AnimationBlendCurveType(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("AnimationBlendCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AnimationCurve */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T AnimationBlendCustomCurve() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AnimationBlendCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AnimationCurve */
		void set_AnimationBlendCustomCurve(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("AnimationBlendCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingBones/Chain/CurveType */
		template <typename T = int> T LengthStiffnessCurveType() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LengthStiffnessCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBones/Chain/CurveType */
		void set_LengthStiffnessCurveType(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("LengthStiffnessCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AnimationCurve */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T LengthStiffnessCustomCurve() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LengthStiffnessCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AnimationCurve */
		void set_LengthStiffnessCustomCurve(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("LengthStiffnessCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingBones/Chain/CurveType */
		template <typename T = int> T PoseStiffnessCurveType() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PoseStiffnessCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBones/Chain/CurveType */
		void set_PoseStiffnessCurveType(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("PoseStiffnessCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AnimationCurve */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T PoseStiffnessCustomCurve() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PoseStiffnessCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AnimationCurve */
		void set_PoseStiffnessCustomCurve(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("PoseStiffnessCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxBendAngleCap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxBendAngleCap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxBendAngleCap(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxBendAngleCap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingBones/Chain/CurveType */
		template <typename T = int> T BendAngleCapCurveType() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BendAngleCapCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBones/Chain/CurveType */
		void set_BendAngleCapCurveType(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("BendAngleCapCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AnimationCurve */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T BendAngleCapCustomCurve() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BendAngleCapCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AnimationCurve */
		void set_BendAngleCapCustomCurve(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("BendAngleCapCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxCollisionRadius() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxCollisionRadius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxCollisionRadius(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxCollisionRadius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingBones/Chain/CurveType */
		template <typename T = int> T CollisionRadiusCurveType() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CollisionRadiusCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBones/Chain/CurveType */
		void set_CollisionRadiusCurveType(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("CollisionRadiusCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AnimationCurve */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T CollisionRadiusCustomCurve() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CollisionRadiusCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AnimationCurve */
		void set_CollisionRadiusCustomCurve(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("CollisionRadiusCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnableBoingKitCollision() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnableBoingKitCollision");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnableBoingKitCollision(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnableBoingKitCollision");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnableUnityCollision() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnableUnityCollision");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnableUnityCollision(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnableUnityCollision");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnableInterChainCollision() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnableInterChainCollision");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnableInterChainCollision(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnableInterChainCollision");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T Gravity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Gravity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_Gravity(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("Gravity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Bounds */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Bounds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Bounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Bounds */
		void set_Bounds(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Bounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingBones/Chain/CurveType */
		template <typename T = int> T SquashAndStretchCurveType() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SquashAndStretchCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBones/Chain/CurveType */
		void set_SquashAndStretchCurveType(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("SquashAndStretchCurveType");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AnimationCurve */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T SquashAndStretchCustomCurve() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SquashAndStretchCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AnimationCurve */
		void set_SquashAndStretchCustomCurve(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("SquashAndStretchCustomCurve");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxSquash() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxSquash");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxSquash(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxSquash");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxStretch() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxStretch");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxStretch(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxStretch");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_scannedRoot() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_scannedRoot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_m_scannedRoot(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_scannedRoot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T m_scannedExclusion() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_scannedExclusion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform[] */
		void set_m_scannedExclusion(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("m_scannedExclusion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_hierarchyHash() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_hierarchyHash");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_hierarchyHash(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_hierarchyHash");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxLengthFromRoot() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxLengthFromRoot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxLengthFromRoot(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxLengthFromRoot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T EvaluateCurve(int type, float t, BNM::IL2CPP::Il2CppObject* curve) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EvaluateCurve", 3);
			return __bnm__method__(type, t, curve);
		}
		
	};
}
