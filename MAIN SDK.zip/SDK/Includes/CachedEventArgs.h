#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class CachedEventArgs : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "CachedEventArgs", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Net.Sockets.Socket/TaskSocketAsyncEventArgs`1<System.Net.Sockets.Socket> */
		template <typename T = void* /*GENERICTYPE*/> T TaskAccept() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TaskAccept");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Net.Sockets.Socket/TaskSocketAsyncEventArgs`1<System.Net.Sockets.Socket> */
		void set_TaskAccept(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("TaskAccept");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Net.Sockets.Socket/Int32TaskSocketAsyncEventArgs */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T TaskReceive() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TaskReceive");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Net.Sockets.Socket/Int32TaskSocketAsyncEventArgs */
		void set_TaskReceive(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("TaskReceive");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Net.Sockets.Socket/Int32TaskSocketAsyncEventArgs */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T TaskSend() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TaskSend");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Net.Sockets.Socket/Int32TaskSocketAsyncEventArgs */
		void set_TaskSend(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("TaskSend");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Net.Sockets.Socket/AwaitableSocketAsyncEventArgs */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ValueTaskReceive() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ValueTaskReceive");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Net.Sockets.Socket/AwaitableSocketAsyncEventArgs */
		void set_ValueTaskReceive(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("ValueTaskReceive");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Net.Sockets.Socket/AwaitableSocketAsyncEventArgs */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ValueTaskSend() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ValueTaskSend");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Net.Sockets.Socket/AwaitableSocketAsyncEventArgs */
		void set_ValueTaskSend(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("ValueTaskSend");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		
	};
}
