#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Cache
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Cache", BNM::Image("Unity.InputSystem.dll"));
		}
		
		void* /*GENERICTYPE*/ table;
		
		
	};
}
