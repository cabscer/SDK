#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Buf24
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Buf24", BNM::Image("mscorlib.dll"));
		}
		
		BNM::Types::uint U0;
		BNM::Types::uint U1;
		BNM::Types::uint U2;
		BNM::Types::uint U3;
		BNM::Types::uint U4;
		BNM::Types::uint U5;
		BNM::Types::ulong ulo64LE;
		BNM::Types::ulong umid64LE;
		BNM::Types::ulong uhigh64LE;
		
		
	};
}
