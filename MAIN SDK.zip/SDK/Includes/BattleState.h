#pragma once
#include <BNMIncludes.hpp>

#undef NotEnoughPlayers
#undef GameEnd
#undef GameEndWaiting
#undef StartCountdown
#undef CountingDownToStart
#undef GameStart
#undef GameRunning
namespace GlobalNamespace {
	enum class BattleState : int
	{
		NotEnoughPlayers = 0,
		GameEnd = 1,
		GameEndWaiting = 2,
		StartCountdown = 3,
		CountingDownToStart = 4,
		GameStart = 5,
		GameRunning = 6
	};
}
