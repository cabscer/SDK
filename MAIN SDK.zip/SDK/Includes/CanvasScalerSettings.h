#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class CanvasScalerSettings : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "CanvasScalerSettings", BNM::Image("Unity.XR.Interaction.Toolkit.dll"));
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T $present$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$present$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_$present$(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$present$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_DefaultSpriteDPI() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_DefaultSpriteDPI");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_DefaultSpriteDPI(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_DefaultSpriteDPI");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_DynamicPixelsPerUnit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_DynamicPixelsPerUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_DynamicPixelsPerUnit(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_DynamicPixelsPerUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_FallbackScreenDPI() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_FallbackScreenDPI");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_FallbackScreenDPI(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_FallbackScreenDPI");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_MatchWidthOrHeight() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_MatchWidthOrHeight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_MatchWidthOrHeight(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_MatchWidthOrHeight");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UI.CanvasScaler/Unit */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_PhysicalUnit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_PhysicalUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UI.CanvasScaler/Unit */
		void set_m_PhysicalUnit(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_PhysicalUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_ReferencePixelsPerUnit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ReferencePixelsPerUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_ReferencePixelsPerUnit(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_ReferencePixelsPerUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector2 */
		template <typename T = BNM::Structures::Unity::Vector2> T m_ReferenceResolution() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ReferenceResolution");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector2 */
		void set_m_ReferenceResolution(BNM::Structures::Unity::Vector2 value) {
			static BNM::Field<BNM::Structures::Unity::Vector2> __bnm__field__ = StaticClass().GetField("m_ReferenceResolution");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_ScaleFactor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ScaleFactor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_ScaleFactor(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_ScaleFactor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UI.CanvasScaler/ScreenMatchMode */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_ScreenMatchMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ScreenMatchMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UI.CanvasScaler/ScreenMatchMode */
		void set_m_ScreenMatchMode(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_ScreenMatchMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UI.CanvasScaler/ScaleMode */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_UiScaleMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_UiScaleMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UI.CanvasScaler/ScaleMode */
		void set_m_UiScaleMode(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_UiScaleMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_present() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_present", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_present(bool $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_present", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T CopyFrom(BNM::IL2CPP::Il2CppObject* source) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CopyFrom", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](source);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T CopyTo(BNM::IL2CPP::Il2CppObject* dest) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CopyTo", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dest);
		}
		
	};
}
