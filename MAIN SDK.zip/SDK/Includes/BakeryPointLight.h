#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryPointLight : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryPointLight", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T UID() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_UID(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("UID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Color */
		template <typename T = BNM::Structures::Unity::Color> T color() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("color");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Color */
		void set_color(BNM::Structures::Unity::Color value) {
			static BNM::Field<BNM::Structures::Unity::Color> __bnm__field__ = StaticClass().GetField("color");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T intensity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("intensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_intensity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("intensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T shadowSpread() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("shadowSpread");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_shadowSpread(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("shadowSpread");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T cutoff() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cutoff");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_cutoff(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("cutoff");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T realisticFalloff() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("realisticFalloff");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_realisticFalloff(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("realisticFalloff");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T samples() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("samples");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_samples(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("samples");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryPointLight/ftLightProjectionMode */
		template <typename T = int> T projMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("projMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryPointLight/ftLightProjectionMode */
		void set_projMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("projMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T cookie() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cookie");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_cookie(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("cookie");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T angle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("angle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_angle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("angle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T innerAngle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("innerAngle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_innerAngle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("innerAngle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Cubemap */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T cubemap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cubemap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Cubemap */
		void set_cubemap(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("cubemap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Object */
		template <typename T = BNM::UnityEngine::Object*> T iesFile() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("iesFile");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Object */
		void set_iesFile(BNM::UnityEngine::Object* value) {
			static BNM::Field<BNM::UnityEngine::Object*> __bnm__field__ = StaticClass().GetField("iesFile");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T bitmask() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bitmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_bitmask(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("bitmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T bakeToIndirect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bakeToIndirect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_bakeToIndirect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("bakeToIndirect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T shadowmask() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("shadowmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_shadowmask(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("shadowmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T indirectIntensity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("indirectIntensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_indirectIntensity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("indirectIntensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T falloffMinRadius() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("falloffMinRadius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_falloffMinRadius(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("falloffMinRadius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T shadowmaskGroupID() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("shadowmaskGroupID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_shadowmaskGroupID(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("shadowmaskGroupID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryPointLight/Direction */
		template <typename T = int> T directionMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("directionMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryPointLight/Direction */
		void set_directionMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("directionMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T GIZMO_MAXSIZE() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("GIZMO_MAXSIZE");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_GIZMO_MAXSIZE(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("GIZMO_MAXSIZE");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T GIZMO_SCALE() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("GIZMO_SCALE");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_GIZMO_SCALE(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("GIZMO_SCALE");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T screenRadius() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("screenRadius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_screenRadius(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("screenRadius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T lightsChanged() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lightsChanged");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_lightsChanged(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("lightsChanged");
			__bnm__field__.Set(value);
		}
		
		
	};
}
