#pragma once
#include <BNMIncludes.hpp>

#undef Info
#undef Warning
#undef Error
namespace GlobalNamespace {
	enum class BurstLogType : int
	{
		Info = 0,
		Warning = 1,
		Error = 2
	};
}
