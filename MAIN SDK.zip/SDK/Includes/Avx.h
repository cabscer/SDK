#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Avx

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Avx", BNM::Image("Unity.Burst.dll"));
		}
		
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T get_IsAvxSupported() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsAvxSupported", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_add_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_add_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_add_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_add_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_addsub_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_addsub_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_addsub_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_addsub_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_and_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_and_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_and_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_and_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_andnot_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_andnot_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_andnot_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_andnot_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_blend_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_blend_pd", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_blend_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_blend_ps", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_blendv_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_blendv_pd", 3);
			return __bnm__method__(a, b, mask);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_blendv_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_blendv_ps", 3);
			return __bnm__method__(a, b, mask);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_div_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_div_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_div_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_div_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_dp_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_dp_ps", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hadd_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hadd_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hadd_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hadd_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hsub_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hsub_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_hsub_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_hsub_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_max_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_max_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_max_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_max_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_min_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_min_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_min_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_min_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mul_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mul_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_mul_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_mul_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_or_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_or_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_or_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_or_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_shuffle_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_shuffle_pd", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_shuffle_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_shuffle_ps", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sub_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sub_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sub_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sub_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_xor_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_xor_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_xor_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_xor_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T cmp_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("cmp_pd", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmp_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmp_pd", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T cmp_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("cmp_ps", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cmp_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cmp_ps", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T cmp_sd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("cmp_sd", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T cmp_ss(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("cmp_ss", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepi32_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepi32_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtepi32_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtepi32_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtpd_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtpd_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtps_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtps_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtps_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtps_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvttpd_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvttpd_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvtpd_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtpd_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_cvttps_epi32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvttps_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T mm256_cvtss_f32(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_cvtss_f32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_extractf128_ps(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_extractf128_ps", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_extractf128_pd(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_extractf128_pd", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_extractf128_si256(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_extractf128_si256", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_zeroall() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_zeroall", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_zeroupper() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_zeroupper", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T permutevar_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("permutevar_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permutevar_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permutevar_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T permute_ps(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("permute_ps", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permute_ps(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permute_ps", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T permutevar_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("permutevar_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permutevar_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permutevar_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permute_pd(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permute_pd", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T permute_pd(BNM::IL2CPP::Il2CppObject* a, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("permute_pd", 2);
			return __bnm__method__(a, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T Select4(BNM::IL2CPP::Il2CppObject* src1, BNM::IL2CPP::Il2CppObject* src2, int control) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Select4", 3);
			return __bnm__method__(src1, src2, control);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permute2f128_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permute2f128_ps", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permute2f128_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permute2f128_pd", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_permute2f128_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_permute2f128_si256", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcast_ss(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcast_ss", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T broadcast_ss(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("broadcast_ss", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcast_sd(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcast_sd", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcast_ps(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcast_ps", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_broadcast_pd(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_broadcast_pd", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_insertf128_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_insertf128_ps", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_insertf128_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_insertf128_pd", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_insertf128_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b, int imm8) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_insertf128_si256", 3);
			return __bnm__method__(a, b, imm8);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_load_ps(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_load_ps", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_store_ps(void* /*POINTER*/ ptr, BNM::IL2CPP::Il2CppObject* val) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_store_ps", 2);
			return __bnm__method__(ptr, val);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_load_pd(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_load_pd", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_store_pd(void* /*POINTER*/ ptr, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_store_pd", 2);
			return __bnm__method__(ptr, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_loadu_pd(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_loadu_pd", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_storeu_pd(void* /*POINTER*/ ptr, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_storeu_pd", 2);
			return __bnm__method__(ptr, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_loadu_ps(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_loadu_ps", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_storeu_ps(void* /*POINTER*/ ptr, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_storeu_ps", 2);
			return __bnm__method__(ptr, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_load_si256(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_load_si256", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_store_si256(void* /*POINTER*/ ptr, BNM::IL2CPP::Il2CppObject* v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_store_si256", 2);
			return __bnm__method__(ptr, v);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_loadu_si256(void* /*POINTER*/ ptr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_loadu_si256", 1);
			return __bnm__method__(ptr);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_storeu_si256(void* /*POINTER*/ ptr, BNM::IL2CPP::Il2CppObject* v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_storeu_si256", 2);
			return __bnm__method__(ptr, v);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_loadu2_m128(void* /*POINTER*/ hiaddr, void* /*POINTER*/ loaddr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_loadu2_m128", 2);
			return __bnm__method__(hiaddr, loaddr);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_loadu2_m128d(void* /*POINTER*/ hiaddr, void* /*POINTER*/ loaddr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_loadu2_m128d", 2);
			return __bnm__method__(hiaddr, loaddr);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_loadu2_m128i(void* /*POINTER*/ hiaddr, void* /*POINTER*/ loaddr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_loadu2_m128i", 2);
			return __bnm__method__(hiaddr, loaddr);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_m128(BNM::IL2CPP::Il2CppObject* hi, BNM::IL2CPP::Il2CppObject* lo) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_m128", 2);
			return __bnm__method__(hi, lo);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_storeu2_m128(void* /*POINTER*/ hiaddr, void* /*POINTER*/ loaddr, BNM::IL2CPP::Il2CppObject* val) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_storeu2_m128", 3);
			return __bnm__method__(hiaddr, loaddr, val);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_storeu2_m128d(void* /*POINTER*/ hiaddr, void* /*POINTER*/ loaddr, BNM::IL2CPP::Il2CppObject* val) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_storeu2_m128d", 3);
			return __bnm__method__(hiaddr, loaddr, val);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_storeu2_m128i(void* /*POINTER*/ hiaddr, void* /*POINTER*/ loaddr, BNM::IL2CPP::Il2CppObject* val) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_storeu2_m128i", 3);
			return __bnm__method__(hiaddr, loaddr, val);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T maskload_pd(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("maskload_pd", 2);
			return __bnm__method__(mem_addr, mask);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_maskload_pd(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maskload_pd", 2);
			return __bnm__method__(mem_addr, mask);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T maskstore_pd(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("maskstore_pd", 3);
			return __bnm__method__(mem_addr, mask, a);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_maskstore_pd(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maskstore_pd", 3);
			return __bnm__method__(mem_addr, mask, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T maskload_ps(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("maskload_ps", 2);
			return __bnm__method__(mem_addr, mask);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_maskload_ps(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maskload_ps", 2);
			return __bnm__method__(mem_addr, mask);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T maskstore_ps(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("maskstore_ps", 3);
			return __bnm__method__(mem_addr, mask, a);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_maskstore_ps(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* mask, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_maskstore_ps", 3);
			return __bnm__method__(mem_addr, mask, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_movehdup_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_movehdup_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_moveldup_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_moveldup_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_movedup_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_movedup_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_lddqu_si256(void* /*POINTER*/ mem_addr) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_lddqu_si256", 1);
			return __bnm__method__(mem_addr);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_stream_si256(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_stream_si256", 2);
			return __bnm__method__(mem_addr, a);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_stream_pd(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_stream_pd", 2);
			return __bnm__method__(mem_addr, a);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T mm256_stream_ps(void* /*POINTER*/ mem_addr, BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_stream_ps", 2);
			return __bnm__method__(mem_addr, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_rcp_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_rcp_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_rsqrt_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_rsqrt_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sqrt_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sqrt_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_sqrt_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_sqrt_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_round_pd(BNM::IL2CPP::Il2CppObject* a, int rounding) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_round_pd", 2);
			return __bnm__method__(a, rounding);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_ceil_pd(BNM::IL2CPP::Il2CppObject* val) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_ceil_pd", 1);
			return __bnm__method__(val);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_floor_pd(BNM::IL2CPP::Il2CppObject* val) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_floor_pd", 1);
			return __bnm__method__(val);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_round_ps(BNM::IL2CPP::Il2CppObject* a, int rounding) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_round_ps", 2);
			return __bnm__method__(a, rounding);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_ceil_ps(BNM::IL2CPP::Il2CppObject* val) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_ceil_ps", 1);
			return __bnm__method__(val);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_floor_ps(BNM::IL2CPP::Il2CppObject* val) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_floor_ps", 1);
			return __bnm__method__(val);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpackhi_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpackhi_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpacklo_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpacklo_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpackhi_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpackhi_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_unpacklo_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_unpacklo_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testz_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testz_si256", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testc_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testc_si256", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testnzc_si256(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testnzc_si256", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testz_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testz_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testc_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testc_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testnzc_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testnzc_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T testz_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("testz_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T testc_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("testc_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T testnzc_pd(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("testnzc_pd", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testz_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testz_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testc_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testc_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_testnzc_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_testnzc_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T testz_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("testz_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T testc_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("testc_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T testnzc_ps(BNM::IL2CPP::Il2CppObject* a, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("testnzc_ps", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_movemask_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_movemask_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_movemask_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_movemask_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setzero_pd() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setzero_pd", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setzero_ps() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setzero_ps", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setzero_si256() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setzero_si256", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_pd(double d, double c, double b, double a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_pd", 4);
			return __bnm__method__(d, c, b, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_ps(float e7, float e6, float e5, float e4, float e3, float e2, float e1, float e0) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_ps", 8);
			return __bnm__method__(e7, e6, e5, e4, e3, e2, e1, e0);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_epi8(BNM::Types::byte e31_, BNM::Types::byte e30_, BNM::Types::byte e29_, BNM::Types::byte e28_, BNM::Types::byte e27_, BNM::Types::byte e26_, BNM::Types::byte e25_, BNM::Types::byte e24_, BNM::Types::byte e23_, BNM::Types::byte e22_, BNM::Types::byte e21_, BNM::Types::byte e20_, BNM::Types::byte e19_, BNM::Types::byte e18_, BNM::Types::byte e17_, BNM::Types::byte e16_, BNM::Types::byte e15_, BNM::Types::byte e14_, BNM::Types::byte e13_, BNM::Types::byte e12_, BNM::Types::byte e11_, BNM::Types::byte e10_, BNM::Types::byte e9_, BNM::Types::byte e8_, BNM::Types::byte e7_, BNM::Types::byte e6_, BNM::Types::byte e5_, BNM::Types::byte e4_, BNM::Types::byte e3_, BNM::Types::byte e2_, BNM::Types::byte e1_, BNM::Types::byte e0_) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_epi8", 32);
			return __bnm__method__(e31_, e30_, e29_, e28_, e27_, e26_, e25_, e24_, e23_, e22_, e21_, e20_, e19_, e18_, e17_, e16_, e15_, e14_, e13_, e12_, e11_, e10_, e9_, e8_, e7_, e6_, e5_, e4_, e3_, e2_, e1_, e0_);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_epi16(short e15_, short e14_, short e13_, short e12_, short e11_, short e10_, short e9_, short e8_, short e7_, short e6_, short e5_, short e4_, short e3_, short e2_, short e1_, short e0_) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_epi16", 16);
			return __bnm__method__(e15_, e14_, e13_, e12_, e11_, e10_, e9_, e8_, e7_, e6_, e5_, e4_, e3_, e2_, e1_, e0_);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_epi32(int e7, int e6, int e5, int e4, int e3, int e2, int e1, int e0) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_epi32", 8);
			return __bnm__method__(e7, e6, e5, e4, e3, e2, e1, e0);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_epi64x(int64_t e3, int64_t e2, int64_t e1, int64_t e0) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_epi64x", 4);
			return __bnm__method__(e3, e2, e1, e0);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_m128d(BNM::IL2CPP::Il2CppObject* hi, BNM::IL2CPP::Il2CppObject* lo) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_m128d", 2);
			return __bnm__method__(hi, lo);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set_m128i(BNM::IL2CPP::Il2CppObject* hi, BNM::IL2CPP::Il2CppObject* lo) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set_m128i", 2);
			return __bnm__method__(hi, lo);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_pd(double d, double c, double b, double a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_pd", 4);
			return __bnm__method__(d, c, b, a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_ps(float e7, float e6, float e5, float e4, float e3, float e2, float e1, float e0) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_ps", 8);
			return __bnm__method__(e7, e6, e5, e4, e3, e2, e1, e0);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_epi8(BNM::Types::byte e31_, BNM::Types::byte e30_, BNM::Types::byte e29_, BNM::Types::byte e28_, BNM::Types::byte e27_, BNM::Types::byte e26_, BNM::Types::byte e25_, BNM::Types::byte e24_, BNM::Types::byte e23_, BNM::Types::byte e22_, BNM::Types::byte e21_, BNM::Types::byte e20_, BNM::Types::byte e19_, BNM::Types::byte e18_, BNM::Types::byte e17_, BNM::Types::byte e16_, BNM::Types::byte e15_, BNM::Types::byte e14_, BNM::Types::byte e13_, BNM::Types::byte e12_, BNM::Types::byte e11_, BNM::Types::byte e10_, BNM::Types::byte e9_, BNM::Types::byte e8_, BNM::Types::byte e7_, BNM::Types::byte e6_, BNM::Types::byte e5_, BNM::Types::byte e4_, BNM::Types::byte e3_, BNM::Types::byte e2_, BNM::Types::byte e1_, BNM::Types::byte e0_) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_epi8", 32);
			return __bnm__method__(e31_, e30_, e29_, e28_, e27_, e26_, e25_, e24_, e23_, e22_, e21_, e20_, e19_, e18_, e17_, e16_, e15_, e14_, e13_, e12_, e11_, e10_, e9_, e8_, e7_, e6_, e5_, e4_, e3_, e2_, e1_, e0_);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_epi16(short e15_, short e14_, short e13_, short e12_, short e11_, short e10_, short e9_, short e8_, short e7_, short e6_, short e5_, short e4_, short e3_, short e2_, short e1_, short e0_) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_epi16", 16);
			return __bnm__method__(e15_, e14_, e13_, e12_, e11_, e10_, e9_, e8_, e7_, e6_, e5_, e4_, e3_, e2_, e1_, e0_);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_epi32(int e7, int e6, int e5, int e4, int e3, int e2, int e1, int e0) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_epi32", 8);
			return __bnm__method__(e7, e6, e5, e4, e3, e2, e1, e0);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_epi64x(int64_t e3, int64_t e2, int64_t e1, int64_t e0) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_epi64x", 4);
			return __bnm__method__(e3, e2, e1, e0);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_m128(BNM::IL2CPP::Il2CppObject* hi, BNM::IL2CPP::Il2CppObject* lo) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_m128", 2);
			return __bnm__method__(hi, lo);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_m128d(BNM::IL2CPP::Il2CppObject* hi, BNM::IL2CPP::Il2CppObject* lo) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_m128d", 2);
			return __bnm__method__(hi, lo);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_setr_m128i(BNM::IL2CPP::Il2CppObject* hi, BNM::IL2CPP::Il2CppObject* lo) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_setr_m128i", 2);
			return __bnm__method__(hi, lo);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set1_pd(double a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set1_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set1_ps(float a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set1_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set1_epi8(BNM::Types::byte a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set1_epi8", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set1_epi16(short a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set1_epi16", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set1_epi32(int a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set1_epi32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_set1_epi64x(int64_t a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_set1_epi64x", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castpd_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castpd_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castps_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castps_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castps_si256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castps_si256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castpd_si256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castpd_si256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castsi256_ps(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castsi256_ps", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castsi256_pd(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castsi256_pd", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castps256_ps128(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castps256_ps128", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castpd256_pd128(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castpd256_pd128", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castsi256_si128(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castsi256_si128", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castps128_ps256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castps128_ps256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castpd128_pd256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castpd128_pd256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_castsi128_si256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_castsi128_si256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T undefined_ps() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("undefined_ps", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T undefined_pd() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("undefined_pd", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v128 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T undefined_si128() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("undefined_si128", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_undefined_ps() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_undefined_ps", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_undefined_pd() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_undefined_pd", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_undefined_si256() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_undefined_si256", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_zextps128_ps256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_zextps128_ps256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_zextpd128_pd256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_zextpd128_pd256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_zextsi128_si256(BNM::IL2CPP::Il2CppObject* a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_zextsi128_si256", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_insert_epi8(BNM::IL2CPP::Il2CppObject* a, int i, int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_insert_epi8", 3);
			return __bnm__method__(a, i, index);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_insert_epi16(BNM::IL2CPP::Il2CppObject* a, int i, int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_insert_epi16", 3);
			return __bnm__method__(a, i, index);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_insert_epi32(BNM::IL2CPP::Il2CppObject* a, int i, int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_insert_epi32", 3);
			return __bnm__method__(a, i, index);
		}
		/* @brief Orig Type: Unity.Burst.Intrinsics.v256 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T mm256_insert_epi64(BNM::IL2CPP::Il2CppObject* a, int64_t i, int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_insert_epi64", 3);
			return __bnm__method__(a, i, index);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mm256_extract_epi32(BNM::IL2CPP::Il2CppObject* a, int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_extract_epi32", 2);
			return __bnm__method__(a, index);
		}
		/* @brief Orig Type: System.Int64 */
		template <typename T = int64_t> static T mm256_extract_epi64(BNM::IL2CPP::Il2CppObject* a, int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mm256_extract_epi64", 2);
			return __bnm__method__(a, index);
		}
		
	};
}
