#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AudioRaycastCallback : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AudioRaycastCallback", BNM::Image("Oculus.Spatializer.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Invoke_1(BNM::Structures::Unity::Vector3 origin, BNM::Structures::Unity::Vector3 direction, BNM::IL2CPP::Il2CppObject** point, BNM::IL2CPP::Il2CppObject** normal, BNM::Types::nuint data) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 5);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](origin, direction, point, normal, data);
		}
		/* @brief Orig Type: System.IAsyncResult */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T BeginInvoke_1(BNM::Structures::Unity::Vector3 origin, BNM::Structures::Unity::Vector3 direction, BNM::IL2CPP::Il2CppObject** point, BNM::IL2CPP::Il2CppObject** normal, BNM::Types::nuint data, BNM::IL2CPP::Il2CppObject* callback, BNM::IL2CPP::Il2CppObject* $object) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BeginInvoke", 7);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](origin, direction, point, normal, data, callback, $object);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EndInvoke_1(BNM::IL2CPP::Il2CppObject** point, BNM::IL2CPP::Il2CppObject** normal, BNM::IL2CPP::Il2CppObject* result) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EndInvoke", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](point, normal, result);
		}
		
	};
}
