#pragma once
#include <BNMIncludes.hpp>

#undef TopLeft
#undef Top
#undef TopRight
#undef Left
#undef Center
#undef Right
#undef BottomLeft
#undef Bottom
#undef BottomRight
#undef BaseLine
#undef None
namespace GlobalNamespace {
	enum class AnchorPositions : int
	{
		TopLeft = 0,
		Top = 1,
		TopRight = 2,
		Left = 3,
		Center = 4,
		Right = 5,
		BottomLeft = 6,
		Bottom = 7,
		BottomRight = 8,
		BaseLine = 9,
		None = 10
	};
}
