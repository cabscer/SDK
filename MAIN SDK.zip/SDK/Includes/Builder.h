#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Builder : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Builder", BNM::Image("Unity.InputSystem.dll"));
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T $name$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$name$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_$name$(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$name$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T $displayName$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$displayName$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_$displayName$(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$displayName$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Type */
		template <typename T = BNM::MonoType*> T $type$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$type$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Type */
		void set_$type$(BNM::MonoType* value) {
			static BNM::Field<BNM::MonoType*> __bnm__field__ = StaticClass().GetField("$type$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Utilities.FourCC */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $stateFormat$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$stateFormat$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.InputSystem.Utilities.FourCC */
		void set_$stateFormat$(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$stateFormat$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T $stateSizeInBytes$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$stateSizeInBytes$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_$stateSizeInBytes$(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$stateSizeInBytes$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T m_ExtendsLayout() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ExtendsLayout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_m_ExtendsLayout(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("m_ExtendsLayout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Nullable`1<System.Boolean> */
		template <typename T = void* /*GENERICTYPE*/> T $updateBeforeRender$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$updateBeforeRender$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Nullable`1<System.Boolean> */
		void set_$updateBeforeRender$(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$updateBeforeRender$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_ControlCount() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ControlCount");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_ControlCount(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_ControlCount");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T m_Controls() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Controls");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem[] */
		void set_m_Controls(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("m_Controls");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T get_name() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_name", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_name(BNM::Structures::Mono::String* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_name", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T get_displayName() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_displayName", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_displayName(BNM::Structures::Mono::String* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_displayName", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Type */
		template <typename T = BNM::MonoType*> T get_type() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_type", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_type(BNM::MonoType* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_type", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Utilities.FourCC */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_stateFormat() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_stateFormat", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_stateFormat(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_stateFormat", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T get_stateSizeInBytes() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_stateSizeInBytes", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_stateSizeInBytes(int $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_stateSizeInBytes", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T get_extendsLayout() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_extendsLayout", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_extendsLayout(BNM::Structures::Mono::String* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_extendsLayout", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Nullable`1<System.Boolean> */
		template <typename T = void* /*GENERICTYPE*/> T get_updateBeforeRender() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_updateBeforeRender", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_updateBeforeRender(void* /*GENERICTYPE*/ $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_updateBeforeRender", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Layouts.InputControlLayout/ControlItem> */
		template <typename T = void* /*GENERICTYPE*/> T get_controls() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_controls", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder/ControlBuilder */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T AddControl(BNM::Structures::Mono::String* name) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddControl", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](name);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder */
		template <typename T = GlobalNamespace::Builder*> T WithName(BNM::Structures::Mono::String* name) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WithName", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](name);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder */
		template <typename T = GlobalNamespace::Builder*> T WithDisplayName(BNM::Structures::Mono::String* displayName) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WithDisplayName", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](displayName);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder */
		template <typename T = GlobalNamespace::Builder*> T WithType() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WithType", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder */
		template <typename T = GlobalNamespace::Builder*> T WithFormat(BNM::IL2CPP::Il2CppObject* format) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WithFormat", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](format);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder */
		template <typename T = GlobalNamespace::Builder*> T WithFormat_1(BNM::Structures::Mono::String* format) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WithFormat", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](format);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder */
		template <typename T = GlobalNamespace::Builder*> T WithSizeInBytes(int sizeInBytes) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WithSizeInBytes", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](sizeInBytes);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout/Builder */
		template <typename T = GlobalNamespace::Builder*> T Extend(BNM::Structures::Mono::String* baseLayoutName) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Extend", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](baseLayoutName);
		}
		/* @brief Orig Type: UnityEngine.InputSystem.Layouts.InputControlLayout */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Build() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Build", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
