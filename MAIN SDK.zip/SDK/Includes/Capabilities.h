#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Capabilities
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Capabilities", BNM::Image("Unity.InputSystem.dll"));
		}
		
		int type;
		int subType;
		int flags;
		
		
	};
}
