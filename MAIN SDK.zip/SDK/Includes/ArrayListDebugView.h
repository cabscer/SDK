#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ArrayListDebugView : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ArrayListDebugView", BNM::Image("mscorlib.dll"));
		}
		
		
		
	};
}
