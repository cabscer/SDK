#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			class DateTimeHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "DateTimeHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.TimeSpan */
				template <typename T = BNM::IL2CPP::Il2CppObject*> static T Now() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Now", 0);
					return __bnm__method__();
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T Timestamp() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Timestamp", 0);
					return __bnm__method__();
				}
				/* @brief Orig Type: System.Double */
				template <typename T = double> static T TimestampMs() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TimestampMs", 0);
					return __bnm__method__();
				}
				
			};
		}
	}
}
