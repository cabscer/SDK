#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			class ExceptionExtensions

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "ExceptionExtensions", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceReport */
				template <typename T = BNM::IL2CPP::Il2CppObject*> static T ToBacktraceReport(BNM::IL2CPP::Il2CppObject* source) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToBacktraceReport", 1);
					return __bnm__method__(source);
				}
				
			};
		}
	}
}
