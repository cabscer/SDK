#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			class MinidumpHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "MinidumpHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String[] */
				template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T Libraries() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Libraries");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String[] */
				static void set_Libraries(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
					static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("Libraries");
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T IsMemoryDumpAvailable() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsMemoryDumpAvailable", 0);
					return __bnm__method__();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T MiniDumpWriteDump(BNM::Types::nuint hProcess, BNM::Types::uint processId, BNM::IL2CPP::Il2CppObject* hFile, BNM::Types::uint dumpType, BNM::IL2CPP::Il2CppObject* expParam, BNM::Types::nuint userStreamParam, BNM::Types::nuint callbackParam) {
					static auto __bnm__method__ = (T(*)(BNM::Types::nuint, BNM::Types::uint, BNM::IL2CPP::Il2CppObject*, BNM::Types::uint, BNM::IL2CPP::Il2CppObject*, BNM::Types::nuint, BNM::Types::nuint))BNM::GetExternMethod("Backtrace.Unity.Common::MinidumpHelper::MiniDumpWriteDump");
					return (T)__bnm__method__(hProcess, processId, hFile, dumpType, expParam, userStreamParam, callbackParam);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T MiniDumpWriteDump_1(BNM::Types::nuint hProcess, BNM::Types::uint processId, BNM::IL2CPP::Il2CppObject* hFile, BNM::Types::uint dumpType, BNM::Types::nuint expParam, BNM::Types::nuint userStreamParam, BNM::Types::nuint callbackParam) {
					static auto __bnm__method__ = (T(*)(BNM::Types::nuint, BNM::Types::uint, BNM::IL2CPP::Il2CppObject*, BNM::Types::uint, BNM::Types::nuint, BNM::Types::nuint, BNM::Types::nuint))BNM::GetExternMethod("Backtrace.Unity.Common::MinidumpHelper::MiniDumpWriteDump");
					return (T)__bnm__method__(hProcess, processId, hFile, dumpType, expParam, userStreamParam, callbackParam);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T Write(BNM::Structures::Mono::String* filePath, BNM::Types::uint options, int exceptionType) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Write", 3);
					return __bnm__method__(filePath, options, exceptionType);
				}
				
			};
		}
	}
}
