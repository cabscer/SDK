#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			class MetricsHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "MetricsHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GetMicroseconds(BNM::IL2CPP::Il2CppObject* stopwatch) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetMicroseconds", 1);
					return __bnm__method__(stopwatch);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> static T Restart(BNM::IL2CPP::Il2CppObject* stopwatch) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Restart", 1);
					return __bnm__method__(stopwatch);
				}
				
			};
		}
	}
}
