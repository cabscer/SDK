#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			struct MiniDumpExceptionInformation
			{
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "MiniDumpExceptionInformation", BNM::Image("Backtrace.Unity.dll"));
				}
				
				BNM::Types::uint ThreadId;
				BNM::Types::nuint ExceptionPointers;
				bool ClientPointers;
				
				
			};
		}
	}
}
