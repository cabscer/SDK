#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			class ClientPathHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "ClientPathHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GetFullPath(BNM::Structures::Mono::String* path) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetFullPath", 1);
					return __bnm__method__(path);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T ParseInterpolatedString(BNM::Structures::Mono::String* path) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ParseInterpolatedString", 1);
					return __bnm__method__(path);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T GenerateFullPath(BNM::Structures::Mono::String* path) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateFullPath", 1);
					return __bnm__method__(path);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T IsFileInDatabaseDirectory(BNM::Structures::Mono::String* databasePath, BNM::Structures::Mono::String* filePath) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsFileInDatabaseDirectory", 2);
					return __bnm__method__(databasePath, filePath);
				}
				
			};
		}
	}
}
