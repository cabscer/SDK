#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			class TypeHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "TypeHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Collections.Generic.HashSet`1<System.Type> */
				template <typename T = void* /*GENERICTYPE*/> static T NumericTypes() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("NumericTypes");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.HashSet`1<System.Type> */
				static void set_NumericTypes(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("NumericTypes");
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T IsNumeric(BNM::MonoType* myType) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsNumeric", 1);
					return __bnm__method__(myType);
				}
				
			};
		}
	}
}
