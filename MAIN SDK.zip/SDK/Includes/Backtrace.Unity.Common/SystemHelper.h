#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			class SystemHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "SystemHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> static T GetCurrentThreadId() {
					static auto __bnm__method__ = (T(*)())BNM::GetExternMethod("Backtrace.Unity.Common::SystemHelper::GetCurrentThreadId");
					return (T)__bnm__method__();
				}
				/* @brief Orig Type: System.IntPtr */
				template <typename T = BNM::Types::nuint> static T LoadLibrary(BNM::Structures::Mono::String* lpFileName) {
					static auto __bnm__method__ = (T(*)(BNM::Structures::Mono::String*))BNM::GetExternMethod("Backtrace.Unity.Common::SystemHelper::LoadLibrary");
					return (T)__bnm__method__(lpFileName);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T IsLibraryAvailable(BNM::Structures::Mono::String* libraryName) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsLibraryAvailable", 1);
					return __bnm__method__(libraryName);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T IsLibraryAvailable_1(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* libraries) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsLibraryAvailable", 1);
					return __bnm__method__(libraries);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T Name() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Name", 0);
					return __bnm__method__();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T CpuArchitecture() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CpuArchitecture", 0);
					return __bnm__method__();
				}
				
			};
		}
	}
}
