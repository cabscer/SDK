#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Common {
			class MathHelper

			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Common", "MathHelper", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.Double */
				template <typename T = double> static T Clamp(double $value, double minimum, double maximum) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clamp", 3);
					return __bnm__method__($value, minimum, maximum);
				}
				/* @brief Orig Type: System.Double */
				template <typename T = double> static T Uniform(double minimum, double maximum) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Uniform", 2);
					return __bnm__method__(minimum, maximum);
				}
				
			};
		}
	}
}
