#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AppMetrics

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AppMetrics", BNM::Image("Unity.XR.Oculus.dll"));
		}
		
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_AppQueueAheadTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_AppQueueAheadTime", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_AppCPUElapsedTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_AppCPUElapsedTime", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_CompositorDroppedFrames() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_CompositorDroppedFrames", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_CompositorLatency() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_CompositorLatency", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_CompositorCPUTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_CompositorCPUTime", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_CPUStartToGPUEnd() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_CPUStartToGPUEnd", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_GPUEndToVsync() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_GPUEndToVsync", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T EnableAppMetrics(bool enable) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableAppMetrics", 1);
			return __bnm__method__(enable);
		}
		
	};
}
