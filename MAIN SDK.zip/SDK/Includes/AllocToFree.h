#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AllocToFree
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AllocToFree", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* alloc;
		BNM::IL2CPP::Il2CppObject* page;
		bool vertices;
		
		
	};
}
