#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class CanvasState : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "CanvasState", BNM::Image("Unity.XR.Interaction.Toolkit.dll"));
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T k_CanvasCheckInterval() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("k_CanvasCheckInterval");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_k_CanvasCheckInterval(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("k_CanvasCheckInterval");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.CanvasTracker */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_Tracker() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Tracker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.CanvasTracker */
		void set_m_Tracker(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_Tracker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.CanvasOptimizer/CanvasState/CanvasSettings */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_CanvasSettings() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_CanvasSettings");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.CanvasOptimizer/CanvasState/CanvasSettings */
		void set_m_CanvasSettings(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_CanvasSettings");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.CanvasOptimizer/CanvasState/CanvasScalerSettings */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_CanvasScalerSettings() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_CanvasScalerSettings");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.CanvasOptimizer/CanvasState/CanvasScalerSettings */
		void set_m_CanvasScalerSettings(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_CanvasScalerSettings");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.CanvasOptimizer/CanvasState/GraphicRaycasterSettings */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_GraphicRaycasterSettings() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_GraphicRaycasterSettings");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.CanvasOptimizer/CanvasState/GraphicRaycasterSettings */
		void set_m_GraphicRaycasterSettings(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_GraphicRaycasterSettings");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_WasNested() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_WasNested");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_WasNested(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_WasNested");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_Nested() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Nested");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_Nested(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_Nested");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_RaysDisabled() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_RaysDisabled");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_RaysDisabled(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_RaysDisabled");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Canvas */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_Canvas() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Canvas");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Canvas */
		void set_m_Canvas(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_Canvas");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UI.GraphicRaycaster */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_Raycaster() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Raycaster");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UI.GraphicRaycaster */
		void set_m_Raycaster(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_Raycaster");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_TrackedDeviceGraphicRaycaster() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_TrackedDeviceGraphicRaycaster");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster */
		void set_m_TrackedDeviceGraphicRaycaster(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_TrackedDeviceGraphicRaycaster");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_CheckTimer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_CheckTimer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_CheckTimer(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_CheckTimer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Initialize(BNM::IL2CPP::Il2CppObject* tracker) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](tracker);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T CheckForNestedChanges(bool force) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CheckForNestedChanges", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](force);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T CheckForOutOfView(BNM::IL2CPP::Il2CppObject* gazeSource, float fovAngle, float facingAngle, float maxDistance) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CheckForOutOfView", 4);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](gazeSource, fovAngle, facingAngle, maxDistance);
		}
		
	};
}
