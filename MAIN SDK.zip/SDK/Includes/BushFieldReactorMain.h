#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BushFieldReactorMain : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BushFieldReactorMain", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.GameObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Bush() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Bush");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject */
		void set_Bush(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Bush");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Blossom() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Blossom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject */
		void set_Blossom(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Blossom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Sphere() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Sphere");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject */
		void set_Sphere(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Sphere");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T NumBushes() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("NumBushes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_NumBushes(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("NumBushes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector2 */
		template <typename T = BNM::Structures::Unity::Vector2> T BushScaleRange() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BushScaleRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector2 */
		void set_BushScaleRange(BNM::Structures::Unity::Vector2 value) {
			static BNM::Field<BNM::Structures::Unity::Vector2> __bnm__field__ = StaticClass().GetField("BushScaleRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T NumBlossoms() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("NumBlossoms");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_NumBlossoms(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("NumBlossoms");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector2 */
		template <typename T = BNM::Structures::Unity::Vector2> T BlossomScaleRange() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BlossomScaleRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector2 */
		void set_BlossomScaleRange(BNM::Structures::Unity::Vector2 value) {
			static BNM::Field<BNM::Structures::Unity::Vector2> __bnm__field__ = StaticClass().GetField("BlossomScaleRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector2 */
		template <typename T = BNM::Structures::Unity::Vector2> T FieldBounds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FieldBounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector2 */
		void set_FieldBounds(BNM::Structures::Unity::Vector2 value) {
			static BNM::Field<BNM::Structures::Unity::Vector2> __bnm__field__ = StaticClass().GetField("FieldBounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T NumSpheresPerCircle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("NumSpheresPerCircle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_NumSpheresPerCircle(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("NumSpheresPerCircle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T NumCircles() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("NumCircles");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_NumCircles(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("NumCircles");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxCircleRadius() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxCircleRadius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxCircleRadius(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxCircleRadius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T CircleSpeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CircleSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_CircleSpeed(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("CircleSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.GameObject> */
		template <typename T = void* /*GENERICTYPE*/> T m_aSphere() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_aSphere");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.GameObject> */
		void set_m_aSphere(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("m_aSphere");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_basePhase() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_basePhase");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_basePhase(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_basePhase");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
