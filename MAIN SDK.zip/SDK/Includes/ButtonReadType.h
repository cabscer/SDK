#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Binary
#undef Axis1D
#undef Axis2DUp
#undef Axis2DDown
#undef Axis2DLeft
#undef Axis2DRight
namespace GlobalNamespace {
	enum class ButtonReadType : int
	{
		None = 0,
		Binary = 1,
		Axis1D = 2,
		Axis2DUp = 3,
		Axis2DDown = 4,
		Axis2DLeft = 5,
		Axis2DRight = 6
	};
}
