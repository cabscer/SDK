#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AnimationDataSet$2
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AnimationDataSet`2", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* elements;
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* properties;
		void* timing;
		void* style;
		int count;
		void* /*GENERICTYPE*/ indices;
		
		
	};
}
