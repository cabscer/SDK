#pragma once
#include <BNMIncludes.hpp>

#undef S16_Mono
#undef S16_Stereo
#undef F32_Mono
#undef F32_Stereo
namespace GlobalNamespace {
	enum class AudioDataType : int
	{
		S16_Mono = 0,
		S16_Stereo = 1,
		F32_Mono = 2,
		F32_Stereo = 3
	};
}
