#pragma once
#include <BNMIncludes.hpp>

#undef CameraAnchorType_PreDefined
#undef CameraAnchorType_Custom
#undef CameraAnchorType_Count
#undef CameraAnchorType_EnumSize
namespace GlobalNamespace {
	enum class CameraAnchorType : int
	{
		CameraAnchorType_PreDefined = 0,
		CameraAnchorType_Custom = 1,
		CameraAnchorType_Count = 2,
		CameraAnchorType_EnumSize = 2147483647
	};
}
