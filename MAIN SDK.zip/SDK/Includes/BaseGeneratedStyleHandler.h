#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BaseGeneratedStyleHandler : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BaseGeneratedStyleHandler", BNM::Image("Oculus.VR.dll"));
		}
		
		/* @brief Orig Type: System.Runtime.InteropServices.GCHandle */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _colorMapDataHandle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_colorMapDataHandle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Runtime.InteropServices.GCHandle */
		void set__colorMapDataHandle(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_colorMapDataHandle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Byte[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T _colorMapData() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_colorMapData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Byte[] */
		void set__colorMapData(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("_colorMapData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> T get_MapSize() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MapSize", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsValid() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsValid", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update(BNM::IL2CPP::Il2CppObject* settings) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](settings);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ApplyStyleSettings(BNM::IL2CPP::Il2CppObject* style) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ApplyStyleSettings", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](style);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Clear() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AllocateColorMapData(BNM::Types::uint size) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AllocateColorMapData", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](size);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T DeallocateColorMapData() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DeallocateColorMapData", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T WriteColorToColorMap(int colorIndex, BNM::IL2CPP::Il2CppObject* color) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WriteColorToColorMap", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](colorIndex, color);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T WriteFloatToColorMap(int index, float $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WriteFloatToColorMap", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](index, $value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ComputeBrightnessContrastPosterizeMap(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* result, float brightness, float contrast, float posterize) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ComputeBrightnessContrastPosterizeMap", 4);
			return __bnm__method__(result, brightness, contrast, posterize);
		}
		
	};
}
