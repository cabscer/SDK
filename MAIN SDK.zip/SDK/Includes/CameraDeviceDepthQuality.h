#pragma once
#include <BNMIncludes.hpp>

#undef Low
#undef Medium
#undef High
namespace GlobalNamespace {
	enum class CameraDeviceDepthQuality : int
	{
		Low = 0,
		Medium = 1,
		High = 2
	};
}
