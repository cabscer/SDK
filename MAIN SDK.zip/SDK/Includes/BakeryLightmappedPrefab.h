#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryLightmappedPrefab : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryLightmappedPrefab", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		
		
	};
}
