#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ButtonClickedEvent : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ButtonClickedEvent", BNM::Image("UnityEngine.UI.dll"));
		}
		
		
		
	};
}
