#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryLightmapGroupSelector : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryLightmapGroupSelector", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.Object */
		template <typename T = BNM::UnityEngine::Object*> T lmgroupAsset() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lmgroupAsset");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Object */
		void set_lmgroupAsset(BNM::UnityEngine::Object* value) {
			static BNM::Field<BNM::UnityEngine::Object*> __bnm__field__ = StaticClass().GetField("lmgroupAsset");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T instanceResolutionOverride() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("instanceResolutionOverride");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_instanceResolutionOverride(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("instanceResolutionOverride");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T instanceResolution() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("instanceResolution");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_instanceResolution(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("instanceResolution");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		
	};
}
