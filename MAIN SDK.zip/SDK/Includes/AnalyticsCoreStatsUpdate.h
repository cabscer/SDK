#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AnalyticsCoreStatsUpdate
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AnalyticsCoreStatsUpdate", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		
	};
}
