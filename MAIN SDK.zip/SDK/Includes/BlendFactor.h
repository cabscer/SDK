#pragma once
#include <BNMIncludes.hpp>

#undef Zero
#undef One
#undef SrcAlpha
#undef OneMinusSrcAlpha
#undef DstAlpha
#undef OneMinusDstAlpha
namespace GlobalNamespace {
	enum class BlendFactor : int
	{
		Zero = 0,
		One = 1,
		SrcAlpha = 2,
		OneMinusSrcAlpha = 3,
		DstAlpha = 4,
		OneMinusDstAlpha = 5
	};
}
