#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class APIDispatchDelegate : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "APIDispatchDelegate", BNM::Image("Assembly-CSharp-firstpass.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Invoke(void* param, bool bIOFailure) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](param, bIOFailure);
		}
		/* @brief Orig Type: System.IAsyncResult */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T BeginInvoke(void* param, bool bIOFailure, BNM::IL2CPP::Il2CppObject* callback, BNM::IL2CPP::Il2CppObject* $object) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BeginInvoke", 4);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](param, bIOFailure, callback, $object);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EndInvoke(BNM::IL2CPP::Il2CppObject* result) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EndInvoke", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](result);
		}
		
	};
}
