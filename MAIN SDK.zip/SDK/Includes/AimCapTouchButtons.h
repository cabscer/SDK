#pragma once
#include <BNMIncludes.hpp>

#undef A
#undef B
#undef LeftTrigger
#undef LeftThumbstick
#undef RightTrigger
#undef RightThumbstick
#undef X
#undef Y
namespace GlobalNamespace {
	enum class AimCapTouchButtons : int
	{
		A = 0,
		B = 1,
		LeftTrigger = 2,
		LeftThumbstick = 3,
		RightTrigger = 4,
		RightThumbstick = 5,
		X = 6,
		Y = 7
	};
}
