#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AssetPackManagerDownloadStatusCallback : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AssetPackManagerDownloadStatusCallback", BNM::Image("UnityEngine.AndroidJNIModule.dll"));
		}
		
		/* @brief Orig Type: System.Action`1<UnityEngine.Android.AndroidAssetPackInfo> */
		template <typename T = void* /*GENERICTYPE*/> T m_Callback() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Callback");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`1<UnityEngine.Android.AndroidAssetPackInfo> */
		void set_m_Callback(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("m_Callback");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T m_AssetPacks() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_AssetPacks");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String[] */
		void set_m_AssetPacks(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("m_AssetPacks");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T onStatusUpdate(BNM::Structures::Mono::String* assetPackName, int assetPackStatus, int64_t assetPackSize, int64_t assetPackBytesDownloaded, int assetPackTransferProgress, int assetPackErrorCode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("onStatusUpdate", 6);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](assetPackName, assetPackStatus, assetPackSize, assetPackBytesDownloaded, assetPackTransferProgress, assetPackErrorCode);
		}
		
	};
}
