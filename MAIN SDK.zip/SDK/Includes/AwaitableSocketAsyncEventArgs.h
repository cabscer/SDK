#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AwaitableSocketAsyncEventArgs : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AwaitableSocketAsyncEventArgs", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Net.Sockets.Socket/AwaitableSocketAsyncEventArgs */
		template <typename T = GlobalNamespace::AwaitableSocketAsyncEventArgs*> static T Reserved() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Reserved");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Net.Sockets.Socket/AwaitableSocketAsyncEventArgs */
		static void set_Reserved(GlobalNamespace::AwaitableSocketAsyncEventArgs* value) {
			static BNM::Field<GlobalNamespace::AwaitableSocketAsyncEventArgs*> __bnm__field__ = StaticClass().GetField("Reserved");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action`1<System.Object> */
		template <typename T = void* /*GENERICTYPE*/> static T s_completedSentinel() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_completedSentinel");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`1<System.Object> */
		static void set_s_completedSentinel(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_completedSentinel");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action`1<System.Object> */
		template <typename T = void* /*GENERICTYPE*/> static T s_availableSentinel() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_availableSentinel");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`1<System.Object> */
		static void set_s_availableSentinel(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_availableSentinel");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action`1<System.Object> */
		template <typename T = void* /*GENERICTYPE*/> T _continuation() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_continuation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`1<System.Object> */
		void set__continuation(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_continuation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Threading.ExecutionContext */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _executionContext() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_executionContext");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Threading.ExecutionContext */
		void set__executionContext(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_executionContext");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _scheduler() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_scheduler");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Object */
		void set__scheduler(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_scheduler");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int16 */
		template <typename T = short> T _token() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_token");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int16 */
		void set__token(short value) {
			static BNM::Field<short> __bnm__field__ = StaticClass().GetField("_token");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T $WrapExceptionsInIOExceptions$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$WrapExceptionsInIOExceptions$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_$WrapExceptionsInIOExceptions$(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$WrapExceptionsInIOExceptions$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_WrapExceptionsInIOExceptions() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_WrapExceptionsInIOExceptions", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_WrapExceptionsInIOExceptions(bool $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_WrapExceptionsInIOExceptions", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T Reserve() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reserve", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Release() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Release", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnCompleted(BNM::IL2CPP::Il2CppObject* _) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnCompleted", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](_);
		}
		/* @brief Orig Type: System.Threading.Tasks.ValueTask`1<System.Int32> */
		template <typename T = void* /*GENERICTYPE*/> T ReceiveAsync(BNM::IL2CPP::Il2CppObject* socket) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReceiveAsync", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](socket);
		}
		/* @brief Orig Type: System.Threading.Tasks.ValueTask */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T SendAsyncForNetworkStream(BNM::IL2CPP::Il2CppObject* socket) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendAsyncForNetworkStream", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](socket);
		}
		/* @brief Orig Type: System.Threading.Tasks.Sources.ValueTaskSourceStatus */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetStatus(short token) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetStatus", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](token);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnCompleted_1(void* /*GENERICTYPE*/ continuation, BNM::IL2CPP::Il2CppObject* state, short token, int flags) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnCompleted", 4);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](continuation, state, token, flags);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T InvokeContinuation(void* /*GENERICTYPE*/ continuation, BNM::IL2CPP::Il2CppObject* state, bool forceAsync) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("InvokeContinuation", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](continuation, state, forceAsync);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T GetResult(short token) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetResult", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](token);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_Threading_Tasks_Sources_IValueTaskSource_GetResult(short token) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Threading.Tasks.Sources.IValueTaskSource.GetResult", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](token);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ThrowIncorrectTokenException() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ThrowIncorrectTokenException", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ThrowMultipleContinuationsException() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ThrowMultipleContinuationsException", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ThrowException(int error) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ThrowException", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](error);
		}
		/* @brief Orig Type: System.Exception */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T CreateException(int error) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateException", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](error);
		}
		
	};
}
