#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BalloonHoldable : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BalloonHoldable", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BalloonDynamics */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T balloonDynamics() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("balloonDynamics");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BalloonDynamics */
		void set_balloonDynamics(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("balloonDynamics");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.MeshRenderer */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T mesh() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("mesh");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.MeshRenderer */
		void set_mesh(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("mesh");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.LineRenderer */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T lineRenderer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lineRenderer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.LineRenderer */
		void set_lineRenderer(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("lineRenderer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Rigidbody */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T rb() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rb");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Rigidbody */
		void set_rb(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("rb");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Photon.Realtime.Player */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T originalOwner() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("originalOwner");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Photon.Realtime.Player */
		void set_originalOwner(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("originalOwner");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T balloonPopFXPrefab() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("balloonPopFXPrefab");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject */
		void set_balloonPopFXPrefab(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("balloonPopFXPrefab");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Color */
		template <typename T = BNM::Structures::Unity::Color> T balloonPopFXColor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("balloonPopFXColor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Color */
		void set_balloonPopFXColor(BNM::Structures::Unity::Color value) {
			static BNM::Field<BNM::Structures::Unity::Color> __bnm__field__ = StaticClass().GetField("balloonPopFXColor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T timer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("timer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_timer(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("timer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T scaleTimerLength() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("scaleTimerLength");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_scaleTimerLength(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("scaleTimerLength");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T poppedTimerLength() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("poppedTimerLength");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_poppedTimerLength(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("poppedTimerLength");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T beginScale() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("beginScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_beginScale(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("beginScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T bopSpeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bopSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_bopSpeed(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("bopSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T localScale() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("localScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_localScale(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("localScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AudioSource */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T balloonBopSource() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("balloonBopSource");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AudioSource */
		void set_balloonBopSource(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("balloonBopSource");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AudioSource */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T balloonInflatSource() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("balloonInflatSource");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AudioSource */
		void set_balloonInflatSource(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("balloonInflatSource");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T forceAppliedAsRemote() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("forceAppliedAsRemote");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_forceAppliedAsRemote(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("forceAppliedAsRemote");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T collisionPtAsRemote() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("collisionPtAsRemote");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_collisionPtAsRemote(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("collisionPtAsRemote");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BalloonHoldable/BalloonStates */
		template <typename T = int> T balloonState() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("balloonState");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BalloonHoldable/BalloonStates */
		void set_balloonState(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("balloonState");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Awake() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Awake", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T ShouldSimulate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldSimulate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDisable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnWorldShareableItemSpawn() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnWorldShareableItemSpawn", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnWorldShareableItemDeallocated(BNM::IL2CPP::Il2CppObject* player) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnWorldShareableItemDeallocated", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](player);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PlayPopBalloonFX() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PlayPopBalloonFX", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EnableDynamics(bool enable, bool forceKinematicOn) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableDynamics", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](enable, forceKinematicOn);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PopBalloon() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PopBalloon", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PopBalloonRemote() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PopBalloonRemote", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnOwnerChangeCb(BNM::IL2CPP::Il2CppObject* newOwner, BNM::IL2CPP::Il2CppObject* prevOwner) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnOwnerChangeCb", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](newOwner, prevOwner);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OwnerPopBalloon() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OwnerPopBalloon", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T RunLocalPopSM() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RunLocalPopSM", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T LateUpdateShared() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LateUpdateShared", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T LateUpdateReplicated() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LateUpdateReplicated", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Grab() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Grab", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Release() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Release", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnTriggerEnter(BNM::IL2CPP::Il2CppObject* other) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnTriggerEnter", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](other);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnCollisionEnter(BNM::IL2CPP::Il2CppObject* collision) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnCollisionEnter", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](collision);
		}
		
	};
}
