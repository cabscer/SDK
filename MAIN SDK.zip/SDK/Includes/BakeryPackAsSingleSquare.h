#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryPackAsSingleSquare : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryPackAsSingleSquare", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		
		
	};
}
