#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $axis$e__FixedBuffer
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "<axis>e__FixedBuffer", BNM::Image("Unity.InputSystem.dll"));
		}
		
		float FixedElementField;
		
		
	};
}
