#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Block : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Block", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> T start() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("start");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.UInt32 */
		void set_start(BNM::Types::uint value) {
			static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("start");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> T end() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("end");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.UInt32 */
		void set_end(BNM::Types::uint value) {
			static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("end");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		template <typename T = GlobalNamespace::Block*> T prev() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("prev");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		void set_prev(GlobalNamespace::Block* value) {
			static BNM::Field<GlobalNamespace::Block*> __bnm__field__ = StaticClass().GetField("prev");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		template <typename T = GlobalNamespace::Block*> T next() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("next");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		void set_next(GlobalNamespace::Block* value) {
			static BNM::Field<GlobalNamespace::Block*> __bnm__field__ = StaticClass().GetField("next");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		template <typename T = GlobalNamespace::Block*> T prevAvailable() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("prevAvailable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		void set_prevAvailable(GlobalNamespace::Block* value) {
			static BNM::Field<GlobalNamespace::Block*> __bnm__field__ = StaticClass().GetField("prevAvailable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		template <typename T = GlobalNamespace::Block*> T nextAvailable() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("nextAvailable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		void set_nextAvailable(GlobalNamespace::Block* value) {
			static BNM::Field<GlobalNamespace::Block*> __bnm__field__ = StaticClass().GetField("nextAvailable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T allocated() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("allocated");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_allocated(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("allocated");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> T get_size() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_size", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
