#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BaseVisualElementScheduledItem : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BaseVisualElementScheduledItem", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.UIElements.VisualElement */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $element$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$element$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.VisualElement */
		void set_$element$(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$element$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T isScheduled() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isScheduled");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_isScheduled(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("isScheduled");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.VisualElementPanelActivator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_Activator() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Activator");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.VisualElementPanelActivator */
		void set_m_Activator(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_Activator");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: UnityEngine.UIElements.VisualElement */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_element() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_element", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_element(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_element", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.IVisualElementScheduledItem */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T StartingIn(int64_t delayMs) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StartingIn", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](delayMs);
		}
		/* @brief Orig Type: UnityEngine.UIElements.IVisualElementScheduledItem */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Every(int64_t intervalMs) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Every", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](intervalMs);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnItemUnscheduled() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnItemUnscheduled", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Resume() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Resume", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Pause() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Pause", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ExecuteLater(int64_t delayMs) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteLater", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](delayMs);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnPanelActivate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnPanelActivate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnPanelDeactivate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnPanelDeactivate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T CanBeActivated() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CanBeActivated", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
