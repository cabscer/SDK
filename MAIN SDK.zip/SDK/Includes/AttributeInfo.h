#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AttributeInfo : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AttributeInfo", BNM::Image("mscorlib.dll"));
		}
		
		/* @brief Orig Type: System.AttributeUsageAttribute */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _usage() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_usage");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.AttributeUsageAttribute */
		void set__usage(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_usage");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T _inheritanceLevel() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_inheritanceLevel");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set__inheritanceLevel(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_inheritanceLevel");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.AttributeUsageAttribute */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Usage() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Usage", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T get_InheritanceLevel() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_InheritanceLevel", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
