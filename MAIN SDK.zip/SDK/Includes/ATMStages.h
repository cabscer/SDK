#pragma once
#include <BNMIncludes.hpp>

#undef Unavailable
#undef Begin
#undef Menu
#undef Balance
#undef Choose
#undef Confirm
#undef Purchasing
#undef Success
#undef Failure
#undef Locked
namespace GlobalNamespace {
	enum class ATMStages : int
	{
		Unavailable = 0,
		Begin = 1,
		Menu = 2,
		Balance = 3,
		Choose = 4,
		Confirm = 5,
		Purchasing = 6,
		Success = 7,
		Failure = 8,
		Locked = 9
	};
}
