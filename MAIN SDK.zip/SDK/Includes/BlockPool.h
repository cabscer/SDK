#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BlockPool : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BlockPool", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		
		/* @brief Orig Type: UnityEngine.UIElements.UIR.BestFitAllocator/Block */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T CreateBlock() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateBlock", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ResetBlock(BNM::IL2CPP::Il2CppObject* block) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ResetBlock", 1);
			return __bnm__method__(block);
		}
		
	};
}
