#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AllocToUpdate
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AllocToUpdate", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		BNM::Types::uint id;
		BNM::Types::uint allocTime;
		BNM::IL2CPP::Il2CppObject* meshHandle;
		BNM::IL2CPP::Il2CppObject* permAllocVerts;
		BNM::IL2CPP::Il2CppObject* permAllocIndices;
		BNM::IL2CPP::Il2CppObject* permPage;
		bool copyBackIndices;
		
		
	};
}
