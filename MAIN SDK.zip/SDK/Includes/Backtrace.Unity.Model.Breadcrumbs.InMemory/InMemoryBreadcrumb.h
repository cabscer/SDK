#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				namespace InMemory {
					class InMemoryBreadcrumb : public BNM::IL2CPP::Il2CppObject
					{
						public:
						static BNM::Class StaticClass() {
							return BNM::Class("Backtrace.Unity.Model.Breadcrumbs.InMemory", "InMemoryBreadcrumb", BNM::Image("Backtrace.Unity.dll"));
						}
						
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T message() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("message");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						void set_message(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("message");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T timestamp() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("timestamp");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						void set_timestamp(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("timestamp");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T type() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("type");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						void set_type(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("type");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T level() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("level");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						void set_level(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("level");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
						template <typename T = void* /*GENERICTYPE*/> T Attributes() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Attributes");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
						void set_Attributes(void* /*GENERICTYPE*/ value) {
							static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("Attributes");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T get_Message() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Message", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T set_Message(BNM::Structures::Mono::String* $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Message", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
						}
						/* @brief Orig Type: System.Double */
						template <typename T = double> T get_Timestamp() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Timestamp", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T set_Timestamp(double $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Timestamp", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
						}
						/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BreadcrumbLevel */
						template <typename T = int> T get_Type() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Type", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T set_Type(int $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Type", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
						}
						/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
						template <typename T = int> T get_Level() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Level", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T set_Level(int $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Level", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
						}
						
					};
				}
			}
		}
	}
}
