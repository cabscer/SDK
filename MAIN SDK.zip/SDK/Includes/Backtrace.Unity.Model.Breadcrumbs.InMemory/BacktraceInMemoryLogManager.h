#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				namespace InMemory {
					class BacktraceInMemoryLogManager : public BNM::IL2CPP::Il2CppObject
					{
						public:
						static BNM::Class StaticClass() {
							return BNM::Class("Backtrace.Unity.Model.Breadcrumbs.InMemory", "BacktraceInMemoryLogManager", BNM::Image("Backtrace.Unity.dll"));
						}
						
						/* @brief Orig Type: System.Int32 */
						template <typename T = int> static T DefaultMaximumNumberOfInMemoryBreadcrumbs() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultMaximumNumberOfInMemoryBreadcrumbs");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Int32 */
						static void set_DefaultMaximumNumberOfInMemoryBreadcrumbs(int value) {
							static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultMaximumNumberOfInMemoryBreadcrumbs");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Int32 */
						template <typename T = int> T $MaximumNumberOfBreadcrumbs$() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$MaximumNumberOfBreadcrumbs$");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Int32 */
						void set_$MaximumNumberOfBreadcrumbs$(int value) {
							static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$MaximumNumberOfBreadcrumbs$");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Object */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T _lockObject() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_lockObject");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Object */
						void set__lockObject(BNM::IL2CPP::Il2CppObject* value) {
							static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_lockObject");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Collections.Generic.Queue`1<Backtrace.Unity.Model.Breadcrumbs.InMemory.InMemoryBreadcrumb> */
						template <typename T = void* /*GENERICTYPE*/> T Breadcrumbs() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Breadcrumbs");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Collections.Generic.Queue`1<Backtrace.Unity.Model.Breadcrumbs.InMemory.InMemoryBreadcrumb> */
						void set_Breadcrumbs(void* /*GENERICTYPE*/ value) {
							static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("Breadcrumbs");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Double */
						template <typename T = double> T _breadcrumbId() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_breadcrumbId");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Double */
						void set__breadcrumbId(double value) {
							static BNM::Field<double> __bnm__field__ = StaticClass().GetField("_breadcrumbId");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						
						/* @brief Orig Type: System.Int32 */
						template <typename T = int> T get_MaximumNumberOfBreadcrumbs() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaximumNumberOfBreadcrumbs", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T set_MaximumNumberOfBreadcrumbs(int $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_MaximumNumberOfBreadcrumbs", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T get_BreadcrumbsFilePath() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BreadcrumbsFilePath", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Add(BNM::Structures::Mono::String* message, int type, int level, void* /*GENERICTYPE*/ attributes) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 4);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, type, level, attributes);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Clear() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Enable() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Enable", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Int32 */
						template <typename T = int> T Length() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Length", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Double */
						template <typename T = double> T BreadcrumbId() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BreadcrumbId", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						
					};
				}
			}
		}
	}
}
