#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace JsonData {
				class Annotations : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.JsonData", "Annotations", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
					template <typename T = void* /*GENERICTYPE*/> static T _environmentVariablesCache() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_environmentVariablesCache");
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
					static void set__environmentVariablesCache(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_environmentVariablesCache");
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> static T VariablesLoaded() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("VariablesLoaded");
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Boolean */
					static void set_VariablesLoaded(bool value) {
						static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("VariablesLoaded");
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T _gameObjectDepth() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_gameObjectDepth");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Int32 */
					void set__gameObjectDepth(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_gameObjectDepth");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Exception */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T $Exception$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Exception$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Exception */
					void set_$Exception$(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$Exception$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
					template <typename T = void* /*GENERICTYPE*/> static T get_EnvironmentVariablesCache() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_EnvironmentVariablesCache", 0);
						return __bnm__method__();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> static T set_EnvironmentVariablesCache(void* /*GENERICTYPE*/ $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_EnvironmentVariablesCache", 1);
						return __bnm__method__($value);
					}
					/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
					template <typename T = void* /*GENERICTYPE*/> T get_EnvironmentVariables() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_EnvironmentVariables", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_EnvironmentVariables(void* /*GENERICTYPE*/ $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_EnvironmentVariables", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Exception */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Exception() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Exception", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Exception(BNM::IL2CPP::Il2CppObject* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Exception", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
					template <typename T = void* /*GENERICTYPE*/> static T SetEnvironmentVariables() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetEnvironmentVariables", 0);
						return __bnm__method__();
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T ToJson() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T ConvertGameObject(BNM::IL2CPP::Il2CppObject* gameObject, int depth) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ConvertGameObject", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](gameObject, depth);
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T ConvertGameObject_1(BNM::IL2CPP::Il2CppObject* gameObject, BNM::Structures::Mono::String* parentName, int depth) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ConvertGameObject", 3);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](gameObject, parentName, depth);
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T GetJObject(BNM::IL2CPP::Il2CppObject* gameObject, BNM::Structures::Mono::String* parentName) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetJObject", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](gameObject, parentName);
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T GetJObject_1(BNM::IL2CPP::Il2CppObject* gameObject, BNM::Structures::Mono::String* parentName) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetJObject", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](gameObject, parentName);
					}
					
				};
			}
		}
	}
}
