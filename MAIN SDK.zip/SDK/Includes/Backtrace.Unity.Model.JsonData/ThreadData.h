#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace JsonData {
				class ThreadData : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.JsonData", "ThreadData", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,Backtrace.Unity.Model.JsonData.ThreadInformation> */
					template <typename T = void* /*GENERICTYPE*/> T ThreadInformations() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ThreadInformations");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.String,Backtrace.Unity.Model.JsonData.ThreadInformation> */
					void set_ThreadInformations(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("ThreadInformations");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T MainThread() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MainThread");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_MainThread(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("MainThread");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T ToJson() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
