#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace JsonData {
				class AttributeProvider : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.JsonData", "AttributeProvider", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
					template <typename T = void* /*GENERICTYPE*/> T _attributes() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_attributes");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
					void set__attributes(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_attributes");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Collections.Generic.IList`1<Backtrace.Unity.Model.Attributes.IDynamicAttributeProvider> */
					template <typename T = void* /*GENERICTYPE*/> T _dynamicAttributeProvider() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_dynamicAttributeProvider");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.IList`1<Backtrace.Unity.Model.Attributes.IDynamicAttributeProvider> */
					void set__dynamicAttributeProvider(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_dynamicAttributeProvider");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_ApplicationVersion() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ApplicationVersion", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_ApplicationSessionKey() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ApplicationSessionKey", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_ApplicationGuid() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ApplicationGuid", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_Item(BNM::Structures::Mono::String* index) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Item", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](index);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Item(BNM::Structures::Mono::String* index, BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Item", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](index, $value);
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T Count() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Count", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T AddDynamicAttributeProvider(BNM::IL2CPP::Il2CppObject* attributeProvider) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddDynamicAttributeProvider", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributeProvider);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T AddScopedAttributeProvider(BNM::IL2CPP::Il2CppObject* attributeProvider) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddScopedAttributeProvider", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributeProvider);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T AddAttributes(void* /*GENERICTYPE*/ source, bool includeDynamic) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddAttributes", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](source, includeDynamic);
					}
					/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
					template <typename T = void* /*GENERICTYPE*/> T GenerateAttributes(bool includeDynamic) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateAttributes", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](includeDynamic);
					}
					
				};
			}
		}
	}
}
