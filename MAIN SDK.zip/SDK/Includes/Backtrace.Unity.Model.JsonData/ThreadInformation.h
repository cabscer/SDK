#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace JsonData {
				class ThreadInformation : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.JsonData", "ThreadInformation", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T $Name$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Name$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_$Name$(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$Name$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T $Fault$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Fault$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Boolean */
					void set_$Fault$(bool value) {
						static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$Fault$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Model.BacktraceStackFrame> */
					template <typename T = void* /*GENERICTYPE*/> T Stack() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Stack");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Model.BacktraceStackFrame> */
					void set_Stack(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("Stack");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_Name() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Name", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Name(BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Name", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T get_Fault() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Fault", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Fault(bool $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Fault", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T ToJson() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
