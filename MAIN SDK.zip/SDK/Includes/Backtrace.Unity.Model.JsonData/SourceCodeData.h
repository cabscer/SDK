#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace JsonData {
				class SourceCodeData : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.JsonData", "SourceCodeData", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,Backtrace.Unity.Model.JsonData.SourceCodeData/SourceCode> */
					template <typename T = void* /*GENERICTYPE*/> T data() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("data");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.String,Backtrace.Unity.Model.JsonData.SourceCodeData/SourceCode> */
					void set_data(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("data");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					
				};
			}
		}
	}
}
