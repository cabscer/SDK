#pragma once
#include <BNMIncludes.hpp>

#undef WebsiteDownload
#undef AssetStore
#undef PackageManager
namespace GlobalNamespace {
	enum class AstarDistribution : int
	{
		WebsiteDownload = 0,
		AssetStore = 1,
		PackageManager = 2
	};
}
