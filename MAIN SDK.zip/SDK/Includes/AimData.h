#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AimData : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AimData", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.RaycastHit */
		template <typename T = BNM::Structures::Unity::RaycastHit> T TargetHitInfo() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TargetHitInfo");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.RaycastHit */
		void set_TargetHitInfo(BNM::Structures::Unity::RaycastHit value) {
			static BNM::Field<BNM::Structures::Unity::RaycastHit> __bnm__field__ = StaticClass().GetField("TargetHitInfo");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TargetValid() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TargetValid");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_TargetValid(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("TargetValid");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Nullable`1<UnityEngine.Vector3> */
		template <typename T = void* /*GENERICTYPE*/> T Destination() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Destination");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Nullable`1<UnityEngine.Vector3> */
		void set_Destination(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("Destination");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T Radius() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Radius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_Radius(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Radius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.Vector3> */
		template <typename T = void* /*GENERICTYPE*/> T $Points$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Points$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.Vector3> */
		void set_$Points$(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$Points$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.Vector3> */
		template <typename T = void* /*GENERICTYPE*/> T get_Points() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Points", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_Points(void* /*GENERICTYPE*/ $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Points", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
