#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef ToLower
#undef ToUpper
namespace GlobalNamespace {
	enum class CaseConversion : int
	{
		None = 0,
		ToLower = 1,
		ToUpper = 2
	};
}
