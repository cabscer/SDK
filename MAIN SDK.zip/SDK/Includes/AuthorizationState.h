#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AuthorizationState
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AuthorizationState", BNM::Image("System.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* request;
		bool isProxy;
		bool isCompleted;
		int ntlm_auth_state;
		
		
	};
}
