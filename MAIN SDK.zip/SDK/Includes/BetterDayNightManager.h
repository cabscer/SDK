#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BetterDayNightManager : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BetterDayNightManager", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BetterDayNightManager */
		template <typename T = GlobalNamespace::BetterDayNightManager*> static T instance() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("instance");
			return __bnm__field__();
		}
		/* @param value Orig Type: BetterDayNightManager */
		static void set_instance(GlobalNamespace::BetterDayNightManager* value) {
			static BNM::Field<GlobalNamespace::BetterDayNightManager*> __bnm__field__ = StaticClass().GetField("instance");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Shader */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T standard() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("standard");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Shader */
		void set_standard(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("standard");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Shader */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T standardCutout() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("standardCutout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Shader */
		void set_standardCutout(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("standardCutout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Shader */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T gorillaUnlit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("gorillaUnlit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Shader */
		void set_gorillaUnlit(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("gorillaUnlit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Shader */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T gorillaUnlitCutout() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("gorillaUnlitCutout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Shader */
		void set_gorillaUnlitCutout(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("gorillaUnlitCutout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Material[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T standardMaterialsUnlit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("standardMaterialsUnlit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Material[] */
		void set_standardMaterialsUnlit(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("standardMaterialsUnlit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Material[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T standardMaterialsUnlitDarker() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("standardMaterialsUnlitDarker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Material[] */
		void set_standardMaterialsUnlitDarker(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("standardMaterialsUnlitDarker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Material[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T dayNightSupportedMaterials() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("dayNightSupportedMaterials");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Material[] */
		void set_dayNightSupportedMaterials(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("dayNightSupportedMaterials");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Material[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T dayNightSupportedMaterialsCutout() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("dayNightSupportedMaterialsCutout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Material[] */
		void set_dayNightSupportedMaterialsCutout(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("dayNightSupportedMaterialsCutout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T dayNightLightmaps() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("dayNightLightmaps");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D[] */
		void set_dayNightLightmaps(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("dayNightLightmaps");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T dayNightWeatherLightmaps() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("dayNightWeatherLightmaps");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D[] */
		void set_dayNightWeatherLightmaps(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("dayNightWeatherLightmaps");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T dayNightSkyboxTextures() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("dayNightSkyboxTextures");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D[] */
		void set_dayNightSkyboxTextures(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("dayNightSkyboxTextures");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T cloudsDayNightSkyboxTextures() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cloudsDayNightSkyboxTextures");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D[] */
		void set_cloudsDayNightSkyboxTextures(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("cloudsDayNightSkyboxTextures");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T dayNightWeatherSkyboxTextures() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("dayNightWeatherSkyboxTextures");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D[] */
		void set_dayNightWeatherSkyboxTextures(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("dayNightWeatherSkyboxTextures");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T standardUnlitColor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("standardUnlitColor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single[] */
		void set_standardUnlitColor(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("standardUnlitColor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T standardUnlitColorWithPremadeColorDarker() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("standardUnlitColorWithPremadeColorDarker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single[] */
		void set_standardUnlitColorWithPremadeColorDarker(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("standardUnlitColorWithPremadeColorDarker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T currentLerp() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentLerp");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_currentLerp(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("currentLerp");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T currentTimestep() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentTimestep");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_currentTimestep(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("currentTimestep");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Double[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T timeOfDayRange() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("timeOfDayRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Double[] */
		void set_timeOfDayRange(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("timeOfDayRange");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Double */
		template <typename T = double> T timeMultiplier() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("timeMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Double */
		void set_timeMultiplier(double value) {
			static BNM::Field<double> __bnm__field__ = StaticClass().GetField("timeMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T lastTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lastTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_lastTime(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("lastTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Double */
		template <typename T = double> T currentTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Double */
		void set_currentTime(double value) {
			static BNM::Field<double> __bnm__field__ = StaticClass().GetField("currentTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Double */
		template <typename T = double> T totalHours() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("totalHours");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Double */
		void set_totalHours(double value) {
			static BNM::Field<double> __bnm__field__ = StaticClass().GetField("totalHours");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Double */
		template <typename T = double> T totalSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("totalSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Double */
		void set_totalSeconds(double value) {
			static BNM::Field<double> __bnm__field__ = StaticClass().GetField("totalSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T colorFrom() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("colorFrom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_colorFrom(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("colorFrom");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T colorTo() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("colorTo");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_colorTo(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("colorTo");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T colorFromDarker() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("colorFromDarker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_colorFromDarker(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("colorFromDarker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T colorToDarker() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("colorToDarker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_colorToDarker(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("colorToDarker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T currentTimeIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentTimeIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_currentTimeIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("currentTimeIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T currentWeatherIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentWeatherIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_currentWeatherIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("currentWeatherIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T lastIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lastIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_lastIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("lastIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Double */
		template <typename T = double> T currentIndexSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentIndexSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Double */
		void set_currentIndexSeconds(double value) {
			static BNM::Field<double> __bnm__field__ = StaticClass().GetField("currentIndexSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T tempLerp() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("tempLerp");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_tempLerp(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("tempLerp");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Double */
		template <typename T = double> T baseSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("baseSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Double */
		void set_baseSeconds(double value) {
			static BNM::Field<double> __bnm__field__ = StaticClass().GetField("baseSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T computerInit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("computerInit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_computerInit(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("computerInit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T h() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("h");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_h(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("h");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T s() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_s(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("s");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T v() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("v");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_v(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("v");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T mySeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("mySeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_mySeed(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("mySeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Random */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T randomNumberGenerator() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("randomNumberGenerator");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Random */
		void set_randomNumberGenerator(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("randomNumberGenerator");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BetterDayNightManager/WeatherType[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T weatherCycle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("weatherCycle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BetterDayNightManager/WeatherType[] */
		void set_weatherCycle(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("weatherCycle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T rainChance() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rainChance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_rainChance(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("rainChance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T maxRainDuration() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("maxRainDuration");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_maxRainDuration(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("maxRainDuration");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T rainDuration() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rainDuration");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_rainDuration(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("rainDuration");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T remainingSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("remainingSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_remainingSeconds(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("remainingSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int64 */
		template <typename T = int64_t> T initialDayCycles() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("initialDayCycles");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int64 */
		void set_initialDayCycles(int64_t value) {
			static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("initialDayCycles");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int64 */
		template <typename T = int64_t> T gameEpochDay() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("gameEpochDay");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int64 */
		void set_gameEpochDay(int64_t value) {
			static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("gameEpochDay");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T currentWeatherCycle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentWeatherCycle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_currentWeatherCycle(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("currentWeatherCycle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T fromWeatherIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("fromWeatherIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_fromWeatherIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("fromWeatherIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T toWeatherIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("toWeatherIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_toWeatherIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("toWeatherIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T fromMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("fromMap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_fromMap(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("fromMap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T fromSky() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("fromSky");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_fromSky(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("fromSky");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T fromSky2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("fromSky2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_fromSky2(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("fromSky2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T toMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("toMap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_toMap(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("toMap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T toSky() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("toSky");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_toSky(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("toSky");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T toSky2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("toSky2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_toSky2(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("toSky2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: AddCollidersToParticleSystemTriggers[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T weatherSystems() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("weatherSystems");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: AddCollidersToParticleSystemTriggers[] */
		void set_weatherSystems(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("weatherSystems");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.Collider> */
		template <typename T = void* /*GENERICTYPE*/> T collidersToAddToWeatherSystems() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("collidersToAddToWeatherSystems");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.Collider> */
		void set_collidersToAddToWeatherSystems(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("collidersToAddToWeatherSystems");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T overrideIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("overrideIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_overrideIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("overrideIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BetterDayNightManager/ScheduledEvent> */
		template <typename T = void* /*GENERICTYPE*/> static T scheduledEvents() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("scheduledEvents");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BetterDayNightManager/ScheduledEvent> */
		static void set_scheduledEvents(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("scheduledEvents");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: TimeSettings */
		template <typename T = int> T currentSetting() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentSetting");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: TimeSettings */
		void set_currentSetting(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("currentSetting");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T $currentTimeOfDay$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$currentTimeOfDay$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_$currentTimeOfDay$(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$currentTimeOfDay$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T get_currentTimeOfDay() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_currentTimeOfDay", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_currentTimeOfDay(BNM::Structures::Mono::String* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_currentTimeOfDay", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Awake() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Awake", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDestroy() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDestroy", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Collections.IEnumerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T UpdateTimeOfDay() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateTimeOfDay", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ChangeLerps(float newLerp) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ChangeLerps", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](newLerp);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ChangeMaps(int fromIndex, int toIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ChangeMaps", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](fromIndex, toIndex);
		}
		/* @brief Orig Type: BetterDayNightManager/WeatherType */
		template <typename T = int> T CurrentWeather() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CurrentWeather", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: BetterDayNightManager/WeatherType */
		template <typename T = int> T NextWeather() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("NextWeather", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: BetterDayNightManager/WeatherType */
		template <typename T = int> T LastWeather() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LastWeather", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T GenerateWeatherEventTimes() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateWeatherEventTimes", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T RegisterScheduledEvent(int hour, BNM::IL2CPP::Il2CppObject* action) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RegisterScheduledEvent", 2);
			return __bnm__method__(hour, action);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T UnregisterScheduledEvent(int id) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UnregisterScheduledEvent", 1);
			return __bnm__method__(id);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T SetOverrideIndex(int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetOverrideIndex", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](index);
		}
		
	};
}
