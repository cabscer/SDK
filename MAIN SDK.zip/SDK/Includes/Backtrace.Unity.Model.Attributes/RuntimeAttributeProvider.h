#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Attributes {
				class RuntimeAttributeProvider : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Attributes", "RuntimeAttributeProvider", BNM::Image("Backtrace.Unity.dll"));
					}
					
					
					/* @brief Orig Type: System.Void */
					template <typename T = void> T GetAttributes(void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttributes", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T GetScriptingBackend() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetScriptingBackend", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T GetApiCompatibility() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetApiCompatibility", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
