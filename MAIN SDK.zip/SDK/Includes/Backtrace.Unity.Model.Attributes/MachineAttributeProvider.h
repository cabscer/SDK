#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Attributes {
				class MachineAttributeProvider : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Attributes", "MachineAttributeProvider", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: Backtrace.Unity.Model.MachineIdStorage */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T _machineIdStorage() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_machineIdStorage");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.MachineIdStorage */
					void set__machineIdStorage(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_machineIdStorage");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.Void */
					template <typename T = void> T GetAttributes(void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttributes", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T IncludeOsInformation(void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IncludeOsInformation", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T IncludeGraphicCardInformation(void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IncludeGraphicCardInformation", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
					}
					
				};
			}
		}
	}
}
