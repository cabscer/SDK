#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Attributes {
				class PiiAttributeProvider : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Attributes", "PiiAttributeProvider", BNM::Image("Backtrace.Unity.dll"));
					}
					
					
					/* @brief Orig Type: System.Void */
					template <typename T = void> T GetAttributes(void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttributes", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
					}
					
				};
			}
		}
	}
}
