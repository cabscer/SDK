#pragma once
#include <BNMIncludes.hpp>

#undef Name
#undef Desc
#undef Hidden
namespace GlobalNamespace {
	enum class AchievementDisplayAttribute : int
	{
		Name = 0,
		Desc = 1,
		Hidden = 2
	};
}
