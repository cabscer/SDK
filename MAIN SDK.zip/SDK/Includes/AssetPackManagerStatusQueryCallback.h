#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AssetPackManagerStatusQueryCallback : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AssetPackManagerStatusQueryCallback", BNM::Image("UnityEngine.AndroidJNIModule.dll"));
		}
		
		/* @brief Orig Type: System.Action`2<System.UInt64,UnityEngine.Android.AndroidAssetPackState[]> */
		template <typename T = void* /*GENERICTYPE*/> T m_Callback() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Callback");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`2<System.UInt64,UnityEngine.Android.AndroidAssetPackState[]> */
		void set_m_Callback(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("m_Callback");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<System.String> */
		template <typename T = void* /*GENERICTYPE*/> T m_AssetPackNames() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_AssetPackNames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<System.String> */
		void set_m_AssetPackNames(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("m_AssetPackNames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.Android.AndroidAssetPackState> */
		template <typename T = void* /*GENERICTYPE*/> T m_States() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_States");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.Android.AndroidAssetPackState> */
		void set_m_States(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("m_States");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int64 */
		template <typename T = int64_t> T m_Size() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Size");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int64 */
		void set_m_Size(int64_t value) {
			static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("m_Size");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T onStatusResult(int64_t totalBytes, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* assetPackNames, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* assetPackStatuses, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* assetPackErrorCodes) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("onStatusResult", 4);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](totalBytes, assetPackNames, assetPackStatuses, assetPackErrorCodes);
		}
		
	};
}
