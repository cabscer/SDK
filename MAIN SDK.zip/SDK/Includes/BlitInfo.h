#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BlitInfo
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BlitInfo", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* src;
		BNM::IL2CPP::Il2CppObject* srcRect;
		BNM::IL2CPP::Il2CppObject* dstPos;
		int border;
		BNM::Structures::Unity::Color tint;
		
		
	};
}
