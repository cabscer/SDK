#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CacheRefInstance
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CacheRefInstance", BNM::Image("Unity.InputSystem.dll"));
		}
		
		bool valid;
		
		
	};
}
