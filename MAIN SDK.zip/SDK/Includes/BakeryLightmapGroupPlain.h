#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BakeryLightmapGroupPlain
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryLightmapGroupPlain", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		BNM::Structures::Mono::String* name;
		int resolution;
		int id;
		int renderMode;
		int renderDirMode;
		int atlasPacker;
		bool vertexBake;
		bool containsTerrains;
		bool probes;
		bool isImplicit;
		bool computeSSS;
		int sssSamples;
		float sssDensity;
		float sssR;
		float sssG;
		float sssB;
		float fakeShadowBias;
		bool transparentSelfShadow;
		bool flipNormal;
		BNM::Structures::Mono::String* parentName;
		int sceneLodLevel;
		
		
	};
}
