#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef WidthControlsHeight
#undef HeightControlsWidth
#undef FitInParent
#undef EnvelopeParent
namespace GlobalNamespace {
	enum class AspectMode : int
	{
		None = 0,
		WidthControlsHeight = 1,
		HeightControlsWidth = 2,
		FitInParent = 3,
		EnvelopeParent = 4
	};
}
