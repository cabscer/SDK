#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BuildCondition$1 : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BuildCondition`1", BNM::Image("Oculus.Interaction.dll"));
		}
		
		/* @brief Orig Type: Oculus.Interaction.PoseDetection.FeatureConfigBuilder/BuildCondition`1/BuildStateDelegate<TBuildState> */
		template <typename T = void* /*GENERICTYPE*/> T _buildStateFn() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_buildStateFn");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Oculus.Interaction.PoseDetection.FeatureConfigBuilder/BuildCondition`1/BuildStateDelegate<TBuildState> */
		void set__buildStateFn(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_buildStateFn");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: TBuildState */
		template <typename T = void*> T get_Is() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Is", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: TBuildState */
		template <typename T = void*> T get_IsNot() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsNot", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
