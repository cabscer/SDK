#pragma once
#include <BNMIncludes.hpp>

#undef LeftLeg
#undef LeftFoot
#undef RightLeg
#undef RightFoot
#undef LeftArm
#undef LeftHand
#undef RightArm
#undef RightHand
#undef Hips
#undef Back
#undef Neck
#undef Head
namespace GlobalNamespace {
	enum class BodySection : int
	{
		LeftLeg = 0,
		LeftFoot = 1,
		RightLeg = 2,
		RightFoot = 3,
		LeftArm = 4,
		LeftHand = 5,
		RightArm = 6,
		RightHand = 7,
		Hips = 8,
		Back = 9,
		Neck = 10,
		Head = 11
	};
}
