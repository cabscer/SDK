#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AppPerfFrameStats
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AppPerfFrameStats", BNM::Image("Oculus.VR.dll"));
		}
		
		int HmdVsyncIndex;
		int AppFrameIndex;
		int AppDroppedFrameCount;
		float AppMotionToPhotonLatency;
		float AppQueueAheadTime;
		float AppCpuElapsedTime;
		float AppGpuElapsedTime;
		int CompositorFrameIndex;
		int CompositorDroppedFrameCount;
		float CompositorLatency;
		float CompositorCpuElapsedTime;
		float CompositorGpuElapsedTime;
		float CompositorCpuStartToGpuEndElapsedTime;
		float CompositorGpuEndToVsyncElapsedTime;
		
		
	};
}
