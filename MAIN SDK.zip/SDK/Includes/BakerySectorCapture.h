#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakerySectorCapture : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakerySectorCapture", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		
		
	};
}
