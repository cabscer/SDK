#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BodyState
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BodyState", BNM::Image("Oculus.VR.dll"));
		}
		
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* JointLocations;
		float Confidence;
		BNM::Types::uint SkeletonChangedCount;
		double Time;
		
		
	};
}
