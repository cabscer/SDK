#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Bmi2

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Bmi2", BNM::Image("Unity.Burst.dll"));
		}
		
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T get_IsBmi2Supported() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsBmi2Supported", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T bzhi_u32(BNM::Types::uint a, BNM::Types::uint index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("bzhi_u32", 2);
			return __bnm__method__(a, index);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T bzhi_u64(BNM::Types::ulong a, BNM::Types::ulong index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("bzhi_u64", 2);
			return __bnm__method__(a, index);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T mulx_u32(BNM::Types::uint a, BNM::Types::uint b, BNM::IL2CPP::Il2CppObject** hi) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mulx_u32", 3);
			return __bnm__method__(a, b, hi);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T mulx_u64(BNM::Types::ulong a, BNM::Types::ulong b, BNM::IL2CPP::Il2CppObject** hi) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mulx_u64", 3);
			return __bnm__method__(a, b, hi);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T pdep_u32(BNM::Types::uint a, BNM::Types::uint mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("pdep_u32", 2);
			return __bnm__method__(a, mask);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T pdep_u64(BNM::Types::ulong a, BNM::Types::ulong mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("pdep_u64", 2);
			return __bnm__method__(a, mask);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T pext_u32(BNM::Types::uint a, BNM::Types::uint mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("pext_u32", 2);
			return __bnm__method__(a, mask);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T pext_u64(BNM::Types::ulong a, BNM::Types::ulong mask) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("pext_u64", 2);
			return __bnm__method__(a, mask);
		}
		
	};
}
