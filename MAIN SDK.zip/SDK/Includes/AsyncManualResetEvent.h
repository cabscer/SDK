#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AsyncManualResetEvent : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AsyncManualResetEvent", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Threading.Tasks.TaskCompletionSource`1<System.Boolean> */
		template <typename T = void* /*GENERICTYPE*/> T m_tcs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_tcs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Threading.Tasks.TaskCompletionSource`1<System.Boolean> */
		void set_m_tcs(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("m_tcs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Threading.Tasks.Task */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T WaitAsync() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WaitAsync", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T WaitOne(int millisecondTimeout) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WaitOne", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](millisecondTimeout);
		}
		/* @brief Orig Type: System.Threading.Tasks.Task`1<System.Boolean> */
		template <typename T = void* /*GENERICTYPE*/> T WaitAsync_1(int millisecondTimeout) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WaitAsync", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](millisecondTimeout);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Set() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Set", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
