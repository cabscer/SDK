#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AddEventAdapter : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AddEventAdapter", BNM::Image("mscorlib.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Invoke(BNM::IL2CPP::Il2CppObject* _this, BNM::IL2CPP::Il2CppObject* dele) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](_this, dele);
		}
		
	};
}
