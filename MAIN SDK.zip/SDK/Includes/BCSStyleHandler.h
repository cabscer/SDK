#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BCSStyleHandler : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BCSStyleHandler", BNM::Image("Oculus.VR.dll"));
		}
		
		
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> T get_MapSize() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MapSize", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update(BNM::IL2CPP::Il2CppObject* settings) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](settings);
		}
		
	};
}
