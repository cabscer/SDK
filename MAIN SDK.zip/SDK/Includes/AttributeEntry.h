#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AttributeEntry
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AttributeEntry", BNM::Image("System.dll"));
		}
		
		BNM::MonoType* type;
		int index;
		
		
	};
}
