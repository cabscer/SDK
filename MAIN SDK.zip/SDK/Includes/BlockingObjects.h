#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef TwoD
#undef ThreeD
#undef All
namespace GlobalNamespace {
	enum class BlockingObjects : int
	{
		None = 0,
		TwoD = 1,
		ThreeD = 2,
		All = 3
	};
}
