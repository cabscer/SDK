#pragma once
#include <BNMIncludes.hpp>

#undef InputManagerBindings
#undef InputSystemActions
#undef Both
namespace GlobalNamespace {
	enum class ActiveInputMode : int
	{
		InputManagerBindings = 0,
		InputSystemActions = 1,
		Both = 2
	};
}
