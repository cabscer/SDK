#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Interfaces {
			class IBacktraceMetrics
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Interfaces", "IBacktraceMetrics", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T get_MaximumSummedEvents() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaximumSummedEvents", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_MaximumSummedEvents(BNM::Types::uint $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_MaximumSummedEvents", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T get_MaximumUniqueEvents() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaximumUniqueEvents", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_MaximumUniqueEvents(BNM::Types::uint $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_MaximumUniqueEvents", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_UniqueEventsSubmissionUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_UniqueEventsSubmissionUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_UniqueEventsSubmissionUrl(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_UniqueEventsSubmissionUrl", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_SummedEventsSubmissionUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_SummedEventsSubmissionUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_SummedEventsSubmissionUrl(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_SummedEventsSubmissionUrl", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Send() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AddSummedEvent(BNM::Structures::Mono::String* metricsGroupName) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddSummedEvent", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](metricsGroupName);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AddSummedEvent_1(BNM::Structures::Mono::String* metricsGroupName, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddSummedEvent", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](metricsGroupName, attributes);
				}
				
			};
		}
	}
}
