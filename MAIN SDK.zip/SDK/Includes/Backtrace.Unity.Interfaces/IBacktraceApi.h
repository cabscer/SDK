#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Interfaces {
			class IBacktraceApi
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Interfaces", "IBacktraceApi", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_ServerUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ServerUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Collections.IEnumerator */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Send(BNM::IL2CPP::Il2CppObject* data, void* /*GENERICTYPE*/ callback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data, callback);
				}
				/* @brief Orig Type: System.Collections.IEnumerator */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Send_1(BNM::Structures::Mono::String* json, void* /*GENERICTYPE*/ attachments, int deduplication, void* /*GENERICTYPE*/ callback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](json, attachments, deduplication, callback);
				}
				/* @brief Orig Type: System.Collections.IEnumerator */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Send_2(BNM::Structures::Mono::String* json, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ queryAttributes, void* /*GENERICTYPE*/ callback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](json, attachments, queryAttributes, callback);
				}
				/* @brief Orig Type: System.Action`1<System.Exception> */
				template <typename T = void* /*GENERICTYPE*/> T get_OnServerError() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_OnServerError", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_OnServerError(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_OnServerError", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Action`1<Backtrace.Unity.Model.BacktraceResult> */
				template <typename T = void* /*GENERICTYPE*/> T get_OnServerResponse() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_OnServerResponse", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_OnServerResponse(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_OnServerResponse", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Func`3<System.String,Backtrace.Unity.Model.BacktraceData,Backtrace.Unity.Model.BacktraceResult> */
				template <typename T = void* /*GENERICTYPE*/> T get_RequestHandler() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RequestHandler", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_RequestHandler(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_RequestHandler", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Collections.IEnumerator */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SendMinidump(BNM::Structures::Mono::String* minidumpPath, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ queryAttributes, void* /*GENERICTYPE*/ callback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendMinidump", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](minidumpPath, attachments, queryAttributes, callback);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T get_EnablePerformanceStatistics() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_EnablePerformanceStatistics", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_EnablePerformanceStatistics(bool $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_EnablePerformanceStatistics", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				
			};
		}
	}
}
