#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Interfaces {
			class IBacktraceDatabaseFileContext
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Interfaces", "IBacktraceDatabaseFileContext", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T get_ScreenshotQuality() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotQuality", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_ScreenshotQuality(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotQuality", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T get_ScreenshotMaxHeight() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotMaxHeight", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_ScreenshotMaxHeight(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotMaxHeight", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<System.IO.FileInfo> */
				template <typename T = void* /*GENERICTYPE*/> T GetRecords() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetRecords", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<System.IO.FileInfo> */
				template <typename T = void* /*GENERICTYPE*/> T GetAll() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAll", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ValidFileConsistency() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidFileConsistency", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T RemoveOrphaned(void* /*GENERICTYPE*/ existingRecords) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RemoveOrphaned", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](existingRecords);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Clear() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Delete(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<System.String> */
				template <typename T = void* /*GENERICTYPE*/> T GenerateRecordAttachments(BNM::IL2CPP::Il2CppObject* data) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateRecordAttachments", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Save(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Save", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T IsValidRecord(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsValidRecord", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				
			};
		}
	}
}
