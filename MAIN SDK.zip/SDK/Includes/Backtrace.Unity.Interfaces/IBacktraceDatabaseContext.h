#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Interfaces {
			class IBacktraceDatabaseContext
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Interfaces", "IBacktraceDatabaseContext", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Add(BNM::IL2CPP::Il2CppObject* backtraceDatabaseRecord) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceDatabaseRecord);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T FirstOrDefault() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FirstOrDefault", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T FirstOrDefault_1(void* /*GENERICTYPE*/ predicate) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FirstOrDefault", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](predicate);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T LastOrDefault() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LastOrDefault", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord> */
				template <typename T = void* /*GENERICTYPE*/> T Get() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Get", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Delete(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Any(BNM::IL2CPP::Il2CppObject* n) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Any", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](n);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Any_1() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Any", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T Count() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Count", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Clear() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T IncrementBatchRetry() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IncrementBatchRetry", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T GetSize() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSize", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T GetTotalNumberOfRecords() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetTotalNumberOfRecords", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				template <typename T = int> T get_DeduplicationStrategy() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DeduplicationStrategy", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_DeduplicationStrategy(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DeduplicationStrategy", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord> */
				template <typename T = void* /*GENERICTYPE*/> T GetRecordsToDelete() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetRecordsToDelete", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetHash(BNM::IL2CPP::Il2CppObject* backtraceData) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetHash", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceData);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetRecordByHash(BNM::Structures::Mono::String* hash) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetRecordByHash", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](hash);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AddDuplicate(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddDuplicate", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				
			};
		}
	}
}
