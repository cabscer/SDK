#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Interfaces {
			class IBacktraceDatabase
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Interfaces", "IBacktraceDatabase", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T get_ScreenshotQuality() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotQuality", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_ScreenshotQuality(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotQuality", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T get_ScreenshotMaxHeight() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotMaxHeight", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_ScreenshotMaxHeight(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotMaxHeight", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.IBacktraceBreadcrumbs */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Breadcrumbs() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Breadcrumbs", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Flush() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Flush", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetApi(BNM::IL2CPP::Il2CppObject* backtraceApi) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetApi", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceApi);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Clear() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ValidConsistency() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidConsistency", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Add(BNM::IL2CPP::Il2CppObject* backtraceReport, void* /*GENERICTYPE*/ attributes, BNM::Types::uint miniDumpType) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceReport, attributes, miniDumpType);
				}
				/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<Backtrace.Unity.Model.Database.BacktraceDatabaseRecord> */
				template <typename T = void* /*GENERICTYPE*/> T Get() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Get", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Delete(BNM::IL2CPP::Il2CppObject* record) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](record);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseSettings */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetSettings() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSettings", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T GetDatabaseSize() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetDatabaseSize", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetReportWatcher(BNM::IL2CPP::Il2CppObject* reportLimitWatcher) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetReportWatcher", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](reportLimitWatcher);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Reload() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reload", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Add_1(BNM::IL2CPP::Il2CppObject* data, bool $lock) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data, $lock);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Enabled() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Enabled", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T EnableBreadcrumbsSupport() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableBreadcrumbsSupport", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
