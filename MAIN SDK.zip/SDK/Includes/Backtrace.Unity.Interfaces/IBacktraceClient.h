#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Interfaces {
			class IBacktraceClient
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Interfaces", "IBacktraceClient", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.IBacktraceBreadcrumbs */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Breadcrumbs() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Breadcrumbs", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Send(BNM::IL2CPP::Il2CppObject* report, void* /*GENERICTYPE*/ sendCallback) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report, sendCallback);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Send_1(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attachmentPaths, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attachmentPaths, attributes);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Send_2(BNM::IL2CPP::Il2CppObject* exception, void* /*GENERICTYPE*/ attachmentPaths, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Send", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](exception, attachmentPaths, attributes);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetClientReportLimit(BNM::Types::uint reportPerMin) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetClientReportLimit", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](reportPerMin);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Refresh() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Refresh", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T EnableBreadcrumbsSupport() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableBreadcrumbsSupport", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Interfaces.IBacktraceMetrics */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Metrics() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Metrics", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T EnableMetrics() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableMetrics", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T EnableMetrics_1(BNM::Structures::Mono::String* uniqueEventsSubmissionUrl, BNM::Structures::Mono::String* summedEventsSubmissionUrl, BNM::Types::uint timeIntervalInSec, BNM::Structures::Mono::String* uniqueEventName) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableMetrics", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](uniqueEventsSubmissionUrl, summedEventsSubmissionUrl, timeIntervalInSec, uniqueEventName);
				}
				
			};
		}
	}
}
