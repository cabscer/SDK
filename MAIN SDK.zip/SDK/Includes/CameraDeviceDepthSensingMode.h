#pragma once
#include <BNMIncludes.hpp>

#undef Standard
#undef Fill
namespace GlobalNamespace {
	enum class CameraDeviceDepthSensingMode : int
	{
		Standard = 0,
		Fill = 1
	};
}
