#pragma once
#include <BNMIncludes.hpp>

#undef Stack
#undef Queue
namespace Backtrace {
	namespace Unity {
		namespace Types {
			enum class RetryOrder : int
			{
				Stack = 0,
				Queue = 1
			};
		}
	}
}
