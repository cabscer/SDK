#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Present
namespace Backtrace {
	namespace Unity {
		namespace Types {
			enum class MinidumpException : int
			{
				None = 0,
				Present = 1
			};
		}
	}
}
