#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Default
#undef Classifier
#undef Message
namespace Backtrace {
	namespace Unity {
		namespace Types {
			enum class DeduplicationStrategy : int
			{
				None = 0,
				Default = 1,
				Classifier = 2,
				Message = 4
			};
		}
	}
}
