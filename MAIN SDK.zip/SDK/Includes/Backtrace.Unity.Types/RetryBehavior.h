#pragma once
#include <BNMIncludes.hpp>

#undef ByInterval
#undef NoRetry
namespace Backtrace {
	namespace Unity {
		namespace Types {
			enum class RetryBehavior : int
			{
				ByInterval = 0,
				NoRetry = 1
			};
		}
	}
}
