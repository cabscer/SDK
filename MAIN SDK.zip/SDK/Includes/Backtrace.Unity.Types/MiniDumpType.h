#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Normal
#undef WithDataSegs
#undef WithFullMemory
#undef WithHandleData
#undef FilterMemory
#undef ScanMemory
#undef WithUnloadedModules
#undef WithIndirectlyReferencedMemory
#undef FilterModulePaths
#undef WithProcessThreadData
#undef WithPrivateReadWriteMemory
#undef WithoutOptionalData
#undef WithFullMemoryInfo
#undef WithThreadInfo
#undef WithCodeSegs
#undef WithoutAuxiliaryState
#undef WithFullAuxiliaryState
#undef WithPrivateWriteCopyMemory
#undef IgnoreInaccessibleMemory
#undef ValidTypeFlags
namespace Backtrace {
	namespace Unity {
		namespace Types {
			enum class MiniDumpType : BNM::Types::uint
			{
				None = 524286,
				Normal = 0,
				WithDataSegs = 1,
				WithFullMemory = 2,
				WithHandleData = 4,
				FilterMemory = 8,
				ScanMemory = 16,
				WithUnloadedModules = 32,
				WithIndirectlyReferencedMemory = 64,
				FilterModulePaths = 128,
				WithProcessThreadData = 256,
				WithPrivateReadWriteMemory = 512,
				WithoutOptionalData = 1024,
				WithFullMemoryInfo = 2048,
				WithThreadInfo = 4096,
				WithCodeSegs = 8192,
				WithoutAuxiliaryState = 16384,
				WithFullAuxiliaryState = 32768,
				WithPrivateWriteCopyMemory = 65536,
				IgnoreInaccessibleMemory = 131072,
				ValidTypeFlags = 262143
			};
		}
	}
}
