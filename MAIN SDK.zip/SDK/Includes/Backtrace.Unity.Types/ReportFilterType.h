#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Message
#undef Exception
#undef UnhandledException
#undef Hang
#undef Error
namespace Backtrace {
	namespace Unity {
		namespace Types {
			enum class ReportFilterType : int
			{
				None = 0,
				Message = 1,
				Exception = 2,
				UnhandledException = 4,
				Hang = 8,
				Error = 16
			};
		}
	}
}
