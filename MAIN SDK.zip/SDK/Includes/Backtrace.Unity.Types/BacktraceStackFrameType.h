#pragma once
#include <BNMIncludes.hpp>

#undef Unknown
#undef Dotnet
#undef Android
#undef Native
namespace Backtrace {
	namespace Unity {
		namespace Types {
			enum class BacktraceStackFrameType : int
			{
				Unknown = 0,
				Dotnet = 1,
				Android = 2,
				Native = 3
			};
		}
	}
}
