#pragma once
#include <BNMIncludes.hpp>

#undef LimitReached
#undef ServerError
#undef Ok
#undef Empty
#undef NetworkError
namespace Backtrace {
	namespace Unity {
		namespace Types {
			enum class BacktraceResultStatus : int
			{
				LimitReached = 0,
				ServerError = 1,
				Ok = 2,
				Empty = 3,
				NetworkError = 4
			};
		}
	}
}
