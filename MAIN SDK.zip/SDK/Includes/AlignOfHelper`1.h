#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AlignOfHelper$1
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AlignOfHelper`1", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		BNM::Types::byte dummy;
		void* data;
		
		
	};
}
