#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Json {
			class BacktraceJObject : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Json", "BacktraceJObject", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
				template <typename T = void* /*GENERICTYPE*/> T PrimitiveValues() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PrimitiveValues");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
				void set_PrimitiveValues(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("PrimitiveValues");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
				template <typename T = void* /*GENERICTYPE*/> T UserPrimitives() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UserPrimitives");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
				void set_UserPrimitives(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("UserPrimitives");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,Backtrace.Unity.Json.BacktraceJObject> */
				template <typename T = void* /*GENERICTYPE*/> T InnerObjects() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("InnerObjects");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.String,Backtrace.Unity.Json.BacktraceJObject> */
				void set_InnerObjects(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("InnerObjects");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.Object> */
				template <typename T = void* /*GENERICTYPE*/> T ComplexObjects() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ComplexObjects");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.Object> */
				void set_ComplexObjects(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("ComplexObjects");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Add(BNM::Structures::Mono::String* key, bool $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Add_1(BNM::Structures::Mono::String* key, float $value, BNM::Structures::Mono::String* format) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value, format);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Add_2(BNM::Structures::Mono::String* key, double $value, BNM::Structures::Mono::String* format) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value, format);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Add_3(BNM::Structures::Mono::String* key, BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Add_4(BNM::Structures::Mono::String* key, int64_t $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Add_5(BNM::Structures::Mono::String* key, Backtrace::Unity::Json::BacktraceJObject* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Add_6(BNM::Structures::Mono::String* key, BNM::IL2CPP::Il2CppObject* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T ToJson() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T ToJson_1(BNM::IL2CPP::Il2CppObject* stringBuilder) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](stringBuilder);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AddUserPrimitives(BNM::IL2CPP::Il2CppObject* stringBuilder) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddUserPrimitives", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](stringBuilder);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AppendPrimitives(BNM::IL2CPP::Il2CppObject* stringBuilder) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AppendPrimitives", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](stringBuilder);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AppendJObjects(BNM::IL2CPP::Il2CppObject* stringBuilder) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AppendJObjects", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](stringBuilder);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AppendComplexValues(BNM::IL2CPP::Il2CppObject* stringBuilder) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AppendComplexValues", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](stringBuilder);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ShouldContinueAddingJSONProperties(BNM::IL2CPP::Il2CppObject* stringBuilder) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldContinueAddingJSONProperties", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](stringBuilder);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AppendKey(BNM::Structures::Mono::String* $value, BNM::IL2CPP::Il2CppObject* builder) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AppendKey", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value, builder);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T EscapeString(BNM::Structures::Mono::String* $value, BNM::IL2CPP::Il2CppObject* output) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EscapeString", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value, output);
				}
				/* @brief Orig Type: System.Char */
				template <typename T = char> T IntToHex(int n) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IntToHex", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](n);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T ToCharAsUnicodeToStringBuilder(char c, BNM::IL2CPP::Il2CppObject* output) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToCharAsUnicodeToStringBuilder", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](c, output);
				}
				
			};
		}
	}
}
