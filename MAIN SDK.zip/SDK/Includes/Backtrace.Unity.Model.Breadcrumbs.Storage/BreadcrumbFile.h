#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				namespace Storage {
					class BreadcrumbFile : public BNM::IL2CPP::Il2CppObject
					{
						public:
						static BNM::Class StaticClass() {
							return BNM::Class("Backtrace.Unity.Model.Breadcrumbs.Storage", "BreadcrumbFile", BNM::Image("Backtrace.Unity.dll"));
						}
						
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T _path() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_path");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						void set__path(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_path");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						
						/* @brief Orig Type: System.Void */
						template <typename T = void> T Delete() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Exists() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exists", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.IO.Stream */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T GetCreateStream() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetCreateStream", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.IO.Stream */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T GetIOStream() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetIOStream", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.IO.Stream */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T GetWriteStream() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetWriteStream", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						
					};
				}
			}
		}
	}
}
