#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				namespace Storage {
					class BacktraceStorageLogManager : public BNM::IL2CPP::Il2CppObject
					{
						public:
						static BNM::Class StaticClass() {
							return BNM::Class("Backtrace.Unity.Model.Breadcrumbs.Storage", "BacktraceStorageLogManager", BNM::Image("Backtrace.Unity.dll"));
						}
						
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T $BreadcrumbsFilePath$() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$BreadcrumbsFilePath$");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						void set_$BreadcrumbsFilePath$(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$BreadcrumbsFilePath$");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Int32 */
						template <typename T = int> static T MinimumBreadcrumbsFileSize() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MinimumBreadcrumbsFileSize");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Int32 */
						static void set_MinimumBreadcrumbsFileSize(int value) {
							static BNM::Field<int> __bnm__field__ = StaticClass().GetField("MinimumBreadcrumbsFileSize");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Int64 */
						template <typename T = int64_t> T _breadcrumbsSize() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_breadcrumbsSize");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Int64 */
						void set__breadcrumbsSize(int64_t value) {
							static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("_breadcrumbsSize");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T BreadcrumbLogFilePrefix() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BreadcrumbLogFilePrefix");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_BreadcrumbLogFilePrefix(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("BreadcrumbLogFilePrefix");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T BreadcrumbLogFileName() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BreadcrumbLogFileName");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_BreadcrumbLogFileName(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("BreadcrumbLogFileName");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Byte[] */
						template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T NewRow() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("NewRow");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Byte[] */
						static void set_NewRow(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
							static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("NewRow");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Byte[] */
						template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T EndOfDocument() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EndOfDocument");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Byte[] */
						static void set_EndOfDocument(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
							static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("EndOfDocument");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Byte[] */
						template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T StartOfDocument() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("StartOfDocument");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Byte[] */
						static void set_StartOfDocument(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
							static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("StartOfDocument");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T _emptyFile() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_emptyFile");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Boolean */
						void set__emptyFile(bool value) {
							static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_emptyFile");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Double */
						template <typename T = double> T _breadcrumbId() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_breadcrumbId");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Double */
						void set__breadcrumbId(double value) {
							static BNM::Field<double> __bnm__field__ = StaticClass().GetField("_breadcrumbId");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Object */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T _lockObject() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_lockObject");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Object */
						void set__lockObject(BNM::IL2CPP::Il2CppObject* value) {
							static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_lockObject");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Int64 */
						template <typename T = int64_t> T currentSize() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentSize");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Int64 */
						void set_currentSize(int64_t value) {
							static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("currentSize");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.Collections.Generic.Queue`1<System.Int64> */
						template <typename T = void* /*GENERICTYPE*/> T _logSize() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_logSize");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.Collections.Generic.Queue`1<System.Int64> */
						void set__logSize(void* /*GENERICTYPE*/ value) {
							static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_logSize");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T _storagePath() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_storagePath");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						void set__storagePath(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_storagePath");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.Storage.IBreadcrumbFile */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T $BreadcrumbFile$() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$BreadcrumbFile$");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							return __bnm__field__();
						}
						/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.Storage.IBreadcrumbFile */
						void set_$BreadcrumbFile$(BNM::IL2CPP::Il2CppObject* value) {
							static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$BreadcrumbFile$");
							__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
							__bnm__field__.Set(value);
						}
						
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T get_BreadcrumbsFilePath() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BreadcrumbsFilePath", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T set_BreadcrumbsFilePath(BNM::Structures::Mono::String* $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BreadcrumbsFilePath", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
						}
						/* @brief Orig Type: System.Int64 */
						template <typename T = int64_t> T get_BreadcrumbsSize() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BreadcrumbsSize", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T set_BreadcrumbsSize(int64_t $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BreadcrumbsSize", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
						}
						/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.Storage.IBreadcrumbFile */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T get_BreadcrumbFile() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BreadcrumbFile", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T set_BreadcrumbFile(BNM::IL2CPP::Il2CppObject* $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BreadcrumbFile", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Enable() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Enable", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Add(BNM::Structures::Mono::String* message, int level, int type, void* /*GENERICTYPE*/ attributes) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 4);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, level, type, attributes);
						}
						/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T CreateBreadcrumbJson(double id, BNM::Structures::Mono::String* message, int level, int type, void* /*GENERICTYPE*/ attributes) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateBreadcrumbJson", 5);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](id, message, level, type, attributes);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T AppendBreadcrumb(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* bytes) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AppendBreadcrumb", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](bytes);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T ClearOldLogs() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ClearOldLogs", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Int64 */
						template <typename T = int64_t> T GetNextStartPosition() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetNextStartPosition", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Clear() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Int32 */
						template <typename T = int> T Length() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Length", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Double */
						template <typename T = double> T BreadcrumbId() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BreadcrumbId", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T Archive() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Archive", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						
					};
				}
			}
		}
	}
}
