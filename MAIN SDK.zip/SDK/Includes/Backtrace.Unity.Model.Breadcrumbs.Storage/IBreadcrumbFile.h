#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				namespace Storage {
					class IBreadcrumbFile
					{
						public:
						static BNM::Class StaticClass() {
							return BNM::Class("Backtrace.Unity.Model.Breadcrumbs.Storage", "IBreadcrumbFile", BNM::Image("Backtrace.Unity.dll"));
						}
						
						
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Exists() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exists", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T Delete() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Delete", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.IO.Stream */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T GetCreateStream() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetCreateStream", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.IO.Stream */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T GetIOStream() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetIOStream", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.IO.Stream */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T GetWriteStream() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetWriteStream", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						
					};
				}
			}
		}
	}
}
