#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef WebCamera0
#undef WebCamera1
#undef ZEDCamera
namespace GlobalNamespace {
	enum class CameraDevice : int
	{
		None = 0,
		WebCamera0 = 100,
		WebCamera1 = 101,
		ZEDCamera = 300
	};
}
