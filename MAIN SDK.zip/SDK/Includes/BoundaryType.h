#pragma once
#include <BNMIncludes.hpp>

#undef OuterBoundary
#undef PlayArea
namespace GlobalNamespace {
	enum class BoundaryType : int
	{
		OuterBoundary = 0,
		PlayArea = 1
	};
}
