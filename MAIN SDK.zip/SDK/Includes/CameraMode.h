#pragma once
#include <BNMIncludes.hpp>

#undef Normal
#undef OverrideFov
#undef ThirdPerson
namespace GlobalNamespace {
	enum class CameraMode : int
	{
		Normal = 0,
		OverrideFov = 1,
		ThirdPerson = 2
	};
}
