#pragma once
#include <BNMIncludes.hpp>

#undef Normal
#undef Pop
#undef Waiting
#undef WaitForOwnershipTransfer
#undef WaitForReDock
#undef Refilling
namespace GlobalNamespace {
	enum class BalloonStates : int
	{
		Normal = 0,
		Pop = 1,
		Waiting = 2,
		WaitForOwnershipTransfer = 3,
		WaitForReDock = 4,
		Refilling = 5
	};
}
