#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryDirectLight : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryDirectLight", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.Color */
		template <typename T = BNM::Structures::Unity::Color> T color() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("color");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Color */
		void set_color(BNM::Structures::Unity::Color value) {
			static BNM::Field<BNM::Structures::Unity::Color> __bnm__field__ = StaticClass().GetField("color");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T intensity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("intensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_intensity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("intensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T shadowSpread() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("shadowSpread");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_shadowSpread(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("shadowSpread");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T samples() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("samples");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_samples(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("samples");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T bitmask() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bitmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_bitmask(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("bitmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T bakeToIndirect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bakeToIndirect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_bakeToIndirect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("bakeToIndirect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T shadowmask() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("shadowmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_shadowmask(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("shadowmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T shadowmaskDenoise() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("shadowmaskDenoise");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_shadowmaskDenoise(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("shadowmaskDenoise");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T indirectIntensity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("indirectIntensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_indirectIntensity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("indirectIntensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T cloudShadow() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cloudShadow");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_cloudShadow(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("cloudShadow");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T cloudShadowTilingX() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cloudShadowTilingX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_cloudShadowTilingX(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("cloudShadowTilingX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T cloudShadowTilingY() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cloudShadowTilingY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_cloudShadowTilingY(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("cloudShadowTilingY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T cloudShadowOffsetX() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cloudShadowOffsetX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_cloudShadowOffsetX(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("cloudShadowOffsetX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T cloudShadowOffsetY() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cloudShadowOffsetY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_cloudShadowOffsetY(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("cloudShadowOffsetY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T UID() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_UID(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("UID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T lightsChanged() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lightsChanged");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_lightsChanged(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("lightsChanged");
			__bnm__field__.Set(value);
		}
		
		
	};
}
