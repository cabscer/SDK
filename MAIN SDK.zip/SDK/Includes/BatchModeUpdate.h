#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BatchModeUpdate
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BatchModeUpdate", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		
	};
}
