#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ButtonDownListener : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ButtonDownListener", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Action */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T onButtonDown() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("onButtonDown");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action */
		void set_onButtonDown(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("onButtonDown");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T add_onButtonDown(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("add_onButtonDown", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T remove_onButtonDown(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("remove_onButtonDown", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnPointerDown(BNM::IL2CPP::Il2CppObject* eventData) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnPointerDown", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](eventData);
		}
		
	};
}
