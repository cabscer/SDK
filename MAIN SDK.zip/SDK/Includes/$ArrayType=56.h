#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $ArrayType$56
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "$ArrayType=56", BNM::Image("Pathfinding.Ionic.Zip.Reduced.dll"));
		}
		
		
		
	};
}
