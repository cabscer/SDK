#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $ArrayType$6144
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "$ArrayType=6144", BNM::Image("Pathfinding.Ionic.Zip.Reduced.dll"));
		}
		
		
		
	};
}
