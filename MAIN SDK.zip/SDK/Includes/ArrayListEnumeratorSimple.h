#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ArrayListEnumeratorSimple : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ArrayListEnumeratorSimple", BNM::Image("mscorlib.dll"));
		}
		
		/* @brief Orig Type: System.Collections.ArrayList */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _list() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_list");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.ArrayList */
		void set__list(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_list");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T _index() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_index");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set__index(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_index");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T _version() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_version");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set__version(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_version");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _currentElement() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_currentElement");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Object */
		void set__currentElement(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_currentElement");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T _isArrayList() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_isArrayList");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set__isArrayList(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_isArrayList");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T s_dummyObject() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_dummyObject");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Object */
		static void set_s_dummyObject(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("s_dummyObject");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Clone() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clone", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T MoveNext() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MoveNext", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
