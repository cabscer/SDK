#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BundleData
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BundleData", BNM::Image("Assembly-CSharp.dll"));
		}
		
		BNM::Structures::Mono::String* skuName;
		BNM::Structures::Mono::String* playFabItemName;
		int shinyRocks;
		int majorVersion;
		int minorVersion;
		int minorVersion2;
		bool isActive;
		
		
	};
}
