#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef PrimaryIndexTrigger
#undef PrimaryHandTrigger
#undef SecondaryIndexTrigger
#undef SecondaryHandTrigger
#undef PrimaryIndexTriggerCurl
#undef PrimaryIndexTriggerSlide
#undef PrimaryThumbRestForce
#undef PrimaryStylusForce
#undef SecondaryIndexTriggerCurl
#undef SecondaryIndexTriggerSlide
#undef SecondaryThumbRestForce
#undef SecondaryStylusForce
#undef PrimaryIndexTriggerForce
#undef SecondaryIndexTriggerForce
#undef Any
namespace GlobalNamespace {
	enum class Axis1D : int
	{
		None = 0,
		PrimaryIndexTrigger = 1,
		PrimaryHandTrigger = 4,
		SecondaryIndexTrigger = 2,
		SecondaryHandTrigger = 8,
		PrimaryIndexTriggerCurl = 16,
		PrimaryIndexTriggerSlide = 32,
		PrimaryThumbRestForce = 64,
		PrimaryStylusForce = 128,
		SecondaryIndexTriggerCurl = 256,
		SecondaryIndexTriggerSlide = 512,
		SecondaryThumbRestForce = 1024,
		SecondaryStylusForce = 2048,
		PrimaryIndexTriggerForce = 4096,
		SecondaryIndexTriggerForce = 8192,
		Any = -1
	};
}
