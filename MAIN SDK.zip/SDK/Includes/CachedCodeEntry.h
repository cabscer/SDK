#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class CachedCodeEntry : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "CachedCodeEntry", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Text.RegularExpressions.Regex/CachedCodeEntry */
		template <typename T = GlobalNamespace::CachedCodeEntry*> T Next() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Next");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Text.RegularExpressions.Regex/CachedCodeEntry */
		void set_Next(GlobalNamespace::CachedCodeEntry* value) {
			static BNM::Field<GlobalNamespace::CachedCodeEntry*> __bnm__field__ = StaticClass().GetField("Next");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Text.RegularExpressions.Regex/CachedCodeEntry */
		template <typename T = GlobalNamespace::CachedCodeEntry*> T Previous() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Previous");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Text.RegularExpressions.Regex/CachedCodeEntry */
		void set_Previous(GlobalNamespace::CachedCodeEntry* value) {
			static BNM::Field<GlobalNamespace::CachedCodeEntry*> __bnm__field__ = StaticClass().GetField("Previous");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Text.RegularExpressions.Regex/CachedCodeEntryKey */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Key() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Key");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Text.RegularExpressions.Regex/CachedCodeEntryKey */
		void set_Key(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Key");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Text.RegularExpressions.RegexCode */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Code() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Code");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Text.RegularExpressions.RegexCode */
		void set_Code(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Code");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Hashtable */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Caps() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Caps");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Hashtable */
		void set_Caps(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Caps");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Hashtable */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Capnames() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Capnames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Hashtable */
		void set_Capnames(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Capnames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T Capslist() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Capslist");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String[] */
		void set_Capslist(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("Capslist");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T Capsize() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Capsize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_Capsize(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("Capsize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Text.RegularExpressions.ExclusiveReference */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Runnerref() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Runnerref");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Text.RegularExpressions.ExclusiveReference */
		void set_Runnerref(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Runnerref");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.WeakReference`1<System.Text.RegularExpressions.RegexReplacement> */
		template <typename T = void* /*GENERICTYPE*/> T ReplRef() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ReplRef");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.WeakReference`1<System.Text.RegularExpressions.RegexReplacement> */
		void set_ReplRef(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("ReplRef");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		
	};
}
