#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ButtonState : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ButtonState", BNM::Image("UnityEngine.UI.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.EventSystems.PointerEventData/InputButton */
		template <typename T = int> T m_Button() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Button");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.EventSystems.PointerEventData/InputButton */
		void set_m_Button(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_Button");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_EventData() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_EventData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData */
		void set_m_EventData(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_EventData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_eventData() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_eventData", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_eventData(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_eventData", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: UnityEngine.EventSystems.PointerEventData/InputButton */
		template <typename T = int> T get_button() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_button", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_button(int $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_button", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		
	};
}
