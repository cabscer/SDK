#pragma once
#include <BNMIncludes.hpp>

#undef Pooled
#undef OverMaximumSize
#undef PoolExhausted
namespace GlobalNamespace {
	enum class BufferAllocatedReason : int
	{
		Pooled = 0,
		OverMaximumSize = 1,
		PoolExhausted = 2
	};
}
