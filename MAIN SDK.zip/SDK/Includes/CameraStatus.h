#pragma once
#include <BNMIncludes.hpp>

#undef CameraStatus_None
#undef CameraStatus_Connected
#undef CameraStatus_Calibrating
#undef CameraStatus_CalibrationFailed
#undef CameraStatus_Calibrated
#undef CameraStatus_ThirdPerson
#undef CameraStatus_EnumSize
namespace GlobalNamespace {
	enum class CameraStatus : int
	{
		CameraStatus_None = 0,
		CameraStatus_Connected = 1,
		CameraStatus_Calibrating = 2,
		CameraStatus_CalibrationFailed = 3,
		CameraStatus_Calibrated = 4,
		CameraStatus_ThirdPerson = 5,
		CameraStatus_EnumSize = 2147483647
	};
}
