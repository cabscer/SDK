#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BurstCompilerHelper

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BurstCompilerHelper", BNM::Image("Unity.Burst.dll"));
		}
		
		/* @brief Orig Type: Unity.Burst.BurstCompiler/BurstCompilerHelper/IsBurstEnabledDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T IsBurstEnabledImpl() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("IsBurstEnabledImpl");
			return __bnm__field__();
		}
		/* @param value Orig Type: Unity.Burst.BurstCompiler/BurstCompilerHelper/IsBurstEnabledDelegate */
		static void set_IsBurstEnabledImpl(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("IsBurstEnabledImpl");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T IsBurstGenerated() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("IsBurstGenerated");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		static void set_IsBurstGenerated(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("IsBurstGenerated");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T IsBurstEnabled() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsBurstEnabled", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T DiscardedMethod(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DiscardedMethod", 1);
			return __bnm__method__($value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T IsCompiledByBurst(BNM::IL2CPP::Il2CppObject* del) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsCompiledByBurst", 1);
			return __bnm__method__(del);
		}
		
	};
}
