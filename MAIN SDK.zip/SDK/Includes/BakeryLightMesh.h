#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryLightMesh : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryLightMesh", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T UID() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_UID(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("UID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Color */
		template <typename T = BNM::Structures::Unity::Color> T color() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("color");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Color */
		void set_color(BNM::Structures::Unity::Color value) {
			static BNM::Field<BNM::Structures::Unity::Color> __bnm__field__ = StaticClass().GetField("color");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T intensity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("intensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_intensity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("intensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture2D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T texture() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("texture");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture2D */
		void set_texture(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("texture");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T cutoff() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cutoff");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_cutoff(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("cutoff");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T samples() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("samples");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_samples(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("samples");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T samples2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("samples2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_samples2(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("samples2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T bitmask() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bitmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_bitmask(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("bitmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T selfShadow() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("selfShadow");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_selfShadow(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("selfShadow");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T bakeToIndirect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bakeToIndirect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_bakeToIndirect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("bakeToIndirect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T indirectIntensity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("indirectIntensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_indirectIntensity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("indirectIntensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T lmid() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lmid");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_lmid(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("lmid");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T lightsChanged() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lightsChanged");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_lightsChanged(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("lightsChanged");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDrawGizmosSelected() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDrawGizmosSelected", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
