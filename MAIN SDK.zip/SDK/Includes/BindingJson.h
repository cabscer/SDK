#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BindingJson
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BindingJson", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::Structures::Mono::String* name;
		BNM::Structures::Mono::String* id;
		BNM::Structures::Mono::String* path;
		BNM::Structures::Mono::String* interactions;
		BNM::Structures::Mono::String* processors;
		BNM::Structures::Mono::String* groups;
		BNM::Structures::Mono::String* action;
		bool isComposite;
		bool isPartOfComposite;
		
		
	};
}
