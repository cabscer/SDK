#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AreaNode : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AreaNode", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.UIElements.ObjectPool`1<UnityEngine.UIElements.UIRAtlasAllocator/AreaNode> */
		template <typename T = void* /*GENERICTYPE*/> static T s_Pool() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_Pool");
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.ObjectPool`1<UnityEngine.UIElements.UIRAtlasAllocator/AreaNode> */
		static void set_s_Pool(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_Pool");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.RectInt */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T rect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.RectInt */
		void set_rect(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("rect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.UIRAtlasAllocator/AreaNode */
		template <typename T = GlobalNamespace::AreaNode*> T previous() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("previous");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.UIRAtlasAllocator/AreaNode */
		void set_previous(GlobalNamespace::AreaNode* value) {
			static BNM::Field<GlobalNamespace::AreaNode*> __bnm__field__ = StaticClass().GetField("previous");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.UIElements.UIRAtlasAllocator/AreaNode */
		template <typename T = GlobalNamespace::AreaNode*> T next() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("next");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.UIRAtlasAllocator/AreaNode */
		void set_next(GlobalNamespace::AreaNode* value) {
			static BNM::Field<GlobalNamespace::AreaNode*> __bnm__field__ = StaticClass().GetField("next");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: UnityEngine.UIElements.UIRAtlasAllocator/AreaNode */
		template <typename T = GlobalNamespace::AreaNode*> static T Acquire(BNM::IL2CPP::Il2CppObject* rect) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Acquire", 1);
			return __bnm__method__(rect);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Release() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Release", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T RemoveFromChain() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RemoveFromChain", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AddAfter(GlobalNamespace::AreaNode* previous) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddAfter", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](previous);
		}
		
	};
}
