#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $ArrayType$124
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "$ArrayType=124", BNM::Image("Pathfinding.Ionic.Zip.Reduced.dll"));
		}
		
		
		
	};
}
