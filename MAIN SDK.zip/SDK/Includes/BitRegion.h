#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BitRegion
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BitRegion", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::Types::uint bitOffset;
		BNM::Types::uint sizeInBits;
		
		
	};
}
