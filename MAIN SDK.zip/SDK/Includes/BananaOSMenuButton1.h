#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BananaOSMenuButton1 : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BananaOSMenuButton1", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Collections.Generic.List`1<BananaOSMenuButton1/ToggledObject> */
		template <typename T = void* /*GENERICTYPE*/> T ObjectsToToggle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ObjectsToToggle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<BananaOSMenuButton1/ToggledObject> */
		void set_ObjectsToToggle(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("ObjectsToToggle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T buttonFadeTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("buttonFadeTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_buttonFadeTime(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("buttonFadeTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T isButtonToggled() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isButtonToggled");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_isButtonToggled(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("isButtonToggled");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T wasButtonToggled() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("wasButtonToggled");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_wasButtonToggled(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("wasButtonToggled");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ButtonActivation() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ButtonActivation", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Collections.IEnumerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ButtonColorUpdate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ButtonColorUpdate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
