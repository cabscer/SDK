#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AdjustmentRule : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AdjustmentRule", BNM::Image("mscorlib.dll"));
		}
		
		/* @brief Orig Type: System.DateTime */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _dateStart() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_dateStart");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.DateTime */
		void set__dateStart(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_dateStart");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.DateTime */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _dateEnd() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_dateEnd");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.DateTime */
		void set__dateEnd(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_dateEnd");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.TimeSpan */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _daylightDelta() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_daylightDelta");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.TimeSpan */
		void set__daylightDelta(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_daylightDelta");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.TimeZoneInfo/TransitionTime */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _daylightTransitionStart() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_daylightTransitionStart");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.TimeZoneInfo/TransitionTime */
		void set__daylightTransitionStart(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_daylightTransitionStart");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.TimeZoneInfo/TransitionTime */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _daylightTransitionEnd() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_daylightTransitionEnd");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.TimeZoneInfo/TransitionTime */
		void set__daylightTransitionEnd(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_daylightTransitionEnd");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.TimeSpan */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _baseUtcOffsetDelta() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_baseUtcOffsetDelta");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.TimeSpan */
		void set__baseUtcOffsetDelta(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_baseUtcOffsetDelta");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T _noDaylightTransitions() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_noDaylightTransitions");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set__noDaylightTransitions(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_noDaylightTransitions");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.DateTime */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_DateStart() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DateStart", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.DateTime */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_DateEnd() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DateEnd", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.TimeSpan */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_DaylightDelta() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DaylightDelta", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.TimeZoneInfo/TransitionTime */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_DaylightTransitionStart() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DaylightTransitionStart", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.TimeZoneInfo/TransitionTime */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_DaylightTransitionEnd() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DaylightTransitionEnd", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.TimeSpan */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_BaseUtcOffsetDelta() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BaseUtcOffsetDelta", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_NoDaylightTransitions() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NoDaylightTransitions", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_HasDaylightSaving() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_HasDaylightSaving", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T Equals(GlobalNamespace::AdjustmentRule* other) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Equals", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](other);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T GetHashCode() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetHashCode", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.TimeZoneInfo/AdjustmentRule */
		template <typename T = GlobalNamespace::AdjustmentRule*> static T CreateAdjustmentRule(BNM::IL2CPP::Il2CppObject* dateStart, BNM::IL2CPP::Il2CppObject* dateEnd, BNM::IL2CPP::Il2CppObject* daylightDelta, BNM::IL2CPP::Il2CppObject* daylightTransitionStart, BNM::IL2CPP::Il2CppObject* daylightTransitionEnd) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateAdjustmentRule", 5);
			return __bnm__method__(dateStart, dateEnd, daylightDelta, daylightTransitionStart, daylightTransitionEnd);
		}
		/* @brief Orig Type: System.TimeZoneInfo/AdjustmentRule */
		template <typename T = GlobalNamespace::AdjustmentRule*> static T CreateAdjustmentRule_1(BNM::IL2CPP::Il2CppObject* dateStart, BNM::IL2CPP::Il2CppObject* dateEnd, BNM::IL2CPP::Il2CppObject* daylightDelta, BNM::IL2CPP::Il2CppObject* daylightTransitionStart, BNM::IL2CPP::Il2CppObject* daylightTransitionEnd, BNM::IL2CPP::Il2CppObject* baseUtcOffsetDelta, bool noDaylightTransitions) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateAdjustmentRule", 7);
			return __bnm__method__(dateStart, dateEnd, daylightDelta, daylightTransitionStart, daylightTransitionEnd, baseUtcOffsetDelta, noDaylightTransitions);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T IsStartDateMarkerForBeginningOfYear() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsStartDateMarkerForBeginningOfYear", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T IsEndDateMarkerForEndOfYear() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsEndDateMarkerForEndOfYear", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ValidateAdjustmentRule(BNM::IL2CPP::Il2CppObject* dateStart, BNM::IL2CPP::Il2CppObject* dateEnd, BNM::IL2CPP::Il2CppObject* daylightDelta, BNM::IL2CPP::Il2CppObject* daylightTransitionStart, BNM::IL2CPP::Il2CppObject* daylightTransitionEnd, bool noDaylightTransitions) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidateAdjustmentRule", 6);
			return __bnm__method__(dateStart, dateEnd, daylightDelta, daylightTransitionStart, daylightTransitionEnd, noDaylightTransitions);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_Runtime_Serialization_IDeserializationCallback_OnDeserialization(BNM::IL2CPP::Il2CppObject* sender) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Runtime.Serialization.IDeserializationCallback.OnDeserialization", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](sender);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_Runtime_Serialization_ISerializable_GetObjectData(BNM::IL2CPP::Il2CppObject* info, BNM::IL2CPP::Il2CppObject* context) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Runtime.Serialization.ISerializable.GetObjectData", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](info, context);
		}
		
	};
}
