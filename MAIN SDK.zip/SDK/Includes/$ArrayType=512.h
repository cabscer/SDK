#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $ArrayType$512
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "$ArrayType=512", BNM::Image("Pathfinding.Ionic.Zip.Reduced.dll"));
		}
		
		
		
	};
}
