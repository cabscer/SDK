#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BoneCapsule
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BoneCapsule", BNM::Image("Oculus.VR.dll"));
		}
		
		short BoneIndex;
		BNM::IL2CPP::Il2CppObject* StartPoint;
		BNM::IL2CPP::Il2CppObject* EndPoint;
		float Radius;
		
		
	};
}
