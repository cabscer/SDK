#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AbductionStateBuilder : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AbductionStateBuilder", BNM::Image("Oculus.Interaction.dll"));
		}
		
		/* @brief Orig Type: Oculus.Interaction.PoseDetection.FeatureStateActiveMode */
		template <typename T = int> T _mode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_mode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: Oculus.Interaction.PoseDetection.FeatureStateActiveMode */
		void set__mode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_mode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: Oculus.Interaction.PoseDetection.ShapeRecognizer/FingerFeatureConfig */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_None() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_None", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: Oculus.Interaction.PoseDetection.ShapeRecognizer/FingerFeatureConfig */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Closed() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Closed", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: Oculus.Interaction.PoseDetection.ShapeRecognizer/FingerFeatureConfig */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Open() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Open", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
