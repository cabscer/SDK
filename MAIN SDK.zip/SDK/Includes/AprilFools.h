#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AprilFools

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AprilFools", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T changeIntervalSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("changeIntervalSeconds");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_changeIntervalSeconds(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("changeIntervalSeconds");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T lerpIntervalSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lerpIntervalSeconds");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_lerpIntervalSeconds(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("lerpIntervalSeconds");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T minRange() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("minRange");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_minRange(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("minRange");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T maxRange() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("maxRange");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_maxRange(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("maxRange");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T excludeRangeStart() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("excludeRangeStart");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_excludeRangeStart(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("excludeRangeStart");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T excludeRangeEnd() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("excludeRangeEnd");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_excludeRangeEnd(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("excludeRangeEnd");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T mod(int x, int m) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("mod", 2);
			return __bnm__method__(x, m);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T GenerateTarget(BNM::Structures::Mono::String* username, BNM::Structures::Mono::String* roomName, BNM::Structures::Mono::String* areaName, int startTime) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateTarget", 4);
			return __bnm__method__(username, roomName, areaName, startTime);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Slerp(float a, float b, float t) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Slerp", 3);
			return __bnm__method__(a, b, t);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T SmoothSlerp(float a, float b, float t) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SmoothSlerp", 3);
			return __bnm__method__(a, b, t);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T GenerateSmoothTarget(BNM::Structures::Mono::String* username, BNM::Structures::Mono::String* roomName, BNM::Structures::Mono::String* areaName) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateSmoothTarget", 3);
			return __bnm__method__(username, roomName, areaName);
		}
		
	};
}
