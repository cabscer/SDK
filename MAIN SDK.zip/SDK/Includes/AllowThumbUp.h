#pragma once
#include <BNMIncludes.hpp>

#undef Always
#undef GripRequired
#undef TriggerAndGripRequired
namespace GlobalNamespace {
	enum class AllowThumbUp : int
	{
		Always = 0,
		GripRequired = 1,
		TriggerAndGripRequired = 2
	};
}
