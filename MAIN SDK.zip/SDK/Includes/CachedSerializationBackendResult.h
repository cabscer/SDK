#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CachedSerializationBackendResult
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CachedSerializationBackendResult", BNM::Image("Sirenix.Serialization.dll"));
		}
		
		bool HasCalculatedSerializeUnityFieldsTrueResult;
		bool HasCalculatedSerializeUnityFieldsFalseResult;
		bool SerializeUnityFieldsTrueResult;
		bool SerializeUnityFieldsFalseResult;
		
		
	};
}
