#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AssetPackManagerMobileDataConfirmationCallback : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AssetPackManagerMobileDataConfirmationCallback", BNM::Image("UnityEngine.AndroidJNIModule.dll"));
		}
		
		/* @brief Orig Type: System.Action`1<UnityEngine.Android.AndroidAssetPackUseMobileDataRequestResult> */
		template <typename T = void* /*GENERICTYPE*/> T m_Callback() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Callback");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`1<UnityEngine.Android.AndroidAssetPackUseMobileDataRequestResult> */
		void set_m_Callback(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("m_Callback");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T onMobileDataConfirmationResult(bool allowed) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("onMobileDataConfirmationResult", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allowed);
		}
		
	};
}
