#pragma once
#include <BNMIncludes.hpp>

#undef RotateOverTime
#undef MatchDirection
namespace GlobalNamespace {
	enum class AnchorRotationMode : int
	{
		RotateOverTime = 0,
		MatchDirection = 1
	};
}
