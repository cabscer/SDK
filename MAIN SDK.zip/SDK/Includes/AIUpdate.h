#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AIUpdate
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AIUpdate", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		
	};
}
