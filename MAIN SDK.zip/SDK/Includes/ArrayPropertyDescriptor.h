#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ArrayPropertyDescriptor : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ArrayPropertyDescriptor", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T _index() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_index");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set__index(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_index");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetValue(BNM::IL2CPP::Il2CppObject* instance) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetValue", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](instance);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T SetValue(BNM::IL2CPP::Il2CppObject* instance, BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetValue", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](instance, $value);
		}
		
	};
}
