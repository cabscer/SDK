#pragma once
#include <BNMIncludes.hpp>

#undef Unknown
#undef WristPosBeta
#undef WristPosMinCutOff
#undef WristRotBeta
#undef WristRotMinCutOff
#undef FingerRotBeta
#undef FingerRotMinCutOff
#undef Frequency
#undef WristPosDeltaCutOff
#undef WristRotDeltaCutOff
#undef FingerRotDeltaCutOff
namespace GlobalNamespace {
	enum class AttributeId : int
	{
		Unknown = 0,
		WristPosBeta = 1,
		WristPosMinCutOff = 2,
		WristRotBeta = 3,
		WristRotMinCutOff = 4,
		FingerRotBeta = 5,
		FingerRotMinCutOff = 6,
		Frequency = 7,
		WristPosDeltaCutOff = 8,
		WristRotDeltaCutOff = 9,
		FingerRotDeltaCutOff = 10
	};
}
