#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BoolMonitor : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BoolMonitor", BNM::Image("Oculus.VR.dll"));
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T m_name() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_name");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_m_name(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("m_name");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: OVRHandTest/BoolMonitor/BoolGenerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_generator() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_generator");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: OVRHandTest/BoolMonitor/BoolGenerator */
		void set_m_generator(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_generator");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_prevValue() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_prevValue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_prevValue(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_prevValue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_currentValue() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_currentValue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_currentValue(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_currentValue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_currentValueRecentlyChanged() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_currentValueRecentlyChanged");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_currentValueRecentlyChanged(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_currentValueRecentlyChanged");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_displayTimeout() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_displayTimeout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_displayTimeout(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_displayTimeout");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_displayTimer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_displayTimer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_displayTimer(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_displayTimer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AppendToStringBuilder(BNM::IL2CPP::Il2CppObject* sb) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AppendToStringBuilder", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](sb);
		}
		
	};
}
