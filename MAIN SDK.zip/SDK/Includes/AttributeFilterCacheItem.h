#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AttributeFilterCacheItem : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AttributeFilterCacheItem", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Attribute[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T _filter() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_filter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Attribute[] */
		void set__filter(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("_filter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.ICollection */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T FilteredMembers() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FilteredMembers");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.ICollection */
		void set_FilteredMembers(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("FilteredMembers");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T IsValid(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* filter) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsValid", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](filter);
		}
		
	};
}
