#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BakeMeshJob
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeMeshJob", BNM::Image("Oculus.VR.dll"));
		}
		
		int MeshID;
		bool Convex;
		
		
	};
}
