#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BufferingParams : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BufferingParams", BNM::Image("Oculus.Interaction.dll"));
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> T BufferLengthSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BufferLengthSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_BufferLengthSeconds(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("BufferLengthSeconds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T SampleFrequency() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SampleFrequency");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_SampleFrequency(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("SampleFrequency");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Validate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Validate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
