#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AllocMeshData
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AllocMeshData", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* alloc;
		BNM::IL2CPP::Il2CppObject* texture;
		BNM::IL2CPP::Il2CppObject* svgTexture;
		BNM::IL2CPP::Il2CppObject* material;
		int flags;
		BNM::IL2CPP::Il2CppObject* colorAlloc;
		
		
	};
}
