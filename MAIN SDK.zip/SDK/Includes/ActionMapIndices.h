#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct ActionMapIndices
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "ActionMapIndices", BNM::Image("Unity.InputSystem.dll"));
		}
		
		int actionStartIndex;
		int actionCount;
		int controlStartIndex;
		int controlCount;
		int bindingStartIndex;
		int bindingCount;
		int interactionStartIndex;
		int interactionCount;
		int processorStartIndex;
		int processorCount;
		int compositeStartIndex;
		int compositeCount;
		
		
	};
}
