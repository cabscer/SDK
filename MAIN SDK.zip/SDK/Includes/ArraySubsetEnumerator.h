#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ArraySubsetEnumerator : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ArraySubsetEnumerator", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Array */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _array() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_array");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Array */
		void set__array(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_array");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T _total() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_total");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set__total(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_total");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T _current() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_current");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set__current(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_current");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T MoveNext() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MoveNext", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
