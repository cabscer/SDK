#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef CaptureInPlace
#undef CaptureToAsset
#undef LoadCaptured
namespace GlobalNamespace {
	enum class CaptureMode : int
	{
		None = -1,
		CaptureInPlace = 0,
		CaptureToAsset = 1,
		LoadCaptured = 2
	};
}
