#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $ArrayType$1152
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "$ArrayType=1152", BNM::Image("Pathfinding.Ionic.Zip.Reduced.dll"));
		}
		
		
		
	};
}
