#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryLightmapGroup : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryLightmapGroup", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T resolution() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("resolution");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_resolution(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("resolution");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T bitmask() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bitmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_bitmask(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("bitmask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T id() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("id");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_id(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("id");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T sortingID() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sortingID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_sortingID(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("sortingID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T isImplicit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isImplicit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_isImplicit(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("isImplicit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T area() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("area");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_area(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("area");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T totalVertexCount() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("totalVertexCount");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_totalVertexCount(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("totalVertexCount");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T vertexCounter() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("vertexCounter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_vertexCounter(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("vertexCounter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T sceneLodLevel() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sceneLodLevel");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_sceneLodLevel(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("sceneLodLevel");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T sceneName() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sceneName");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_sceneName(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("sceneName");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T containsTerrains() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("containsTerrains");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_containsTerrains(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("containsTerrains");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T probes() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("probes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_probes(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("probes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryLightmapGroup/ftLMGroupMode */
		template <typename T = int> T mode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("mode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryLightmapGroup/ftLMGroupMode */
		void set_mode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("mode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryLightmapGroup/RenderMode */
		template <typename T = int> T renderMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("renderMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryLightmapGroup/RenderMode */
		void set_renderMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("renderMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryLightmapGroup/RenderDirMode */
		template <typename T = int> T renderDirMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("renderDirMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryLightmapGroup/RenderDirMode */
		void set_renderDirMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("renderDirMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryLightmapGroup/AtlasPacker */
		template <typename T = int> T atlasPacker() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("atlasPacker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryLightmapGroup/AtlasPacker */
		void set_atlasPacker(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("atlasPacker");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T computeSSS() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("computeSSS");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_computeSSS(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("computeSSS");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T sssSamples() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sssSamples");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_sssSamples(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("sssSamples");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T sssDensity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sssDensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_sssDensity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("sssDensity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Color */
		template <typename T = BNM::Structures::Unity::Color> T sssColor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sssColor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Color */
		void set_sssColor(BNM::Structures::Unity::Color value) {
			static BNM::Field<BNM::Structures::Unity::Color> __bnm__field__ = StaticClass().GetField("sssColor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T sssScale() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sssScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_sssScale(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("sssScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T fakeShadowBias() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("fakeShadowBias");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_fakeShadowBias(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("fakeShadowBias");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T transparentSelfShadow() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("transparentSelfShadow");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_transparentSelfShadow(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("transparentSelfShadow");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T flipNormal() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("flipNormal");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_flipNormal(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("flipNormal");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T parentName() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("parentName");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_parentName(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("parentName");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T overridePath() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("overridePath");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_overridePath(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("overridePath");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T fixPos3D() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("fixPos3D");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_fixPos3D(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("fixPos3D");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T voxelSize() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("voxelSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_voxelSize(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("voxelSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T passedFilter() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("passedFilter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_passedFilter(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("passedFilter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: BakeryLightmapGroupPlain */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetPlainStruct() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetPlainStruct", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
