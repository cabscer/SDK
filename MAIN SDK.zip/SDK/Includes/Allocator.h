#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Allocator : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Allocator", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		
		/* @brief Orig Type: UnityEngine.UIElements.MeshWriteData */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Invoke(BNM::Types::uint vertexCount, BNM::Types::uint indexCount, BNM::IL2CPP::Il2CppObject* allocatorData) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](vertexCount, indexCount, allocatorData);
		}
		
	};
}
