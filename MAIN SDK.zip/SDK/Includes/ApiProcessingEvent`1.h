#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ApiProcessingEvent$1 : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ApiProcessingEvent`1", BNM::Image("PlayFab.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Invoke(void* e) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](e);
		}
		/* @brief Orig Type: System.IAsyncResult */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T BeginInvoke(void* e, BNM::IL2CPP::Il2CppObject* callback, BNM::IL2CPP::Il2CppObject* $object) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BeginInvoke", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](e, callback, $object);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EndInvoke(BNM::IL2CPP::Il2CppObject* result) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EndInvoke", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](result);
		}
		
	};
}
