#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AttributeTypeDescriptor : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AttributeTypeDescriptor", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Attribute[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T _attributeArray() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_attributeArray");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Attribute[] */
		void set__attributeArray(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("_attributeArray");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.ComponentModel.AttributeCollection */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetAttributes() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttributes", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
