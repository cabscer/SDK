#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $ArrayType$12
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "$ArrayType=12", BNM::Image("Pathfinding.Ionic.Zip.Reduced.dll"));
		}
		
		
		
	};
}
