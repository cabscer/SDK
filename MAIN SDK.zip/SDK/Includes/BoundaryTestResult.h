#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BoundaryTestResult
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BoundaryTestResult", BNM::Image("Oculus.VR.dll"));
		}
		
		int IsTriggering;
		float ClosestDistance;
		BNM::IL2CPP::Il2CppObject* ClosestPoint;
		BNM::IL2CPP::Il2CppObject* ClosestPointNormal;
		
		
	};
}
