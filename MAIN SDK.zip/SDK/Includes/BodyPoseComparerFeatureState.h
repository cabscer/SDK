#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BodyPoseComparerFeatureState
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BodyPoseComparerFeatureState", BNM::Image("Oculus.Interaction.dll"));
		}
		
		float Delta;
		float MaxDelta;
		
		
	};
}
