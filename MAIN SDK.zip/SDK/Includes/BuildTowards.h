#pragma once
#include <BNMIncludes.hpp>

#undef Steam
#undef OculusPC
#undef Quest
#undef Viveport
namespace GlobalNamespace {
	enum class BuildTowards : int
	{
		Steam = 0,
		OculusPC = 1,
		Quest = 2,
		Viveport = 3
	};
}
