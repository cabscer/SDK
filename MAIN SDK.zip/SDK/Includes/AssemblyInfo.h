#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AssemblyInfo : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AssemblyInfo", BNM::Image("MeshBakerCore.dll"));
		}
		
		
		
	};
}
