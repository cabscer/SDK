#pragma once
#include <BNMIncludes.hpp>

namespace AA {
	class Spring : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("AA", "Spring", BNM::Image("Assembly-CSharp.dll"));
		}
		
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Damper(float x, float g, float factor) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Damper", 3);
			return __bnm__method__(x, g, factor);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T DamperExponential(float x, float g, float damping, float dt, float ft) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DamperExponential", 5);
			return __bnm__method__(x, g, damping, dt, ft);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T FastNegExp(float x) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FastNegExp", 1);
			return __bnm__method__(x);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T DamperExact(float x, float g, float halflife, float dt, float eps) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DamperExact", 5);
			return __bnm__method__(x, g, halflife, dt, eps);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T DamperDecayExact(float x, float halflife, float dt, float eps) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DamperDecayExact", 4);
			return __bnm__method__(x, halflife, dt, eps);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T CopySign(float a, float s) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CopySign", 2);
			return __bnm__method__(a, s);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T FastAtan(float x) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FastAtan", 1);
			return __bnm__method__(x);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Square(float x) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Square", 1);
			return __bnm__method__(x);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T SpringDamperExactStiffnessDamping(BNM::IL2CPP::Il2CppObject* x, BNM::IL2CPP::Il2CppObject* v, float x_goal, float v_goal, float stiffness, float damping, float dt, float eps) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SpringDamperExactStiffnessDamping", 8);
			return __bnm__method__(x, v, x_goal, v_goal, stiffness, damping, dt, eps);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T HalflifeToDamping(float halflife, float eps) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HalflifeToDamping", 2);
			return __bnm__method__(halflife, eps);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T DampingToHalflife(float damping, float eps) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DampingToHalflife", 2);
			return __bnm__method__(damping, eps);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T FrequencyToStiffness(float frequency) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FrequencyToStiffness", 1);
			return __bnm__method__(frequency);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T stiffness_to_frequency(float stiffness) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("stiffness_to_frequency", 1);
			return __bnm__method__(stiffness);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T critical_halflife(float frequency) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("critical_halflife", 1);
			return __bnm__method__(frequency);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T critical_frequency(float halflife) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("critical_frequency", 1);
			return __bnm__method__(halflife);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T SpringDamperExact(BNM::IL2CPP::Il2CppObject* x, BNM::IL2CPP::Il2CppObject* v, float x_goal, float v_goal, float frequency, float halflife, float dt, float eps) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SpringDamperExact", 8);
			return __bnm__method__(x, v, x_goal, v_goal, frequency, halflife, dt, eps);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T DampingRatioToStiffness(float ratio, float damping) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DampingRatioToStiffness", 2);
			return __bnm__method__(ratio, damping);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T DampingRatioToDamping(float ratio, float stiffness) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DampingRatioToDamping", 2);
			return __bnm__method__(ratio, stiffness);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T SpringDamperExactRatio(BNM::IL2CPP::Il2CppObject* x, BNM::IL2CPP::Il2CppObject* v, float x_goal, float v_goal, float damping_ratio, float halflife, float dt, float eps) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SpringDamperExactRatio", 8);
			return __bnm__method__(x, v, x_goal, v_goal, damping_ratio, halflife, dt, eps);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T CriticalSpringDamperExact(BNM::IL2CPP::Il2CppObject* x, BNM::IL2CPP::Il2CppObject* v, float x_goal, float v_goal, float halflife, float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CriticalSpringDamperExact", 6);
			return __bnm__method__(x, v, x_goal, v_goal, halflife, dt);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T SimpleSpringDamperExact(BNM::IL2CPP::Il2CppObject* x, BNM::IL2CPP::Il2CppObject* v, float x_goal, float halflife, float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SimpleSpringDamperExact", 5);
			return __bnm__method__(x, v, x_goal, halflife, dt);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T DecaySringDamperExact(BNM::IL2CPP::Il2CppObject* x, BNM::IL2CPP::Il2CppObject* v, float halflife, float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DecaySringDamperExact", 4);
			return __bnm__method__(x, v, halflife, dt);
		}
		
	};
}
