#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Enter
#undef Crescendo
#undef Loop
#undef Exit
namespace GlobalNamespace {
	enum class AudioState : int
	{
		None = 0,
		Enter = 1,
		Crescendo = 2,
		Loop = 3,
		Exit = 4
	};
}
