#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakerySector : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakerySector", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		/* @brief Orig Type: BakerySector/CaptureMode */
		template <typename T = int> T captureMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("captureMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakerySector/CaptureMode */
		void set_captureMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("captureMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T captureAssetName() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("captureAssetName");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_captureAssetName(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("captureAssetName");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakerySectorCapture */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T captureAsset() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("captureAsset");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakerySectorCapture */
		void set_captureAsset(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("captureAsset");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T allowUVPaddingAdjustment() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("allowUVPaddingAdjustment");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_allowUVPaddingAdjustment(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("allowUVPaddingAdjustment");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.Transform> */
		template <typename T = void* /*GENERICTYPE*/> T tforms() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("tforms");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.Transform> */
		void set_tforms(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("tforms");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.Transform> */
		template <typename T = void* /*GENERICTYPE*/> T cpoints() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("cpoints");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.Transform> */
		void set_cpoints(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("cpoints");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDrawGizmosSelected() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDrawGizmosSelected", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
