#pragma once
#include <BNMIncludes.hpp>

#undef RedTeam
#undef BlueTeam
#undef Normal
#undef Hit
#undef Stunned
#undef Grace
#undef Eliminated
#undef None
namespace GlobalNamespace {
	enum class BattleStatus : int
	{
		RedTeam = 1,
		BlueTeam = 2,
		Normal = 4,
		Hit = 8,
		Stunned = 16,
		Grace = 32,
		Eliminated = 64,
		None = 0
	};
}
