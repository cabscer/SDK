#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BinderState : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BinderState", BNM::Image("mscorlib.dll"));
		}
		
		/* @brief Orig Type: System.Int32[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T m_argsMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_argsMap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32[] */
		void set_m_argsMap(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("m_argsMap");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_originalSize() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_originalSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_originalSize(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_originalSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_isParamArray() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_isParamArray");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_isParamArray(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_isParamArray");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		
	};
}
