#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BundleList : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BundleList", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T activeBundleIdx() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("activeBundleIdx");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_activeBundleIdx(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("activeBundleIdx");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BundleData[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T data() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("data");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BundleData[] */
		void set_data(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("data");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FromJson(BNM::Structures::Mono::String* jsonString) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromJson", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](jsonString);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T HasSku(BNM::Structures::Mono::String* skuName, BNM::IL2CPP::Il2CppObject** idx) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HasSku", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](skuName, idx);
		}
		/* @brief Orig Type: BundleData */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ActiveBundle() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ActiveBundle", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
