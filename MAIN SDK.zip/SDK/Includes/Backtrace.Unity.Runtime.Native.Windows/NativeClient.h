#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Runtime {
			namespace Native {
				namespace Windows {
					class NativeClient : public BNM::IL2CPP::Il2CppObject
					{
						public:
						static BNM::Class StaticClass() {
							return BNM::Class("Backtrace.Unity.Runtime.Native.Windows", "NativeClient", BNM::Image("Backtrace.Unity.dll"));
						}
						
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T ScopedAttributeListKey() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ScopedAttributeListKey");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_ScopedAttributeListKey(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ScopedAttributeListKey");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T ScopedAttributesPattern() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ScopedAttributesPattern");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_ScopedAttributesPattern(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ScopedAttributesPattern");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T VersionKey() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("VersionKey");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_VersionKey(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("VersionKey");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T MachineUuidKey() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MachineUuidKey");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_MachineUuidKey(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("MachineUuidKey");
							__bnm__field__.Set(value);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> static T SessionKey() {
							static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SessionKey");
							return __bnm__field__();
						}
						/* @param value Orig Type: System.String */
						static void set_SessionKey(BNM::Structures::Mono::String* value) {
							static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("SessionKey");
							__bnm__field__.Set(value);
						}
						
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> static T Initialize(BNM::Structures::Mono::String* submissionUrl, BNM::Structures::Mono::String* databasePath, BNM::Structures::Mono::String* handlerPath, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* attachments, int attachmentSize) {
							static auto __bnm__method__ = (T(*)(BNM::Structures::Mono::String*, BNM::Structures::Mono::String*, BNM::Structures::Mono::String*, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*, int))BNM::GetExternMethod("Backtrace.Unity.Runtime.Native.Windows::NativeClient::Initialize");
							return (T)__bnm__method__(submissionUrl, databasePath, handlerPath, attachments, attachmentSize);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> static T AddNativeAttribute(BNM::Structures::Mono::String* key, BNM::Structures::Mono::String* $value) {
							static auto __bnm__method__ = (T(*)(BNM::Structures::Mono::String*, BNM::Structures::Mono::String*))BNM::GetExternMethod("Backtrace.Unity.Runtime.Native.Windows::NativeClient::AddNativeAttribute");
							return (T)__bnm__method__(key, $value);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> static T NativeReport(BNM::Structures::Mono::String* message, bool setMainThreadAsFaultingThread) {
							static auto __bnm__method__ = (T(*)(BNM::Structures::Mono::String*, bool))BNM::GetExternMethod("Backtrace.Unity.Runtime.Native.Windows::NativeClient::NativeReport");
							return (T)__bnm__method__(message, setMainThreadAsFaultingThread);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T HandleNativeCrashes(void* /*GENERICTYPE*/ clientAttributes, void* /*GENERICTYPE*/ attachments) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleNativeCrashes", 2);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clientAttributes, attachments);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T Isx86Build(BNM::Structures::Mono::String* pluginDirectoryPath) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Isx86Build", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](pluginDirectoryPath);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T GetAttributes(void* /*GENERICTYPE*/ attributes) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttributes", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T HandleAnr() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleAnr", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> T OnOOM() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnOOM", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T SetAttribute(BNM::Structures::Mono::String* key, BNM::Structures::Mono::String* $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetAttribute", 2);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
						}
						/* @brief Orig Type: System.Collections.IEnumerator */
						template <typename T = BNM::IL2CPP::Il2CppObject*> T SendMinidumpOnStartup(void* /*GENERICTYPE*/ clientAttachments, BNM::IL2CPP::Il2CppObject* backtraceApi) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendMinidumpOnStartup", 2);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clientAttachments, backtraceApi);
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T GetPluginDirectoryPath() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetPluginDirectoryPath", 0);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
						}
						/* @brief Orig Type: System.String */
						template <typename T = BNM::Structures::Mono::String*> T GetDefaultPathToCrashpadHandler(BNM::Structures::Mono::String* pluginDirectoryPath) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetDefaultPathToCrashpadHandler", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](pluginDirectoryPath);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> static T CleanScopedAttributes() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CleanScopedAttributes", 0);
							return __bnm__method__();
						}
						/* @brief Orig Type: System.Collections.Generic.IDictionary`2<System.String,System.String> */
						template <typename T = void* /*GENERICTYPE*/> static T GetScopedAttributes() {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetScopedAttributes", 0);
							return __bnm__method__();
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T AddAttributes(BNM::Structures::Mono::String* key, BNM::Structures::Mono::String* $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddAttributes", 2);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T AddScopedAttributes(void* /*GENERICTYPE*/ attributes) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddScopedAttributes", 1);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](attributes);
						}
						/* @brief Orig Type: System.Void */
						template <typename T = void> T AddScopedAttribute(BNM::Structures::Mono::String* key, BNM::Structures::Mono::String* $value) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddScopedAttribute", 2);
							return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](key, $value);
						}
						/* @brief Orig Type: System.Boolean */
						template <typename T = bool> static T HasScopedAttributesEmpty(BNM::Structures::Mono::String* attributesJson) {
							static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HasScopedAttributesEmpty", 1);
							return __bnm__method__(attributesJson);
						}
						
					};
				}
			}
		}
	}
}
