#pragma once
#include <BNMIncludes.hpp>

#undef Point
#undef Sphere
#undef Capsule
namespace GlobalNamespace {
	enum class AimCollisionTypes : int
	{
		Point = 0,
		Sphere = 1,
		Capsule = 2
	};
}
