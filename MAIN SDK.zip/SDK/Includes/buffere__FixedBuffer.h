#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $buffer$e__FixedBuffer
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "<buffer>e__FixedBuffer", BNM::Image("Unity.InputSystem.dll"));
		}
		
		char FixedElementField;
		
		
	};
}
