#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CachedCodeEntryKey
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CachedCodeEntryKey", BNM::Image("System.dll"));
		}
		
		int _options;
		BNM::Structures::Mono::String* _cultureKey;
		BNM::Structures::Mono::String* _pattern;
		
		
	};
}
