#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Alloc2D
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Alloc2D", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* rect;
		BNM::IL2CPP::Il2CppObject* row;
		BNM::IL2CPP::Il2CppObject* alloc;
		
		
	};
}
