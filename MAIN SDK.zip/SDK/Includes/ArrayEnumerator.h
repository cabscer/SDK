#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ArrayEnumerator : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ArrayEnumerator", BNM::Image("mscorlib.dll"));
		}
		
		/* @brief Orig Type: System.Array */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _array() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_array");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Array */
		void set__array(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_array");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T _index() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_index");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set__index(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_index");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T _endIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_endIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set__endIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_endIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T MoveNext() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MoveNext", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Clone() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clone", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
