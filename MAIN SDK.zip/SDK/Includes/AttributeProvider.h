#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AttributeProvider : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AttributeProvider", BNM::Image("System.dll"));
		}
		
		/* @brief Orig Type: System.Attribute[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T _attrs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_attrs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Attribute[] */
		void set__attrs(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("_attrs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.ComponentModel.ICustomTypeDescriptor */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetTypeDescriptor(BNM::MonoType* objectType, BNM::IL2CPP::Il2CppObject* instance) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetTypeDescriptor", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](objectType, instance);
		}
		
	};
}
