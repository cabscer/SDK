#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class MachineIdStorage : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "MachineIdStorage", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T MachineIdentifierKey() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MachineIdentifierKey");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_MachineIdentifierKey(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("MachineIdentifierKey");
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GenerateMachineId() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GenerateMachineId", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T FetchMachineIdFromStorage() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FetchMachineIdFromStorage", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T StoreMachineId(BNM::Structures::Mono::String* machineId) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StoreMachineId", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](machineId);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T UseUnityIdentifier() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UseUnityIdentifier", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T UseNetworkingIdentifier() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UseNetworkingIdentifier", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
