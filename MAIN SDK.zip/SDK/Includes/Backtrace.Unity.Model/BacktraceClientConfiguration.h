#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceClientConfiguration : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceClientConfiguration", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T ServerUrl() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ServerUrl");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_ServerUrl(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ServerUrl");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T ReportPerMin() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ReportPerMin");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_ReportPerMin(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("ReportPerMin");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T HandleUnhandledExceptions() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("HandleUnhandledExceptions");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_HandleUnhandledExceptions(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("HandleUnhandledExceptions");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T IgnoreSslValidation() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("IgnoreSslValidation");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_IgnoreSslValidation(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("IgnoreSslValidation");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T DestroyOnLoad() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DestroyOnLoad");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_DestroyOnLoad(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DestroyOnLoad");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T HandleANR() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("HandleANR");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_HandleANR(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("HandleANR");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T OomReports() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OomReports");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_OomReports(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("OomReports");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T GameObjectDepth() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("GameObjectDepth");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_GameObjectDepth(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("GameObjectDepth");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.MiniDumpType */
				template <typename T = BNM::Types::uint> T MinidumpType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MinidumpType");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.MiniDumpType */
				void set_MinidumpType(BNM::Types::uint value) {
					static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("MinidumpType");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Void */
				template <typename T = void> T UpdateServerUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateServerUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ValidateServerUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidateServerUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
