#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceDefaultClassifierTypes : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceDefaultClassifierTypes", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T MessageType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MessageType");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_MessageType(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("MessageType");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T ExceptionType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ExceptionType");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_ExceptionType(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ExceptionType");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T UnhandledExceptionType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UnhandledExceptionType");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_UnhandledExceptionType(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("UnhandledExceptionType");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T OOMExceptionType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OOMExceptionType");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_OOMExceptionType(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("OOMExceptionType");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T AnrExceptionType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AnrExceptionType");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_AnrExceptionType(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("AnrExceptionType");
					__bnm__field__.Set(value);
				}
				
				
			};
		}
	}
}
