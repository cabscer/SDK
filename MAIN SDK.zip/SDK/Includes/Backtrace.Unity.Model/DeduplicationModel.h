#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class DeduplicationModel : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "DeduplicationModel", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceData */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _backtraceData() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_backtraceData");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.BacktraceData */
				void set__backtraceData(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_backtraceData");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				template <typename T = int> T _strategy() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_strategy");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				void set__strategy(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_strategy");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_StackTrace() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_StackTrace", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Classifier() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Classifier", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_ExceptionMessage() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ExceptionMessage", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Factor() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Factor", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetSha() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSha", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
