#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceHttpClient : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceHttpClient", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T $IgnoreSslValidation$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$IgnoreSslValidation$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_$IgnoreSslValidation$(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$IgnoreSslValidation$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T DiagnosticFileName() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DiagnosticFileName");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_DiagnosticFileName(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("DiagnosticFileName");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T RequestTimeout() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RequestTimeout");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_RequestTimeout(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("RequestTimeout");
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T get_IgnoreSslValidation() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IgnoreSslValidation", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_IgnoreSslValidation(bool $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_IgnoreSslValidation", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Post(BNM::Structures::Mono::String* submissionUrl, BNM::IL2CPP::Il2CppObject* jObject, void* /*GENERICTYPE*/ onComplete) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Post", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](submissionUrl, jObject, onComplete);
				}
				/* @brief Orig Type: UnityEngine.Networking.UnityWebRequest */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Post_1(BNM::Structures::Mono::String* submissionUrl, BNM::Structures::Mono::String* json, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Post", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](submissionUrl, json, attachments, attributes);
				}
				/* @brief Orig Type: UnityEngine.Networking.UnityWebRequest */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Post_2(BNM::Structures::Mono::String* submissionUrl, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* minidump, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Post", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](submissionUrl, minidump, attachments, attributes);
				}
				/* @brief Orig Type: UnityEngine.Networking.UnityWebRequest */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Post_3(BNM::Structures::Mono::String* submissionUrl, void* /*GENERICTYPE*/ formData) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Post", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](submissionUrl, formData);
				}
				/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.Networking.IMultipartFormSection> */
				template <typename T = void* /*GENERICTYPE*/> T CreateJsonFormData(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* json, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateJsonFormData", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](json, attachments, attributes);
				}
				/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.Networking.IMultipartFormSection> */
				template <typename T = void* /*GENERICTYPE*/> T CreateMinidumpFormData(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* minidump, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateMinidumpFormData", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](minidump, attachments, attributes);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AddAttributesToFormData(void* /*GENERICTYPE*/ formData, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddAttributesToFormData", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](formData, attributes);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AddAttachmentToFormData(void* /*GENERICTYPE*/ formData, void* /*GENERICTYPE*/ attachments) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddAttachmentToFormData", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](formData, attachments);
				}
				
			};
		}
	}
}
