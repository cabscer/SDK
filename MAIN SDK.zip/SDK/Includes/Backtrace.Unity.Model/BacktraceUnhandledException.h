#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceUnhandledException : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceUnhandledException", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T _header() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_header");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set__header(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_header");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String[] */
				template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T _javaExtensions() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_javaExtensions");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String[] */
				static void set__javaExtensions(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
					static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("_javaExtensions");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T _message() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_message");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set__message(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_message");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T $Classifier$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Classifier$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_$Classifier$(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$Classifier$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T _stacktrace() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_stacktrace");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set__stacktrace(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_stacktrace");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: UnityEngine.LogType */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T $Type$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Type$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: UnityEngine.LogType */
				void set_$Type$(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$Type$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.BacktraceStackFrame> */
				template <typename T = void* /*GENERICTYPE*/> T StackFrames() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("StackFrames");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.BacktraceStackFrame> */
				void set_StackFrames(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("StackFrames");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T get_Header() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Header", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Message() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Message", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Classifier() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Classifier", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Classifier(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Classifier", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_StackTrace() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_StackTrace", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: UnityEngine.LogType */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Type() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Type", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Type(int $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Type", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetStackTraceErrorMessage(BNM::Structures::Mono::String* beginningOfTheFrame) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetStackTraceErrorMessage", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](beginningOfTheFrame);
				}
				/* @brief Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.BacktraceStackFrame> */
				template <typename T = void* /*GENERICTYPE*/> T ConvertStackFrames(void* /*GENERICTYPE*/ frames) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ConvertStackFrames", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](frames);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceStackFrame */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T ConvertFrame(BNM::Structures::Mono::String* frameString, int methodNameEndIndex) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ConvertFrame", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](frameString, methodNameEndIndex);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceStackFrame */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SetJITStackTraceInformation(BNM::Structures::Mono::String* frameString) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetJITStackTraceInformation", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](frameString);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceStackFrame */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SetNativeStackTraceInformation(BNM::Structures::Mono::String* frameString) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetNativeStackTraceInformation", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](frameString);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceStackFrame */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SetAndroidStackTraceInformation(BNM::Structures::Mono::String* frameString, int parameterStart, int parameterEnd) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetAndroidStackTraceInformation", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](frameString, parameterStart, parameterEnd);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceStackFrame */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SetDefaultStackTraceInformation(BNM::Structures::Mono::String* frameString, int methodNameEndIndex) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetDefaultStackTraceInformation", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](frameString, methodNameEndIndex);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T TrySetClassifier() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TrySetClassifier", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
