#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceStackTrace : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceStackTrace", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.BacktraceStackFrame> */
				template <typename T = void* /*GENERICTYPE*/> T StackFrames() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("StackFrames");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.BacktraceStackFrame> */
				void set_StackFrames(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("StackFrames");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Exception */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T _exception() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_exception");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Exception */
				void set__exception(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_exception");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Initialize() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Initialize", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetStacktraceInformation(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* frames, bool generatedByException) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetStacktraceInformation", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](frames, generatedByException);
				}
				
			};
		}
	}
}
