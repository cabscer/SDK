#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceDatabaseConfiguration : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceDatabaseConfiguration", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Enabled() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Enabled");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_Enabled(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("Enabled");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T DatabasePath() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DatabasePath");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_DatabasePath(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("DatabasePath");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AutoSendMode() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AutoSendMode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_AutoSendMode(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("AutoSendMode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T CreateDatabase() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CreateDatabase");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_CreateDatabase(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("CreateDatabase");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T GenerateScreenshotOnException() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("GenerateScreenshotOnException");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_GenerateScreenshotOnException(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("GenerateScreenshotOnException");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				template <typename T = int> T DeduplicationStrategy() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DeduplicationStrategy");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				void set_DeduplicationStrategy(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DeduplicationStrategy");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T MaxRecordCount() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxRecordCount");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_MaxRecordCount(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("MaxRecordCount");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T MaxDatabaseSize() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxDatabaseSize");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int64 */
				void set_MaxDatabaseSize(int64_t value) {
					static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("MaxDatabaseSize");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T RetryInterval() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RetryInterval");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_RetryInterval(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("RetryInterval");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T RetryLimit() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RetryLimit");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_RetryLimit(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("RetryLimit");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.RetryOrder */
				template <typename T = int> T RetryOrder() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RetryOrder");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.RetryOrder */
				void set_RetryOrder(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("RetryOrder");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ValidDatabasePath() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidDatabasePath", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
