#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceStackFrame : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceStackFrame", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String[] */
				template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T _frameSeparators() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_frameSeparators");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String[] */
				static void set__frameSeparators(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
					static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("_frameSeparators");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T FunctionName() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FunctionName");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_FunctionName(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("FunctionName");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.BacktraceStackFrameType */
				template <typename T = int> T StackFrameType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("StackFrameType");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.BacktraceStackFrameType */
				void set_StackFrameType(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("StackFrameType");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T Line() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Line");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_Line(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("Line");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T MemberInfo() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MemberInfo");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_MemberInfo(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("MemberInfo");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T SourceCodeFullPath() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SourceCodeFullPath");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_SourceCodeFullPath(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("SourceCodeFullPath");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T Column() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Column");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_Column(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("Column");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T ILOffset() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ILOffset");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_ILOffset(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("ILOffset");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T SourceCode() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SourceCode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_SourceCode(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("SourceCode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T Address() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Address");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_Address(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Address");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T Assembly() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Assembly");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_Assembly(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Assembly");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T $InvalidFrame$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$InvalidFrame$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_$InvalidFrame$(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$InvalidFrame$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T Library() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Library");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_Library(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Library");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_FileName() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_FileName", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T get_InvalidFrame() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_InvalidFrame", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_InvalidFrame(bool $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_InvalidFrame", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: Backtrace.Unity.Json.BacktraceJObject */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T ToJson() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetMethodName(BNM::IL2CPP::Il2CppObject* method) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetMethodName", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](method);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetFileNameFromLibraryName() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetFileNameFromLibraryName", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetFileNameFromFunctionName() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetFileNameFromFunctionName", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T ToString() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToString", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
