#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceConfiguration : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceConfiguration", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
				template <typename T = int> static T AllBreadcrumbsTypes() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AllBreadcrumbsTypes");
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
				static void set_AllBreadcrumbsTypes(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("AllBreadcrumbsTypes");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
				template <typename T = int> static T AllLogTypes() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AllLogTypes");
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
				static void set_AllLogTypes(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("AllLogTypes");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T DefaultAnrWatchdogTimeout() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultAnrWatchdogTimeout");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_DefaultAnrWatchdogTimeout(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultAnrWatchdogTimeout");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T DefaultRetryLimit() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultRetryLimit");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_DefaultRetryLimit(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultRetryLimit");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T DefaultReportPerMin() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultReportPerMin");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_DefaultReportPerMin(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultReportPerMin");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T DefaultGameObjectDepth() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultGameObjectDepth");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_DefaultGameObjectDepth(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultGameObjectDepth");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T DefaultNumberOfLogs() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultNumberOfLogs");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_DefaultNumberOfLogs(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultNumberOfLogs");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T DefaultMaxRecordCount() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultMaxRecordCount");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_DefaultMaxRecordCount(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultMaxRecordCount");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T DefaultMaxDatabaseSize() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultMaxDatabaseSize");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_DefaultMaxDatabaseSize(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultMaxDatabaseSize");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> static T DefaultRetryInterval() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DefaultRetryInterval");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				static void set_DefaultRetryInterval(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DefaultRetryInterval");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T ServerUrl() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ServerUrl");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_ServerUrl(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ServerUrl");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T Token() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Token");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_Token(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Token");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T ReportPerMin() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ReportPerMin");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_ReportPerMin(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("ReportPerMin");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T DisableInEditor() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DisableInEditor");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_DisableInEditor(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DisableInEditor");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T HandleUnhandledExceptions() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("HandleUnhandledExceptions");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_HandleUnhandledExceptions(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("HandleUnhandledExceptions");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T IgnoreSslValidation() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("IgnoreSslValidation");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_IgnoreSslValidation(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("IgnoreSslValidation");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T DestroyOnLoad() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DestroyOnLoad");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_DestroyOnLoad(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DestroyOnLoad");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Double */
				template <typename T = double> T Sampling() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Sampling");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Double */
				void set_Sampling(double value) {
					static BNM::Field<double> __bnm__field__ = StaticClass().GetField("Sampling");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.ReportFilterType */
				template <typename T = int> T ReportFilterType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ReportFilterType");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.ReportFilterType */
				void set_ReportFilterType(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("ReportFilterType");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T GameObjectDepth() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("GameObjectDepth");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_GameObjectDepth(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("GameObjectDepth");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T NumberOfLogs() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("NumberOfLogs");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.UInt32 */
				void set_NumberOfLogs(BNM::Types::uint value) {
					static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("NumberOfLogs");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T PerformanceStatistics() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PerformanceStatistics");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_PerformanceStatistics(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("PerformanceStatistics");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T SendUnhandledGameCrashesOnGameStartup() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SendUnhandledGameCrashesOnGameStartup");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_SendUnhandledGameCrashesOnGameStartup(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("SendUnhandledGameCrashesOnGameStartup");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T CaptureNativeCrashes() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CaptureNativeCrashes");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_CaptureNativeCrashes(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("CaptureNativeCrashes");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T HandleANR() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("HandleANR");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_HandleANR(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("HandleANR");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T AnrWatchdogTimeout() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AnrWatchdogTimeout");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_AnrWatchdogTimeout(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("AnrWatchdogTimeout");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				template <typename T = int> T DeduplicationStrategy() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DeduplicationStrategy");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
				void set_DeduplicationStrategy(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("DeduplicationStrategy");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T EnableBreadcrumbsSupport() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnableBreadcrumbsSupport");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_EnableBreadcrumbsSupport(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnableBreadcrumbsSupport");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
				template <typename T = int> T BacktraceBreadcrumbsLevel() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BacktraceBreadcrumbsLevel");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
				void set_BacktraceBreadcrumbsLevel(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("BacktraceBreadcrumbsLevel");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
				template <typename T = int> T LogLevel() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LogLevel");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
				void set_LogLevel(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("LogLevel");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T UseNormalizedExceptionMessage() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UseNormalizedExceptionMessage");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_UseNormalizedExceptionMessage(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("UseNormalizedExceptionMessage");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.MiniDumpType */
				template <typename T = BNM::Types::uint> T MinidumpType() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MinidumpType");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.MiniDumpType */
				void set_MinidumpType(BNM::Types::uint value) {
					static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("MinidumpType");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T GenerateScreenshotOnException() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("GenerateScreenshotOnException");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_GenerateScreenshotOnException(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("GenerateScreenshotOnException");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String[] */
				template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T AttachmentPaths() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AttachmentPaths");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String[] */
				void set_AttachmentPaths(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
					static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("AttachmentPaths");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T DatabasePath() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DatabasePath");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_DatabasePath(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("DatabasePath");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T EnableMetricsSupport() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnableMetricsSupport");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_EnableMetricsSupport(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnableMetricsSupport");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T TimeIntervalInMin() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TimeIntervalInMin");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.UInt32 */
				void set_TimeIntervalInMin(BNM::Types::uint value) {
					static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("TimeIntervalInMin");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Enabled() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Enabled");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_Enabled(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("Enabled");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AddUnityLogToReport() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AddUnityLogToReport");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_AddUnityLogToReport(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("AddUnityLogToReport");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T AutoSendMode() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AutoSendMode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_AutoSendMode(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("AutoSendMode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T CreateDatabase() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CreateDatabase");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_CreateDatabase(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("CreateDatabase");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T MaxRecordCount() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxRecordCount");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_MaxRecordCount(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("MaxRecordCount");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T MaxDatabaseSize() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxDatabaseSize");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int64 */
				void set_MaxDatabaseSize(int64_t value) {
					static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("MaxDatabaseSize");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T RetryInterval() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RetryInterval");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_RetryInterval(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("RetryInterval");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T RetryLimit() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RetryLimit");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_RetryLimit(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("RetryLimit");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.RetryOrder */
				template <typename T = int> T RetryOrder() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RetryOrder");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.RetryOrder */
				void set_RetryOrder(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("RetryOrder");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Collections.Generic.HashSet`1<System.String> */
				template <typename T = void* /*GENERICTYPE*/> T GetAttachmentPaths() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAttachmentPaths", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetUniverseName() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetUniverseName", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetToken() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetToken", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetFullDatabasePath() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetFullDatabasePath", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_CrashpadDatabasePath() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_CrashpadDatabasePath", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetValidServerUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetValidServerUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T UpdateServerUrl(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateServerUrl", 1);
					return __bnm__method__($value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> static T ValidateServerUrl(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidateServerUrl", 1);
					return __bnm__method__($value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T IsValid() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsValid", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T GetEventAggregationIntervalTimerInMs() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetEventAggregationIntervalTimerInMs", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceCredentials */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T ToCredentials() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToCredentials", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
