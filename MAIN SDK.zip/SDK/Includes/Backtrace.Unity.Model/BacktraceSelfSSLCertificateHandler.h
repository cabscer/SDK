#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceSelfSSLCertificateHandler : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceSelfSSLCertificateHandler", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T PUB_KEY() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PUB_KEY");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_PUB_KEY(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("PUB_KEY");
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ValidateCertificate(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* certificateData) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidateCertificate", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](certificateData);
				}
				
			};
		}
	}
}
