#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceCredentials : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceCredentials", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Uri */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T $BacktraceHostUri$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$BacktraceHostUri$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Uri */
				void set_$BacktraceHostUri$(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$BacktraceHostUri$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Uri */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T get_BacktraceHostUri() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BacktraceHostUri", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_BacktraceHostUri(BNM::IL2CPP::Il2CppObject* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BacktraceHostUri", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Uri */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetSubmissionUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSubmissionUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Uri */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetPlCrashReporterSubmissionUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetPlCrashReporterSubmissionUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Uri */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetMinidumpSubmissionUrl() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetMinidumpSubmissionUrl", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Uri */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T GetSymbolsSubmissionUrl(BNM::Structures::Mono::String* token) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetSymbolsSubmissionUrl", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](token);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T IsValid(BNM::IL2CPP::Il2CppObject* uri, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* token) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsValid", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](uri, token);
				}
				
			};
		}
	}
}
