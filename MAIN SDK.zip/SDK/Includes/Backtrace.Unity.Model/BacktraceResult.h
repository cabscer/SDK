#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceResult : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceResult", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceResult */
				template <typename T = Backtrace::Unity::Model::BacktraceResult*> T InnerExceptionResult() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("InnerExceptionResult");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.BacktraceResult */
				void set_InnerExceptionResult(Backtrace::Unity::Model::BacktraceResult* value) {
					static BNM::Field<Backtrace::Unity::Model::BacktraceResult*> __bnm__field__ = StaticClass().GetField("InnerExceptionResult");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T message() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("message");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_message(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("message");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T response() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("response");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_response(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("response");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Types.BacktraceResultStatus */
				template <typename T = int> T Status() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Status");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Types.BacktraceResultStatus */
				void set_Status(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("Status");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T $object() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("object");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_$object(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("object");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T _rxId() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_rxId");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set__rxId(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_rxId");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Message() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Message", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Message(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Message", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Object() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Object", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Object(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Object", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_RxId() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RxId", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_RxId(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_RxId", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceResult */
				template <typename T = Backtrace::Unity::Model::BacktraceResult*> static T OnLimitReached() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnLimitReached", 0);
					return __bnm__method__();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceResult */
				template <typename T = Backtrace::Unity::Model::BacktraceResult*> static T OnNetworkError(BNM::IL2CPP::Il2CppObject* exception) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnNetworkError", 1);
					return __bnm__method__(exception);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AddInnerResult(Backtrace::Unity::Model::BacktraceResult* innerResult) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddInnerResult", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](innerResult);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceResult */
				template <typename T = Backtrace::Unity::Model::BacktraceResult*> static T FromJson(BNM::Structures::Mono::String* json) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromJson", 1);
					return __bnm__method__(json);
				}
				
			};
		}
	}
}
