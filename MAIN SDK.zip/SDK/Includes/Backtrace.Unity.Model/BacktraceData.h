#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceData : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceData", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Guid */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T $Uuid$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Uuid$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Guid */
				void set_$Uuid$(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$Uuid$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T _uuidString() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_uuidString");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set__uuidString(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_uuidString");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T $Timestamp$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Timestamp$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int64 */
				void set_$Timestamp$(int64_t value) {
					static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("$Timestamp$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T Lang() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Lang");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_Lang(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Lang");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T LangVersion() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LangVersion");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_LangVersion(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("LangVersion");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T Agent() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Agent");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_Agent(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Agent");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T AgentVersion() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AgentVersion");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_AgentVersion(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("AgentVersion");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,Backtrace.Unity.Model.JsonData.ThreadInformation> */
				template <typename T = void* /*GENERICTYPE*/> T ThreadInformations() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ThreadInformations");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.String,Backtrace.Unity.Model.JsonData.ThreadInformation> */
				void set_ThreadInformations(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("ThreadInformations");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T MainThread() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MainThread");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_MainThread(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("MainThread");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String[] */
				template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T Classifier() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Classifier");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String[] */
				void set_Classifier(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
					static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("Classifier");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceSourceCode */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SourceCode() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SourceCode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.BacktraceSourceCode */
				void set_SourceCode(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("SourceCode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.ICollection`1<System.String> */
				template <typename T = void* /*GENERICTYPE*/> T Attachments() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Attachments");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.ICollection`1<System.String> */
				void set_Attachments(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("Attachments");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceReport */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T $Report$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Report$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.BacktraceReport */
				void set_$Report$(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$Report$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.JsonData.BacktraceAttributes */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Attributes() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Attributes");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.JsonData.BacktraceAttributes */
				void set_Attributes(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Attributes");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.JsonData.Annotations */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Annotation() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Annotation");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.JsonData.Annotations */
				void set_Annotation(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Annotation");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.JsonData.ThreadData */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T ThreadData() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ThreadData");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.JsonData.ThreadData */
				void set_ThreadData(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("ThreadData");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T Deduplication() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Deduplication");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_Deduplication(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("Deduplication");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Guid */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Uuid() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Uuid", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Uuid(BNM::IL2CPP::Il2CppObject* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Uuid", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_UuidString() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_UuidString", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T get_Timestamp() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Timestamp", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Timestamp(int64_t $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Timestamp", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceReport */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Report() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Report", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Report(BNM::IL2CPP::Il2CppObject* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Report", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T ToJson() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetThreadInformations() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetThreadInformations", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetAttributes(void* /*GENERICTYPE*/ clientAttributes, int gameObjectDepth) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetAttributes", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clientAttributes, gameObjectDepth);
				}
				
			};
		}
	}
}
