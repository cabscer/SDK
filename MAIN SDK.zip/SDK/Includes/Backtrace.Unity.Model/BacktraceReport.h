#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceReport : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceReport", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> static T ErrorTypeAttributeName() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ErrorTypeAttributeName");
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				static void set_ErrorTypeAttributeName(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ErrorTypeAttributeName");
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T $Fingerprint$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Fingerprint$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_$Fingerprint$(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$Fingerprint$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T $Factor$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Factor$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_$Factor$(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$Factor$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Guid */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Uuid() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Uuid");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Guid */
				void set_Uuid(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Uuid");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Int64 */
				template <typename T = int64_t> T Timestamp() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Timestamp");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int64 */
				void set_Timestamp(int64_t value) {
					static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("Timestamp");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T ExceptionTypeReport() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ExceptionTypeReport");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_ExceptionTypeReport(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("ExceptionTypeReport");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T Classifier() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Classifier");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_Classifier(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Classifier");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
				template <typename T = void* /*GENERICTYPE*/> T $Attributes$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Attributes$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
				void set_$Attributes$(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$Attributes$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T $Message$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Message$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_$Message$(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$Message$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Exception */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T $Exception$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Exception$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Exception */
				void set_$Exception$(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$Exception$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.List`1<System.String> */
				template <typename T = void* /*GENERICTYPE*/> T $AttachmentPaths$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$AttachmentPaths$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.List`1<System.String> */
				void set_$AttachmentPaths$(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$AttachmentPaths$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.BacktraceStackFrame> */
				template <typename T = void* /*GENERICTYPE*/> T $DiagnosticStack$() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$DiagnosticStack$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.BacktraceStackFrame> */
				void set_$DiagnosticStack$(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$DiagnosticStack$");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceSourceCode */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T SourceCode() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SourceCode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Backtrace.Unity.Model.BacktraceSourceCode */
				void set_SourceCode(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("SourceCode");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Fingerprint() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Fingerprint", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Fingerprint(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Fingerprint", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Factor() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Factor", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Factor(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Factor", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.String,System.String> */
				template <typename T = void* /*GENERICTYPE*/> T get_Attributes() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Attributes", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Attributes(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Attributes", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T get_Message() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Message", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Message(BNM::Structures::Mono::String* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Message", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Exception */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Exception() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Exception", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_Exception(BNM::IL2CPP::Il2CppObject* $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Exception", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Collections.Generic.List`1<System.String> */
				template <typename T = void* /*GENERICTYPE*/> T get_AttachmentPaths() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_AttachmentPaths", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_AttachmentPaths(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_AttachmentPaths", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Collections.Generic.List`1<Backtrace.Unity.Model.BacktraceStackFrame> */
				template <typename T = void* /*GENERICTYPE*/> T get_DiagnosticStack() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DiagnosticStack", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_DiagnosticStack(void* /*GENERICTYPE*/ $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DiagnosticStack", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetDefaultAttributes() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetDefaultAttributes", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T AssignSourceCodeToReport(BNM::Structures::Mono::String* text) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AssignSourceCodeToReport", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](text);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetClassifierInfo() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetClassifierInfo", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetReportFingerprint(bool generateFingerprint) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetReportFingerprint", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](generateFingerprint);
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceData */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T ToBacktraceData(void* /*GENERICTYPE*/ clientAttributes, int gameObjectDepth) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToBacktraceData", 2);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clientAttributes, gameObjectDepth);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T SetStacktraceInformation() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetStacktraceInformation", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: Backtrace.Unity.Model.BacktraceReport */
				template <typename T = Backtrace::Unity::Model::BacktraceReport*> T CreateInnerReport() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateInnerReport", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
