#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceLogManager : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceLogManager", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.Collections.Generic.Queue`1<System.String> */
				template <typename T = void* /*GENERICTYPE*/> T LogQueue() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LogQueue");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Collections.Generic.Queue`1<System.String> */
				void set_LogQueue(void* /*GENERICTYPE*/ value) {
					static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("LogQueue");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Object */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T lockObject() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("lockObject");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Object */
				void set_lockObject(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("lockObject");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.UInt32 */
				template <typename T = BNM::Types::uint> T _limit() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_limit");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.UInt32 */
				void set__limit(BNM::Types::uint value) {
					static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("_limit");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T get_Size() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Size", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T get_Disabled() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Disabled", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Enqueue(BNM::IL2CPP::Il2CppObject* report) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Enqueue", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Enqueue_1(BNM::Structures::Mono::String* message, BNM::Structures::Mono::String* stackTrace, int type) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Enqueue", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, stackTrace, type);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T Enqueue_2(BNM::IL2CPP::Il2CppObject* unityMessage) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Enqueue", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](unityMessage);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T ToSourceCode() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToSourceCode", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
