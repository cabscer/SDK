#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class IBacktraceHttpClient
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "IBacktraceHttpClient", BNM::Image("Backtrace.Unity.dll"));
				}
				
				
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T get_IgnoreSslValidation() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IgnoreSslValidation", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T set_IgnoreSslValidation(bool $value) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_IgnoreSslValidation", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Post(BNM::Structures::Mono::String* submissionUrl, BNM::IL2CPP::Il2CppObject* jObject, void* /*GENERICTYPE*/ onComplete) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Post", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](submissionUrl, jObject, onComplete);
				}
				/* @brief Orig Type: UnityEngine.Networking.UnityWebRequest */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Post_1(BNM::Structures::Mono::String* submissionUrl, BNM::Structures::Mono::String* json, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Post", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](submissionUrl, json, attachments, attributes);
				}
				/* @brief Orig Type: UnityEngine.Networking.UnityWebRequest */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Post_2(BNM::Structures::Mono::String* submissionUrl, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* minidump, void* /*GENERICTYPE*/ attachments, void* /*GENERICTYPE*/ attributes) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Post", 4);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](submissionUrl, minidump, attachments, attributes);
				}
				
			};
		}
	}
}
