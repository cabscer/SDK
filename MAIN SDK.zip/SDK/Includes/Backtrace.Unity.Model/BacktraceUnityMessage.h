#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			class BacktraceUnityMessage : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Backtrace.Unity.Model", "BacktraceUnityMessage", BNM::Image("Backtrace.Unity.dll"));
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T _formattedMessage() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_formattedMessage");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set__formattedMessage(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_formattedMessage");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T Message() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Message");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_Message(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Message");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T StackTrace() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("StackTrace");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_StackTrace(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("StackTrace");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: UnityEngine.LogType */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T Type() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Type");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: UnityEngine.LogType */
				void set_Type(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Type");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetFormattedMessage(bool backtraceFrame) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetFormattedMessage", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceFrame);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T GetFormattedStackTrace(BNM::Structures::Mono::String* stacktrace) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetFormattedStackTrace", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](stacktrace);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T IsUnhandledException() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsUnhandledException", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T ToString() {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToString", 0);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
				}
				
			};
		}
	}
}
