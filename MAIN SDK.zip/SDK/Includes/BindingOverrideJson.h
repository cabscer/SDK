#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BindingOverrideJson
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BindingOverrideJson", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::Structures::Mono::String* action;
		BNM::Structures::Mono::String* id;
		BNM::Structures::Mono::String* path;
		BNM::Structures::Mono::String* interactions;
		BNM::Structures::Mono::String* processors;
		
		
	};
}
