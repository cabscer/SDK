#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BacktraceDatabaseRawRecord
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BacktraceDatabaseRawRecord", BNM::Image("Backtrace.Unity.dll"));
		}
		
		BNM::Structures::Mono::String* Id;
		BNM::Structures::Mono::String* recordName;
		BNM::Structures::Mono::String* dataPath;
		int64_t size;
		BNM::Structures::Mono::String* hash;
		void* /*GENERICTYPE*/ attachments;
		
		
	};
}
