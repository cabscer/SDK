#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct ButtonInfo
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "ButtonInfo", BNM::Image("Unity.XR.Interaction.Toolkit.dll"));
		}
		
		BNM::Structures::Mono::String* name;
		int type;
		
		
	};
}
