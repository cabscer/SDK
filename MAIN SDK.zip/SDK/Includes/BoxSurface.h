#pragma once
#include <BNMIncludes.hpp>

#undef XMin
#undef YMin
#undef ZMin
#undef XMax
#undef YMax
#undef ZMax
namespace GlobalNamespace {
	enum class BoxSurface : int
	{
		XMin = 0,
		YMin = 1,
		ZMin = 2,
		XMax = 3,
		YMax = 4,
		ZMax = 5
	};
}
