#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class $$c : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "<>c", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.UIElements.UIR.UIRenderDevice/<>c */
		template <typename T = GlobalNamespace::$$c*> static T $$9() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$9");
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.UIR.UIRenderDevice/<>c */
		static void set_$$9(GlobalNamespace::$$c* value) {
			static BNM::Field<GlobalNamespace::$$c*> __bnm__field__ = StaticClass().GetField("$$9");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Func`1<UnityEngine.UIElements.UIR.MeshHandle> */
		template <typename T = void* /*GENERICTYPE*/> static T $$9__53_0() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$9__53_0");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Func`1<UnityEngine.UIElements.UIR.MeshHandle> */
		static void set_$$9__53_0(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$$9__53_0");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action`1<UnityEngine.UIElements.UIR.MeshHandle> */
		template <typename T = void* /*GENERICTYPE*/> static T $$9__53_1() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$9__53_1");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`1<UnityEngine.UIElements.UIR.MeshHandle> */
		static void set_$$9__53_1(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$$9__53_1");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: UnityEngine.UIElements.UIR.MeshHandle */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _ctorb__53_0() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("<.ctor>b__53_0", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T _ctorb__53_1(BNM::IL2CPP::Il2CppObject* mh) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("<.ctor>b__53_1", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](mh);
		}
		
	};
}
