#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct ARCoreUpdate
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "ARCoreUpdate", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		
	};
}
