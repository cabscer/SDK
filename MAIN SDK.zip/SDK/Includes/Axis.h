#pragma once
#include <BNMIncludes.hpp>

#undef Horizontal
#undef Vertical
namespace GlobalNamespace {
	enum class Axis : int
	{
		Horizontal = 0,
		Vertical = 1
	};
}
