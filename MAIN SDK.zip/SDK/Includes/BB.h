#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BB

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BB", BNM::Image("Oculus.VR.dll"));
		}
		
		
		
	};
}
