#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class CachedData : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "CachedData", BNM::Image("mscorlib.dll"));
		}
		
		/* @brief Orig Type: System.TimeZoneInfo */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _localTimeZone() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_localTimeZone");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.TimeZoneInfo */
		void set__localTimeZone(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_localTimeZone");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.TimeZoneInfo */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T CreateLocal() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CreateLocal", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.TimeZoneInfo */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Local() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Local", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.DateTimeKind */
		template <typename T = int> T GetCorrespondingKind(BNM::IL2CPP::Il2CppObject* timeZone) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetCorrespondingKind", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](timeZone);
		}
		
	};
}
