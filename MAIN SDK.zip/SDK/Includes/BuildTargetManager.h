#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BuildTargetManager : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BuildTargetManager", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BuildTargetManager/BuildTowards */
		template <typename T = int> T newBuildTarget() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("newBuildTarget");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BuildTargetManager/BuildTowards */
		void set_newBuildTarget(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("newBuildTarget");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T isBeta() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isBeta");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_isBeta(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("isBeta");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T isQA() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isQA");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_isQA(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("isQA");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T spoofIDs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("spoofIDs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_spoofIDs(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("spoofIDs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T enableAllCosmetics() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("enableAllCosmetics");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_enableAllCosmetics(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("enableAllCosmetics");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: OVRManager */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ovrManager() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ovrManager");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: OVRManager */
		void set_ovrManager(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("ovrManager");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T path() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("path");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_path(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("path");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BuildTargetManager/BuildTowards */
		template <typename T = int> T currentBuildTargetDONOTCHANGE() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("currentBuildTargetDONOTCHANGE");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BuildTargetManager/BuildTowards */
		void set_currentBuildTargetDONOTCHANGE(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("currentBuildTargetDONOTCHANGE");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: GorillaTagger */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T gorillaTagger() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("gorillaTagger");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: GorillaTagger */
		void set_gorillaTagger(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("gorillaTagger");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T betaDisableObjects() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("betaDisableObjects");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject[] */
		void set_betaDisableObjects(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("betaDisableObjects");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T betaEnableObjects() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("betaEnableObjects");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject[] */
		void set_betaEnableObjects(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("betaEnableObjects");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T GetPath() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetPath", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
