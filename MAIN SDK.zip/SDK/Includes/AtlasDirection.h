#pragma once
#include <BNMIncludes.hpp>

#undef horizontal
#undef vertical
namespace GlobalNamespace {
	enum class AtlasDirection : int
	{
		horizontal = 0,
		vertical = 1
	};
}
