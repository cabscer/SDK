#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BindingOverrideListJson
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BindingOverrideListJson", BNM::Image("Unity.InputSystem.dll"));
		}
		
		void* /*GENERICTYPE*/ bindings;
		
		
	};
}
