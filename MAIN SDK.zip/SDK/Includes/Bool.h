#pragma once
#include <BNMIncludes.hpp>

#undef False
#undef True
namespace GlobalNamespace {
	enum class Bool : int
	{
		False = 0,
		True = 1
	};
}
