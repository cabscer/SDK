#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BindingSyntax
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BindingSyntax", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* m_ActionMap;
		BNM::IL2CPP::Il2CppObject* m_Action;
		int m_BindingIndexInMap;
		
		
	};
}
