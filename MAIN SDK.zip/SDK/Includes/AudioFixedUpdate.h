#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AudioFixedUpdate
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AudioFixedUpdate", BNM::Image("UnityEngine.CoreModule.dll"));
		}
		
		
		
	};
}
