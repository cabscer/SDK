#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class ButtonClickStatus : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "ButtonClickStatus", BNM::Image("UnityEngine.UIElementsModule.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.UIElements.VisualElement */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_Target() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_Target");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.UIElements.VisualElement */
		void set_m_Target(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_Target");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_PointerDownPosition() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_PointerDownPosition");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_PointerDownPosition(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_PointerDownPosition");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int64 */
		template <typename T = int64_t> T m_LastPointerDownTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_LastPointerDownTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int64 */
		void set_m_LastPointerDownTime(int64_t value) {
			static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("m_LastPointerDownTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_ClickCount() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ClickCount");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_ClickCount(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_ClickCount");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
