#pragma once
#include <BNMIncludes.hpp>

namespace Assets {
	namespace OVR {
		namespace Scripts {
			class FixRecord : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Assets.OVR.Scripts", "FixRecord", BNM::Image("Oculus.VR.dll"));
				}
				
				/* @brief Orig Type: Assets.OVR.Scripts.FixMethodDelegate */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T fixMethod() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("fixMethod");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: Assets.OVR.Scripts.FixMethodDelegate */
				void set_fixMethod(BNM::IL2CPP::Il2CppObject* value) {
					static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("fixMethod");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: UnityEngine.Object */
				template <typename T = BNM::UnityEngine::Object*> T targetObject() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("targetObject");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: UnityEngine.Object */
				void set_targetObject(BNM::UnityEngine::Object* value) {
					static BNM::Field<BNM::UnityEngine::Object*> __bnm__field__ = StaticClass().GetField("targetObject");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String[] */
				template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T buttonNames() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("buttonNames");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String[] */
				void set_buttonNames(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
					static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("buttonNames");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T editModeRequired() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("editModeRequired");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_editModeRequired(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("editModeRequired");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Boolean */
				template <typename T = bool> T complete() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("complete");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Boolean */
				void set_complete(bool value) {
					static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("complete");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				
			};
		}
	}
}
