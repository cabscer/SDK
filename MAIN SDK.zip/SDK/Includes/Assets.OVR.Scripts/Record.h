#pragma once
#include <BNMIncludes.hpp>

namespace Assets {
	namespace OVR {
		namespace Scripts {
			class Record : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Assets.OVR.Scripts", "Record", BNM::Image("Oculus.VR.dll"));
				}
				
				/* @brief Orig Type: System.Int32 */
				template <typename T = int> T sortOrder() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sortOrder");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Int32 */
				void set_sortOrder(int value) {
					static BNM::Field<int> __bnm__field__ = StaticClass().GetField("sortOrder");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T category() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("category");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_category(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("category");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.String */
				template <typename T = BNM::Structures::Mono::String*> T message() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("message");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.String */
				void set_message(BNM::Structures::Mono::String* value) {
					static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("message");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				
			};
		}
	}
}
