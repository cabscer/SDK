#pragma once
#include <BNMIncludes.hpp>

namespace Assets {
	namespace OVR {
		namespace Scripts {
			class FixMethodDelegate : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Assets.OVR.Scripts", "FixMethodDelegate", BNM::Image("Oculus.VR.dll"));
				}
				
				
				/* @brief Orig Type: System.Void */
				template <typename T = void> T Invoke(BNM::UnityEngine::Object* obj, bool isLastInSet, int selectedIndex) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Invoke", 3);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](obj, isLastInSet, selectedIndex);
				}
				/* @brief Orig Type: System.IAsyncResult */
				template <typename T = BNM::IL2CPP::Il2CppObject*> T BeginInvoke(BNM::UnityEngine::Object* obj, bool isLastInSet, int selectedIndex, BNM::IL2CPP::Il2CppObject* callback, BNM::IL2CPP::Il2CppObject* $object) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BeginInvoke", 5);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](obj, isLastInSet, selectedIndex, callback, $object);
				}
				/* @brief Orig Type: System.Void */
				template <typename T = void> T EndInvoke(BNM::IL2CPP::Il2CppObject* result) {
					static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EndInvoke", 1);
					return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](result);
				}
				
			};
		}
	}
}
