#pragma once
#include <BNMIncludes.hpp>

namespace Assets {
	namespace OVR {
		namespace Scripts {
			class RangedRecord : public BNM::IL2CPP::Il2CppObject
			{
				public:
				static BNM::Class StaticClass() {
					return BNM::Class("Assets.OVR.Scripts", "RangedRecord", BNM::Image("Oculus.VR.dll"));
				}
				
				/* @brief Orig Type: System.Single */
				template <typename T = float> T $value() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("value");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Single */
				void set_$value(float value) {
					static BNM::Field<float> __bnm__field__ = StaticClass().GetField("value");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Single */
				template <typename T = float> T min() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("min");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Single */
				void set_min(float value) {
					static BNM::Field<float> __bnm__field__ = StaticClass().GetField("min");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				/* @brief Orig Type: System.Single */
				template <typename T = float> T max() {
					static BNM::Field<T> __bnm__field__ = StaticClass().GetField("max");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					return __bnm__field__();
				}
				/* @param value Orig Type: System.Single */
				void set_max(float value) {
					static BNM::Field<float> __bnm__field__ = StaticClass().GetField("max");
					__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
					__bnm__field__.Set(value);
				}
				
				
			};
		}
	}
}
