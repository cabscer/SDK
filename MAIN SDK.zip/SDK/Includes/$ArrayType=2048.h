#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct $ArrayType$2048
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "$ArrayType=2048", BNM::Image("Pathfinding.Ionic.Zip.Reduced.dll"));
		}
		
		
		
	};
}
