#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryVolume : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryVolume", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T enableBaking() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("enableBaking");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_enableBaking(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("enableBaking");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Bounds */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T bounds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Bounds */
		void set_bounds(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("bounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T adaptiveRes() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("adaptiveRes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_adaptiveRes(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("adaptiveRes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T voxelsPerUnit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("voxelsPerUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_voxelsPerUnit(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("voxelsPerUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T resolutionX() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("resolutionX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_resolutionX(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("resolutionX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T resolutionY() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("resolutionY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_resolutionY(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("resolutionY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T resolutionZ() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("resolutionZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_resolutionZ(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("resolutionZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryVolume/Encoding */
		template <typename T = int> T encoding() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("encoding");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryVolume/Encoding */
		void set_encoding(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("encoding");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryVolume/ShadowmaskEncoding */
		template <typename T = int> T shadowmaskEncoding() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("shadowmaskEncoding");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryVolume/ShadowmaskEncoding */
		void set_shadowmaskEncoding(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("shadowmaskEncoding");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T denoise() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("denoise");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_denoise(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("denoise");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T isGlobal() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("isGlobal");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_isGlobal(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("isGlobal");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture3D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T bakedTexture0() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bakedTexture0");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture3D */
		void set_bakedTexture0(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("bakedTexture0");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture3D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T bakedTexture1() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bakedTexture1");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture3D */
		void set_bakedTexture1(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("bakedTexture1");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture3D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T bakedTexture2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bakedTexture2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture3D */
		void set_bakedTexture2(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("bakedTexture2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture3D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T bakedTexture3() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bakedTexture3");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture3D */
		void set_bakedTexture3(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("bakedTexture3");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Texture3D */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T bakedMask() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bakedMask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Texture3D */
		void set_bakedMask(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("bakedMask");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T supportRotationAfterBake() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("supportRotationAfterBake");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_supportRotationAfterBake(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("supportRotationAfterBake");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BakeryVolume */
		template <typename T = GlobalNamespace::BakeryVolume*> static T globalVolume() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("globalVolume");
			return __bnm__field__();
		}
		/* @param value Orig Type: BakeryVolume */
		static void set_globalVolume(GlobalNamespace::BakeryVolume* value) {
			static BNM::Field<GlobalNamespace::BakeryVolume*> __bnm__field__ = StaticClass().GetField("globalVolume");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T tform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("tform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_tform(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("tform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T GetMin() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetMin", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T GetInvSize() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetInvSize", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: UnityEngine.Matrix4x4 */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T GetMatrix() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetMatrix", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T SetGlobalParams() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetGlobalParams", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateBounds() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateBounds", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
