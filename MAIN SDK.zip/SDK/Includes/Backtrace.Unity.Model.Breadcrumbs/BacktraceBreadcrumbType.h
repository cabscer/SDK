#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Manual
#undef Log
#undef Navigation
#undef Http
#undef System
#undef User
#undef Configuration
namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				enum class BacktraceBreadcrumbType : int
				{
					None = 0,
					Manual = 1,
					Log = 2,
					Navigation = 4,
					Http = 8,
					System = 16,
					User = 32,
					Configuration = 64
				};
			}
		}
	}
}
