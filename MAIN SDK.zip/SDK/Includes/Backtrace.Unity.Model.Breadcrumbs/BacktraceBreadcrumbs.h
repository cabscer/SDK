#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				class BacktraceBreadcrumbs : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Breadcrumbs", "BacktraceBreadcrumbs", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
					template <typename T = int> T $BreadcrumbsLevel$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$BreadcrumbsLevel$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
					void set_$BreadcrumbsLevel$(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$BreadcrumbsLevel$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
					template <typename T = int> T $UnityLogLevel$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$UnityLogLevel$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
					void set_$UnityLogLevel$(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$UnityLogLevel$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.IBacktraceLogManager */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T LogManager() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LogManager");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.IBacktraceLogManager */
					void set_LogManager(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("LogManager");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbsEventHandler */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T EventHandler() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EventHandler");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbsEventHandler */
					void set_EventHandler(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("EventHandler");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T _enabled() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_enabled");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Boolean */
					void set__enabled(bool value) {
						static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_enabled");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
					template <typename T = int> T get_BreadcrumbsLevel() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BreadcrumbsLevel", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_BreadcrumbsLevel(int $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_BreadcrumbsLevel", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
					template <typename T = int> T get_UnityLogLevel() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_UnityLogLevel", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_UnityLogLevel(int $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_UnityLogLevel", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T UnregisterEvents() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UnregisterEvents", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T ClearBreadcrumbs() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ClearBreadcrumbs", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T EnableBreadcrumbs(int level, int unityLogLevel) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableBreadcrumbs", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](level, unityLogLevel);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T EnableBreadcrumbs_1() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableBreadcrumbs", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T FromBacktrace(BNM::IL2CPP::Il2CppObject* report) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromBacktrace", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T FromMonoBehavior(BNM::Structures::Mono::String* message, int type, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromMonoBehavior", 3);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, type, attributes);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T GetBreadcrumbLogPath() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetBreadcrumbLogPath", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Info(BNM::Structures::Mono::String* message) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Info", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Info_1(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Info", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Warning(BNM::Structures::Mono::String* message) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Warning", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Warning_1(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Warning", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Debug(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Debug", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Debug_1(BNM::Structures::Mono::String* message) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Debug", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Exception(BNM::Structures::Mono::String* message) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exception", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Exception_1(BNM::IL2CPP::Il2CppObject* exception, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exception", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](exception, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Exception_2(BNM::IL2CPP::Il2CppObject* exception) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exception", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](exception);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Exception_3(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exception", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Log(BNM::Structures::Mono::String* message, int type) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Log", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, type);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Log_1(BNM::Structures::Mono::String* message, int logType, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Log", 3);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, logType, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T AddBreadcrumbs(BNM::Structures::Mono::String* message, int level, int type, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddBreadcrumbs", 4);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, level, type, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T ShouldLog(int type) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ShouldLog", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](type);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.UnityEngineLogLevel */
					template <typename T = int> static T ConvertLogTypeToLogLevel(int type) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ConvertLogTypeToLogLevel", 1);
						return __bnm__method__(type);
					}
					/* @brief Orig Type: System.Double */
					template <typename T = double> T BreadcrumbId() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BreadcrumbId", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Update() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> static T CanStoreBreadcrumbs(int logLevel, int backtraceBreadcrumbsLevel) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CanStoreBreadcrumbs", 2);
						return __bnm__method__(logLevel, backtraceBreadcrumbsLevel);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T Archive() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Archive", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
