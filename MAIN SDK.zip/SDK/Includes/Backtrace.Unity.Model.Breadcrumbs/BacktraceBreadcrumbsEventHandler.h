#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				class BacktraceBreadcrumbsEventHandler : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Breadcrumbs", "BacktraceBreadcrumbsEventHandler", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T $HasRegisteredEvents$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$HasRegisteredEvents$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Boolean */
					void set_$HasRegisteredEvents$(bool value) {
						static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$HasRegisteredEvents$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbs */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T _breadcrumbs() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_breadcrumbs");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbs */
					void set__breadcrumbs(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_breadcrumbs");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
					template <typename T = int> T _registeredLevel() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_registeredLevel");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
					void set__registeredLevel(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_registeredLevel");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: UnityEngine.NetworkReachability */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T _networkStatus() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_networkStatus");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: UnityEngine.NetworkReachability */
					void set__networkStatus(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_networkStatus");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Threading.Thread */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T _thread() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_thread");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Threading.Thread */
					void set__thread(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_thread");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T get_HasRegisteredEvents() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_HasRegisteredEvents", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_HasRegisteredEvents(bool $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_HasRegisteredEvents", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Register(int level) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](level);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Unregister() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T SceneManager_sceneUnloaded(BNM::IL2CPP::Il2CppObject* scene) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SceneManager_sceneUnloaded", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](scene);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T SceneManager_sceneLoaded(BNM::IL2CPP::Il2CppObject* scene, int loadSceneMode) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SceneManager_sceneLoaded", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](scene, loadSceneMode);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T HandleSceneChanged(BNM::IL2CPP::Il2CppObject* sceneFrom, BNM::IL2CPP::Il2CppObject* sceneTo) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleSceneChanged", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](sceneFrom, sceneTo);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T HandleLowMemory() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleLowMemory", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T HandleApplicationQuitting() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleApplicationQuitting", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T HandleBackgroundMessage(BNM::Structures::Mono::String* condition, BNM::Structures::Mono::String* stackTrace, int type) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleBackgroundMessage", 3);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](condition, stackTrace, type);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T HandleMessage(BNM::Structures::Mono::String* condition, BNM::Structures::Mono::String* stackTrace, int type) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleMessage", 3);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](condition, stackTrace, type);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Application_focusChanged(bool hasFocus) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Application_focusChanged", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](hasFocus);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Log(BNM::Structures::Mono::String* message, int level, int breadcrumbLevel, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Log", 4);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, level, breadcrumbLevel, attributes);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T LogNewNetworkStatus(int status) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("LogNewNetworkStatus", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](status);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Update() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
