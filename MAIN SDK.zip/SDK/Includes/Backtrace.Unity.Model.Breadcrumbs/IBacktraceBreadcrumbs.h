#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				class IBacktraceBreadcrumbs
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Breadcrumbs", "IBacktraceBreadcrumbs", BNM::Image("Backtrace.Unity.dll"));
					}
					
					
					/* @brief Orig Type: Backtrace.Unity.Model.Breadcrumbs.BacktraceBreadcrumbType */
					template <typename T = int> T get_BreadcrumbsLevel() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BreadcrumbsLevel", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T EnableBreadcrumbs() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableBreadcrumbs", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T EnableBreadcrumbs_1(int level, int unityLogLevel) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableBreadcrumbs", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](level, unityLogLevel);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T ClearBreadcrumbs() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ClearBreadcrumbs", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Log(BNM::Structures::Mono::String* message, int type, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Log", 3);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, type, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Log_1(BNM::Structures::Mono::String* message, int type) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Log", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, type);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Debug(BNM::Structures::Mono::String* message) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Debug", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Debug_1(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Debug", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Info(BNM::Structures::Mono::String* message) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Info", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Info_1(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Info", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Warning(BNM::Structures::Mono::String* message) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Warning", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Warning_1(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Warning", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Exception(BNM::IL2CPP::Il2CppObject* exception) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exception", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](exception);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Exception_1(BNM::IL2CPP::Il2CppObject* exception, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exception", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](exception, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Exception_2(BNM::Structures::Mono::String* message) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exception", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Exception_3(BNM::Structures::Mono::String* message, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Exception", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T FromBacktrace(BNM::IL2CPP::Il2CppObject* report) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromBacktrace", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](report);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T FromMonoBehavior(BNM::Structures::Mono::String* message, int type, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromMonoBehavior", 3);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, type, attributes);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T GetBreadcrumbLogPath() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetBreadcrumbLogPath", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Double */
					template <typename T = double> T BreadcrumbId() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BreadcrumbId", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T UnregisterEvents() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UnregisterEvents", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Update() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T Archive() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Archive", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
