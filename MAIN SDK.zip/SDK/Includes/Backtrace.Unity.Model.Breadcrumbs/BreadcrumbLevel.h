#pragma once
#include <BNMIncludes.hpp>

#undef Manual
#undef Log
#undef Navigation
#undef Http
#undef System
#undef User
#undef Configuration
namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				enum class BreadcrumbLevel : int
				{
					Manual = 1,
					Log = 2,
					Navigation = 4,
					Http = 8,
					System = 16,
					User = 32,
					Configuration = 64
				};
			}
		}
	}
}
