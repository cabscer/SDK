#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef Debug
#undef Warning
#undef Info
#undef Fatal
#undef Error
namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				enum class UnityEngineLogLevel : int
				{
					None = 0,
					Debug = 1,
					Warning = 2,
					Info = 4,
					Fatal = 8,
					Error = 16
				};
			}
		}
	}
}
