#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				class IBacktraceLogManager
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Breadcrumbs", "IBacktraceLogManager", BNM::Image("Backtrace.Unity.dll"));
					}
					
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_BreadcrumbsFilePath() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BreadcrumbsFilePath", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Add(BNM::Structures::Mono::String* message, int level, int type, void* /*GENERICTYPE*/ attributes) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 4);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](message, level, type, attributes);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Clear() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Enable() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Enable", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T Length() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Length", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Double */
					template <typename T = double> T BreadcrumbId() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BreadcrumbId", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
