#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Breadcrumbs {
				class IArchiveableBreadcrumbManager
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Breadcrumbs", "IArchiveableBreadcrumbManager", BNM::Image("Backtrace.Unity.dll"));
					}
					
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T Archive() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Archive", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
