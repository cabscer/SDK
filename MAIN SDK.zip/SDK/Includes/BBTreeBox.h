#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BBTreeBox
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BBTreeBox", BNM::Image("AstarPathfindingProject.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* rect;
		int nodeOffset;
		int left;
		int right;
		
		
	};
}
