#pragma once
#include <BNMIncludes.hpp>

#undef Charging
#undef Discharging
#undef Full
#undef NotCharging
#undef Unknown
namespace GlobalNamespace {
	enum class BatteryStatus : int
	{
		Charging = 0,
		Discharging = 1,
		Full = 2,
		NotCharging = 3,
		Unknown = 4
	};
}
