#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BetterBakerPositionOverrides : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BetterBakerPositionOverrides", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Collections.Generic.List`1<BetterBakerPositionOverrides/OverridePosition> */
		template <typename T = void* /*GENERICTYPE*/> T overridePositions() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("overridePositions");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<BetterBakerPositionOverrides/OverridePosition> */
		void set_overridePositions(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("overridePositions");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		
	};
}
