#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CameraIntrinsics
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CameraIntrinsics", BNM::Image("Oculus.VR.dll"));
		}
		
		int IsValid;
		double LastChangedTimeSeconds;
		BNM::IL2CPP::Il2CppObject* FOVPort;
		float VirtualNearPlaneDistanceMeters;
		float VirtualFarPlaneDistanceMeters;
		BNM::IL2CPP::Il2CppObject* ImageSensorPixelResolution;
		
		
	};
}
