#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class $ActionWrapper$d__16$4 : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "<ActionWrapper>d__16`4", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T $$1__state() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$1__state");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_$$1__state(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$$1__state");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $$2__current() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$2__current");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Object */
		void set_$$2__current(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$$2__current");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action`4<T1,T2,T3,T4> */
		template <typename T = void* /*GENERICTYPE*/> T action() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("action");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`4<T1,T2,T3,T4> */
		void set_action(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("action");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: T1 */
		template <typename T = void*> T param1() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("param1");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: T1 */
		void set_param1(void* value) {
			static BNM::Field<void*> __bnm__field__ = StaticClass().GetField("param1");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: T2 */
		template <typename T = void*> T param2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("param2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: T2 */
		void set_param2(void* value) {
			static BNM::Field<void*> __bnm__field__ = StaticClass().GetField("param2");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: T3 */
		template <typename T = void*> T param3() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("param3");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: T3 */
		void set_param3(void* value) {
			static BNM::Field<void*> __bnm__field__ = StaticClass().GetField("param3");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: T4 */
		template <typename T = void*> T param4() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("param4");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: T4 */
		void set_param4(void* value) {
			static BNM::Field<void*> __bnm__field__ = StaticClass().GetField("param4");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_IDisposable_Dispose() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.IDisposable.Dispose", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T MoveNext() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MoveNext", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T System_Collections_Generic_IEnumeratorSystem_Object_get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.Generic.IEnumerator<System.Object>.get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_Collections_IEnumerator_Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.IEnumerator.Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T System_Collections_IEnumerator_get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.IEnumerator.get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
