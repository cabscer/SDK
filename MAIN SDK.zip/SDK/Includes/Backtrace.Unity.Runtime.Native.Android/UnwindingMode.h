#pragma once
#include <BNMIncludes.hpp>

#undef LOCAL
#undef REMOTE
#undef REMOTE_DUMPWITHOUTCRASH
#undef LOCAL_DUMPWITHOUTCRASH
#undef LOCAL_CONTEXT
namespace Backtrace {
	namespace Unity {
		namespace Runtime {
			namespace Native {
				namespace Android {
					enum class UnwindingMode : int
					{
						LOCAL = 0,
						REMOTE = 1,
						REMOTE_DUMPWITHOUTCRASH = 2,
						LOCAL_DUMPWITHOUTCRASH = 3,
						LOCAL_CONTEXT = 4
					};
				}
			}
		}
	}
}
