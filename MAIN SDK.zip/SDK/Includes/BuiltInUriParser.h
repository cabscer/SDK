#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BuiltInUriParser : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BuiltInUriParser", BNM::Image("System.dll"));
		}
		
		
		
	};
}
