#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BitsBuffer
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BitsBuffer", BNM::Image("System.Numerics.dll"));
		}
		
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* _bits;
		int _length;
		
		
	};
}
