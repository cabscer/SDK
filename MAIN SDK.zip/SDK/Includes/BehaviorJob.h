#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BehaviorJob
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BehaviorJob", BNM::Image("Assembly-CSharp.dll"));
		}
		
		void* /*GENERICTYPE*/ Params;
		void* /*GENERICTYPE*/ Output;
		float DeltaTime;
		float FixedDeltaTime;
		
		
	};
}
