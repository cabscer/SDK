#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AnnotationTypes

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AnnotationTypes", BNM::Image("Oculus.VR.dll"));
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T Sample() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Sample");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_Sample(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Sample");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T TimeSpent() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TimeSpent");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_TimeSpent(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("TimeSpent");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T TimeSinceEditorStart() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TimeSinceEditorStart");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_TimeSinceEditorStart(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("TimeSinceEditorStart");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T BuildTarget() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BuildTarget");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_BuildTarget(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("BuildTarget");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T RuntimePlatform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RuntimePlatform");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_RuntimePlatform(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("RuntimePlatform");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T InEditor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("InEditor");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_InEditor(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("InEditor");
			__bnm__field__.Set(value);
		}
		
		
	};
}
