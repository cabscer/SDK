#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class CanvasSettings : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "CanvasSettings", BNM::Image("Unity.XR.Interaction.Toolkit.dll"));
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T $present$() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$present$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_$present$(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("$present$");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AdditionalCanvasShaderChannels */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_AdditionalShaderChannels() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_AdditionalShaderChannels");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AdditionalCanvasShaderChannels */
		void set_m_AdditionalShaderChannels(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_AdditionalShaderChannels");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_NormalizedSortingGridSize() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_NormalizedSortingGridSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_NormalizedSortingGridSize(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_NormalizedSortingGridSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_OverridePixelPerfect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_OverridePixelPerfect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_OverridePixelPerfect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_OverridePixelPerfect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_OverrideSorting() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_OverrideSorting");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_OverrideSorting(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_OverrideSorting");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_PlaneDistance() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_PlaneDistance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_PlaneDistance(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_PlaneDistance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_ReferencePixelsPerUnit() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ReferencePixelsPerUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_ReferencePixelsPerUnit(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_ReferencePixelsPerUnit");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.RenderMode */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_RenderMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_RenderMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.RenderMode */
		void set_m_RenderMode(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_RenderMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_ScaleFactor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_ScaleFactor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_ScaleFactor(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_ScaleFactor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_SortingLayerID() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_SortingLayerID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_SortingLayerID(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_SortingLayerID");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T m_SortingLayerName() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_SortingLayerName");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		void set_m_SortingLayerName(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("m_SortingLayerName");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_SortingOrder() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_SortingOrder");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_SortingOrder(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_SortingOrder");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_TargetDisplay() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_TargetDisplay");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_TargetDisplay(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_TargetDisplay");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_present() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_present", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_present(bool $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_present", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T CopyFrom(BNM::IL2CPP::Il2CppObject* source) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CopyFrom", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](source);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T CopyTo(BNM::IL2CPP::Il2CppObject* dest) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CopyTo", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dest);
		}
		
	};
}
