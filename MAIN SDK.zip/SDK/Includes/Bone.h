#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Bone
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Bone", BNM::Image("Oculus.VR.dll"));
		}
		
		int Id;
		short ParentBoneIndex;
		BNM::IL2CPP::Il2CppObject* Pose;
		
		
	};
}
