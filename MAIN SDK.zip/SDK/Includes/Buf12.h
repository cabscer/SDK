#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Buf12
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Buf12", BNM::Image("mscorlib.dll"));
		}
		
		BNM::Types::uint U0;
		BNM::Types::uint U1;
		BNM::Types::uint U2;
		BNM::Types::ulong ulo64LE;
		BNM::Types::ulong uhigh64LE;
		
		
	};
}
