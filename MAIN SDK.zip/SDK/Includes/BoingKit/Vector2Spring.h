#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct Vector2Spring
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "Vector2Spring", BNM::Image("Assembly-CSharp.dll"));
		}
		
		static int Stride;
		BNM::Structures::Unity::Vector2 Value;
		BNM::Structures::Unity::Vector2 Velocity;
		
		
	};
}
