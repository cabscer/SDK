#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct Vector4Spring
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "Vector4Spring", BNM::Image("Assembly-CSharp.dll"));
		}
		
		static int Stride;
		BNM::Structures::Unity::Vector4 Value;
		BNM::Structures::Unity::Vector4 Velocity;
		
		
	};
}
