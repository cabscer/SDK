#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class MathUtil : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "MathUtil", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Pi() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Pi");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_Pi(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Pi");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T TwoPi() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TwoPi");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_TwoPi(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("TwoPi");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T HalfPi() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("HalfPi");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_HalfPi(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("HalfPi");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T QuaterPi() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("QuaterPi");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_QuaterPi(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("QuaterPi");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T SixthPi() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SixthPi");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_SixthPi(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("SixthPi");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Sqrt2() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Sqrt2");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_Sqrt2(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Sqrt2");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Sqrt2Inv() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Sqrt2Inv");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_Sqrt2Inv(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Sqrt2Inv");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Sqrt3() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Sqrt3");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_Sqrt3(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Sqrt3");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Sqrt3Inv() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Sqrt3Inv");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_Sqrt3Inv(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Sqrt3Inv");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Epsilon() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Epsilon");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_Epsilon(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Epsilon");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Rad2Deg() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Rad2Deg");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_Rad2Deg(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Rad2Deg");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Deg2Rad() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Deg2Rad");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_Deg2Rad(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Deg2Rad");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T AsinSafe(float x) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AsinSafe", 1);
			return __bnm__method__(x);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T AcosSafe(float x) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AcosSafe", 1);
			return __bnm__method__(x);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T InvSafe(float x) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("InvSafe", 1);
			return __bnm__method__(x);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T PointLineDist(BNM::Structures::Unity::Vector2 point, BNM::Structures::Unity::Vector2 linePos, BNM::Structures::Unity::Vector2 lineDir) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PointLineDist", 3);
			return __bnm__method__(point, linePos, lineDir);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T PointSegmentDist(BNM::Structures::Unity::Vector2 point, BNM::Structures::Unity::Vector2 segmentPosA, BNM::Structures::Unity::Vector2 segmentPosB) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PointSegmentDist", 3);
			return __bnm__method__(point, segmentPosA, segmentPosB);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Seek(float current, float target, float maxDelta) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Seek", 3);
			return __bnm__method__(current, target, maxDelta);
		}
		/* @brief Orig Type: UnityEngine.Vector2 */
		template <typename T = BNM::Structures::Unity::Vector2> static T Seek_1(BNM::Structures::Unity::Vector2 current, BNM::Structures::Unity::Vector2 target, float maxDelta) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Seek", 3);
			return __bnm__method__(current, target, maxDelta);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Remainder(float a, float b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Remainder", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Remainder_1(int a, int b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Remainder", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Modulo(float a, float b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Modulo", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Modulo_1(int a, int b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Modulo", 2);
			return __bnm__method__(a, b);
		}
		
	};
}
