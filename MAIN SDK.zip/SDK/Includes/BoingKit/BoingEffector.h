#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingEffector : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingEffector", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> T Radius() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Radius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_Radius(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Radius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T FullEffectRadiusRatio() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FullEffectRadiusRatio");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_FullEffectRadiusRatio(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("FullEffectRadiusRatio");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxImpulseSpeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxImpulseSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxImpulseSpeed(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxImpulseSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T ContinuousMotion() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ContinuousMotion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_ContinuousMotion(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("ContinuousMotion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MoveDistance() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MoveDistance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MoveDistance(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MoveDistance");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T LinearImpulse() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LinearImpulse");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_LinearImpulse(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("LinearImpulse");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T RotationAngle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RotationAngle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_RotationAngle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("RotationAngle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T AngularImpulse() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AngularImpulse");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_AngularImpulse(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("AngularImpulse");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DrawAffectedReactorFieldGizmos() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DrawAffectedReactorFieldGizmos");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DrawAffectedReactorFieldGizmos(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DrawAffectedReactorFieldGizmos");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_currPosition() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_currPosition");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_currPosition(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_currPosition");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_prevPosition() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_prevPosition");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_prevPosition(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_prevPosition");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_linearVelocity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_linearVelocity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_linearVelocity(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_linearVelocity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T get_LinearVelocity() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_LinearVelocity", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T get_LinearSpeed() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_LinearSpeed", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDisable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDrawGizmosSelected() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDrawGizmosSelected", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
