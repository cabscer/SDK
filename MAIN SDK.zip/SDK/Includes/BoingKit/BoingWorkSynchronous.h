#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingWorkSynchronous

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingWorkSynchronous", BNM::Image("Assembly-CSharp.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteBehaviors(void* /*GENERICTYPE*/ behaviorMap, int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteBehaviors", 2);
			return __bnm__method__(behaviorMap, updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteReactors(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* aEffectorParams, void* /*GENERICTYPE*/ reactorMap, void* /*GENERICTYPE*/ fieldMap, void* /*GENERICTYPE*/ cpuSamplerMap, int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteReactors", 5);
			return __bnm__method__(aEffectorParams, reactorMap, fieldMap, cpuSamplerMap, updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteBones(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* aEffectorParams, void* /*GENERICTYPE*/ bonesMap, int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteBones", 3);
			return __bnm__method__(aEffectorParams, bonesMap, updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PullBonesResults(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* aEffectorParams, void* /*GENERICTYPE*/ bonesMap, int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PullBonesResults", 3);
			return __bnm__method__(aEffectorParams, bonesMap, updateMode);
		}
		
	};
}
