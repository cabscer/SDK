#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingKit

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingKit", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.Version */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T Version() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Version");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.Version */
		static void set_Version(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Version");
			__bnm__field__.Set(value);
		}
		
		
	};
}
