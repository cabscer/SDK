#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct QuaternionSpring
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "QuaternionSpring", BNM::Image("Assembly-CSharp.dll"));
		}
		
		static int Stride;
		BNM::Structures::Unity::Vector4 ValueVec;
		BNM::Structures::Unity::Vector4 VelocityVec;
		
		
	};
}
