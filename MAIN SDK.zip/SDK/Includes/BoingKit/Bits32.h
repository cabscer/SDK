#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct Bits32
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "Bits32", BNM::Image("Assembly-CSharp.dll"));
		}
		
		int m_bits;
		
		
	};
}
