#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct Vector3Spring
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "Vector3Spring", BNM::Image("Assembly-CSharp.dll"));
		}
		
		static int Stride;
		BNM::Structures::Unity::Vector3 Value;
		float m_padding0;
		BNM::Structures::Unity::Vector3 Velocity;
		float m_padding1;
		
		
	};
}
