#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct BitArray
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BitArray", BNM::Image("Assembly-CSharp.dll"));
		}
		
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* m_aBlock;
		
		
	};
}
