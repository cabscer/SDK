#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingReactorField : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingReactorField", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.BoingReactorField/ShaderPropertyIdSet */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T s_shaderPropertyId() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_shaderPropertyId");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/ShaderPropertyIdSet */
		static void set_s_shaderPropertyId(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("s_shaderPropertyId");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingReactorField/FieldParams */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_fieldParams() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_fieldParams");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/FieldParams */
		void set_m_fieldParams(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_fieldParams");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingReactorField/HardwareModeEnum */
		template <typename T = int> T HardwareMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("HardwareMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/HardwareModeEnum */
		void set_HardwareMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("HardwareMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingReactorField/HardwareModeEnum */
		template <typename T = int> T m_hardwareMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_hardwareMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/HardwareModeEnum */
		void set_m_hardwareMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_hardwareMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingReactorField/CellMoveModeEnum */
		template <typename T = int> T CellMoveMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CellMoveMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/CellMoveModeEnum */
		void set_CellMoveMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("CellMoveMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingReactorField/CellMoveModeEnum */
		template <typename T = int> T m_cellMoveMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_cellMoveMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/CellMoveModeEnum */
		void set_m_cellMoveMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_cellMoveMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T CellSize() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CellSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_CellSize(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("CellSize");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T CellsX() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CellsX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_CellsX(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("CellsX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T CellsY() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CellsY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_CellsY(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("CellsY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T CellsZ() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CellsZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_CellsZ(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("CellsZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_cellsX() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_cellsX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_cellsX(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_cellsX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_cellsY() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_cellsY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_cellsY(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_cellsY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_cellsZ() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_cellsZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_cellsZ(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_cellsZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_iCellBaseX() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_iCellBaseX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_iCellBaseX(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_iCellBaseX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_iCellBaseY() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_iCellBaseY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_iCellBaseY(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_iCellBaseY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_iCellBaseZ() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_iCellBaseZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_iCellBaseZ(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_iCellBaseZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingReactorField/FalloffModeEnum */
		template <typename T = int> T FalloffMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FalloffMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/FalloffModeEnum */
		void set_FalloffMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("FalloffMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T FalloffRatio() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FalloffRatio");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_FalloffRatio(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("FalloffRatio");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingReactorField/FalloffDimensionsEnum */
		template <typename T = int> T FalloffDimensions() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FalloffDimensions");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/FalloffDimensionsEnum */
		void set_FalloffDimensions(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("FalloffDimensions");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingEffector[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T Effectors() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Effectors");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingEffector[] */
		void set_Effectors(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("Effectors");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_numEffectors() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_numEffectors");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_numEffectors(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_numEffectors");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.Aabb */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_bounds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_bounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.Aabb */
		void set_m_bounds(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_bounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TwoDDistanceCheck() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TwoDDistanceCheck");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_TwoDDistanceCheck(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("TwoDDistanceCheck");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TwoDPositionInfluence() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TwoDPositionInfluence");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_TwoDPositionInfluence(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("TwoDPositionInfluence");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TwoDRotationInfluence() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TwoDRotationInfluence");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_TwoDRotationInfluence(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("TwoDRotationInfluence");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnablePositionEffect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnablePositionEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnablePositionEffect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnablePositionEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnableRotationEffect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnableRotationEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnableRotationEffect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnableRotationEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T GlobalReactionUpVector() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("GlobalReactionUpVector");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_GlobalReactionUpVector(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("GlobalReactionUpVector");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingWork/Params */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Params() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Params");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingWork/Params */
		void set_Params(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Params");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.SharedBoingParams */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T SharedParams() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SharedParams");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.SharedBoingParams */
		void set_SharedParams(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("SharedParams");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnablePropagation() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnablePropagation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnablePropagation(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnablePropagation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T PositionPropagation() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PositionPropagation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_PositionPropagation(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("PositionPropagation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T RotationPropagation() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RotationPropagation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_RotationPropagation(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("RotationPropagation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T PropagationDepth() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PropagationDepth");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_PropagationDepth(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("PropagationDepth");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T AnchorPropagationAtBorder() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AnchorPropagationAtBorder");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_AnchorPropagationAtBorder(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("AnchorPropagationAtBorder");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T kPropagationFactor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("kPropagationFactor");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_kPropagationFactor(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("kPropagationFactor");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingWork/Params/InstanceData[,,] */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_aCpuCell() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_aCpuCell");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingWork/Params/InstanceData[,,] */
		void set_m_aCpuCell(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_aCpuCell");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.ComputeShader */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_shader() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_shader");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.ComputeShader */
		void set_m_shader(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_shader");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.ComputeBuffer */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_effectorIndexBuffer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_effectorIndexBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.ComputeBuffer */
		void set_m_effectorIndexBuffer(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_effectorIndexBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.ComputeBuffer */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_reactorParamsBuffer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_reactorParamsBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.ComputeBuffer */
		void set_m_reactorParamsBuffer(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_reactorParamsBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.ComputeBuffer */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_fieldParamsBuffer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_fieldParamsBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.ComputeBuffer */
		void set_m_fieldParamsBuffer(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_fieldParamsBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.ComputeBuffer */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_cellsBuffer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_cellsBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.ComputeBuffer */
		void set_m_cellsBuffer(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_cellsBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_gpuResourceSetId() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_gpuResourceSetId");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_gpuResourceSetId(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_gpuResourceSetId");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingReactorField/ComputeKernelId */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T s_computeKernelId() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_computeKernelId");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField/ComputeKernelId */
		static void set_s_computeKernelId(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("s_computeKernelId");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_init() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_init");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_init(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_init");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_gridCenter() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_gridCenter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_gridCenter(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_gridCenter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_qPrevGridCenterNorm() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_qPrevGridCenterNorm");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_qPrevGridCenterNorm(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_qPrevGridCenterNorm");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T s_aCellOffset() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aCellOffset");
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3[] */
		static void set_s_aCellOffset(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("s_aCellOffset");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_cellBufferNeedsReset() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_cellBufferNeedsReset");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_cellBufferNeedsReset(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_cellBufferNeedsReset");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T s_aSqrtInv() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aSqrtInv");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single[] */
		static void set_s_aSqrtInv(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("s_aSqrtInv");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingWork/Params[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T s_aReactorParams() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aReactorParams");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingWork/Params[] */
		void set_s_aReactorParams(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("s_aReactorParams");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: BoingKit.BoingReactorField/ShaderPropertyIdSet */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T get_ShaderPropertyId() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ShaderPropertyId", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T get_GpuResourceSetId() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_GpuResourceSetId", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T UpdateShaderConstants(BNM::IL2CPP::Il2CppObject* props, float positionSampleMultiplier, float rotationSampleMultiplier) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateShaderConstants", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](props, positionSampleMultiplier, rotationSampleMultiplier);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T UpdateShaderConstants_1(BNM::IL2CPP::Il2CppObject* material, float positionSampleMultiplier, float rotationSampleMultiplier) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateShaderConstants", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](material, positionSampleMultiplier, rotationSampleMultiplier);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reboot() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reboot", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDisable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T DisposeCpuResources() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DisposeCpuResources", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T DisposeGpuResources() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DisposeGpuResources", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T SampleCpuGrid(BNM::Structures::Unity::Vector3 p, BNM::IL2CPP::Il2CppObject** positionOffset, BNM::IL2CPP::Il2CppObject** rotationOffset) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SampleCpuGrid", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](p, positionOffset, rotationOffset);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateFieldParamsGpu() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateFieldParamsGpu", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateFlags() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateFlags", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateBounds() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateBounds", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PrepareExecute() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PrepareExecute", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ValidateCpuResources() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidateCpuResources", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ValidateGpuResources() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidateGpuResources", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FinishPrepareExecuteCpu() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FinishPrepareExecuteCpu", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FinishPrepareExecuteGpu() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FinishPrepareExecuteGpu", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Init() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Init", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Sanitize() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Sanitize", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T HandleCellMove() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HandleCellMove", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T InitPropagationCpu(BNM::IL2CPP::Il2CppObject* data) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("InitPropagationCpu", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PropagateSpringCpu(BNM::IL2CPP::Il2CppObject* data, float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PropagateSpringCpu", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data, dt);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ExtendPropagationBorder(BNM::IL2CPP::Il2CppObject* data, float weight, int adjDeltaX, int adjDeltaY, int adjDeltaZ) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExtendPropagationBorder", 5);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data, weight, adjDeltaX, adjDeltaY, adjDeltaZ);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AccumulatePropagationWeightedNeighbor(BNM::IL2CPP::Il2CppObject* data, BNM::IL2CPP::Il2CppObject* neighbor, float weight) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AccumulatePropagationWeightedNeighbor", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data, neighbor, weight);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T GatherPropagation(BNM::IL2CPP::Il2CppObject* data, float weightSum) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GatherPropagation", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data, weightSum);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AnchorPropagationBorder(BNM::IL2CPP::Il2CppObject* data) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AnchorPropagationBorder", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PropagateCpu(float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PropagateCpu", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dt);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T WrapCpu(int deltaX, int deltaY, int deltaZ) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WrapCpu", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](deltaX, deltaY, deltaZ);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T WrapGpu(int deltaX, int deltaY, int deltaZ) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("WrapGpu", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](deltaX, deltaY, deltaZ);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ExecuteCpu(float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteCpu", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dt);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ExecuteGpu(float dt, BNM::IL2CPP::Il2CppObject* effectorParamsBuffer, void* /*GENERICTYPE*/ effectorParamsIndexMap) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteGpu", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dt, effectorParamsBuffer, effectorParamsIndexMap);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDrawGizmosSelected() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDrawGizmosSelected", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T DrawGizmos(bool drawEffectors) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DrawGizmos", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](drawEffectors);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T GetGridCenter() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetGridCenter", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T QuantizeNorm(BNM::Structures::Unity::Vector3 p) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("QuantizeNorm", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](p);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T GetCellCenterOffset(int x, int y, int z) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetCellCenterOffset", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](x, y, z);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T ResolveCellIndex(int x, int y, int z, int baseMult, BNM::IL2CPP::Il2CppObject** resX, BNM::IL2CPP::Il2CppObject** resY, BNM::IL2CPP::Il2CppObject** resZ) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ResolveCellIndex", 7);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](x, y, z, baseMult, resX, resY, resZ);
		}
		
	};
}
