#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct Aabb
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "Aabb", BNM::Image("Assembly-CSharp.dll"));
		}
		
		BNM::Structures::Unity::Vector3 Min;
		BNM::Structures::Unity::Vector3 Max;
		
		
	};
}
