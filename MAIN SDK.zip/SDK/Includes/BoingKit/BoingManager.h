#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingManager

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingManager", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.BoingManager/BehaviorRegisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnBehaviorRegister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnBehaviorRegister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/BehaviorRegisterDelegate */
		static void set_OnBehaviorRegister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnBehaviorRegister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/BehaviorUnregisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnBehaviorUnregister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnBehaviorUnregister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/BehaviorUnregisterDelegate */
		static void set_OnBehaviorUnregister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnBehaviorUnregister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/EffectorRegisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnEffectorRegister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnEffectorRegister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/EffectorRegisterDelegate */
		static void set_OnEffectorRegister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnEffectorRegister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/EffectorUnregisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnEffectorUnregister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnEffectorUnregister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/EffectorUnregisterDelegate */
		static void set_OnEffectorUnregister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnEffectorUnregister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/ReactorRegisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnReactorRegister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnReactorRegister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/ReactorRegisterDelegate */
		static void set_OnReactorRegister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnReactorRegister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/ReactorUnregisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnReactorUnregister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnReactorUnregister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/ReactorUnregisterDelegate */
		static void set_OnReactorUnregister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnReactorUnregister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/ReactorFieldRegisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnReactorFieldRegister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnReactorFieldRegister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/ReactorFieldRegisterDelegate */
		static void set_OnReactorFieldRegister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnReactorFieldRegister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/ReactorFieldUnregisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnReactorFieldUnregister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnReactorFieldUnregister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/ReactorFieldUnregisterDelegate */
		static void set_OnReactorFieldUnregister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnReactorFieldUnregister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/ReactorFieldCPUSamplerRegisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnReactorFieldCPUSamplerRegister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnReactorFieldCPUSamplerRegister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/ReactorFieldCPUSamplerRegisterDelegate */
		static void set_OnReactorFieldCPUSamplerRegister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnReactorFieldCPUSamplerRegister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/ReactorFieldCPUSamplerUnregisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnReactorFieldCPUSamplerUnregister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnReactorFieldCPUSamplerUnregister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/ReactorFieldCPUSamplerUnregisterDelegate */
		static void set_OnReactorFieldCPUSamplerUnregister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnReactorFieldCPUSamplerUnregister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/ReactorFieldGPUSamplerRegisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnReactorFieldGPUSamplerRegister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnReactorFieldGPUSamplerRegister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/ReactorFieldGPUSamplerRegisterDelegate */
		static void set_OnReactorFieldGPUSamplerRegister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnReactorFieldGPUSamplerRegister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/ReactorFieldGPUSamplerUnregisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnFieldGPUSamplerUnregister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnFieldGPUSamplerUnregister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/ReactorFieldGPUSamplerUnregisterDelegate */
		static void set_OnFieldGPUSamplerUnregister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnFieldGPUSamplerUnregister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/BonesRegisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnBonesRegister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnBonesRegister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/BonesRegisterDelegate */
		static void set_OnBonesRegister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnBonesRegister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/BonesUnregisterDelegate */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T OnBonesUnregister() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnBonesUnregister");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/BonesUnregisterDelegate */
		static void set_OnBonesUnregister(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnBonesUnregister");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T s_deltaTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_deltaTime");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_s_deltaTime(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("s_deltaTime");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingBehavior> */
		template <typename T = void* /*GENERICTYPE*/> static T s_behaviorMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_behaviorMap");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingBehavior> */
		static void set_s_behaviorMap(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_behaviorMap");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingEffector> */
		template <typename T = void* /*GENERICTYPE*/> static T s_effectorMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_effectorMap");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingEffector> */
		static void set_s_effectorMap(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_effectorMap");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingReactor> */
		template <typename T = void* /*GENERICTYPE*/> static T s_reactorMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_reactorMap");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingReactor> */
		static void set_s_reactorMap(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_reactorMap");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingReactorField> */
		template <typename T = void* /*GENERICTYPE*/> static T s_fieldMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_fieldMap");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingReactorField> */
		static void set_s_fieldMap(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_fieldMap");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingReactorFieldCPUSampler> */
		template <typename T = void* /*GENERICTYPE*/> static T s_cpuSamplerMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_cpuSamplerMap");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingReactorFieldCPUSampler> */
		static void set_s_cpuSamplerMap(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_cpuSamplerMap");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingReactorFieldGPUSampler> */
		template <typename T = void* /*GENERICTYPE*/> static T s_gpuSamplerMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_gpuSamplerMap");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingReactorFieldGPUSampler> */
		static void set_s_gpuSamplerMap(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_gpuSamplerMap");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingBones> */
		template <typename T = void* /*GENERICTYPE*/> static T s_bonesMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_bonesMap");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,BoingKit.BoingBones> */
		static void set_s_bonesMap(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_bonesMap");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T kEffectorParamsIncrement() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("kEffectorParamsIncrement");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_kEffectorParamsIncrement(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("kEffectorParamsIncrement");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<BoingKit.BoingEffector/Params> */
		template <typename T = void* /*GENERICTYPE*/> static T s_effectorParamsList() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_effectorParamsList");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<BoingKit.BoingEffector/Params> */
		static void set_s_effectorParamsList(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_effectorParamsList");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingEffector/Params[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> static T s_aEffectorParams() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aEffectorParams");
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingEffector/Params[] */
		static void set_s_aEffectorParams(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("s_aEffectorParams");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.ComputeBuffer */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T s_effectorParamsBuffer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_effectorParamsBuffer");
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.ComputeBuffer */
		static void set_s_effectorParamsBuffer(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("s_effectorParamsBuffer");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,System.Int32> */
		template <typename T = void* /*GENERICTYPE*/> static T s_effectorParamsIndexMap() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_effectorParamsIndexMap");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Dictionary`2<System.Int32,System.Int32> */
		static void set_s_effectorParamsIndexMap(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_effectorParamsIndexMap");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T UseAsynchronousJobs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UseAsynchronousJobs");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		static void set_UseAsynchronousJobs(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("UseAsynchronousJobs");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T s_managerGo() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_managerGo");
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject */
		static void set_s_managerGo(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("s_managerGo");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<BoingKit.BoingBehavior> */
		template <typename T = void* /*GENERICTYPE*/> static T get_Behaviors() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Behaviors", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<BoingKit.BoingReactor> */
		template <typename T = void* /*GENERICTYPE*/> static T get_Reactors() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Reactors", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<BoingKit.BoingEffector> */
		template <typename T = void* /*GENERICTYPE*/> static T get_Effectors() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Effectors", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<BoingKit.BoingReactorField> */
		template <typename T = void* /*GENERICTYPE*/> static T get_ReactorFields() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ReactorFields", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<BoingKit.BoingReactorFieldCPUSampler> */
		template <typename T = void* /*GENERICTYPE*/> static T get_ReactorFieldCPUSamlers() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ReactorFieldCPUSamlers", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<BoingKit.BoingReactorFieldGPUSampler> */
		template <typename T = void* /*GENERICTYPE*/> static T get_ReactorFieldGPUSampler() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ReactorFieldGPUSampler", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_DeltaTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DeltaTime", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T get_FixedDeltaTime() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_FixedDeltaTime", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T get_NumBehaviors() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NumBehaviors", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T get_NumEffectors() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NumEffectors", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T get_NumReactors() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NumReactors", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T get_NumFields() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NumFields", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T get_NumCPUFieldSamplers() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NumCPUFieldSamplers", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T get_NumGPUFieldSamplers() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_NumGPUFieldSamplers", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: UnityEngine.SphereCollider */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T get_SharedSphereCollider() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_SharedSphereCollider", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ValidateManager() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ValidateManager", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Register(BNM::IL2CPP::Il2CppObject* behavior) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 1);
			return __bnm__method__(behavior);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Unregister(BNM::IL2CPP::Il2CppObject* behavior) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 1);
			return __bnm__method__(behavior);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Register_1(BNM::IL2CPP::Il2CppObject* effector) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 1);
			return __bnm__method__(effector);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Unregister_1(BNM::IL2CPP::Il2CppObject* effector) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 1);
			return __bnm__method__(effector);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Register_2(BNM::IL2CPP::Il2CppObject* reactor) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 1);
			return __bnm__method__(reactor);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Unregister_2(BNM::IL2CPP::Il2CppObject* reactor) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 1);
			return __bnm__method__(reactor);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Register_3(BNM::IL2CPP::Il2CppObject* field) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 1);
			return __bnm__method__(field);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Unregister_3(BNM::IL2CPP::Il2CppObject* field) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 1);
			return __bnm__method__(field);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Register_4(BNM::IL2CPP::Il2CppObject* sampler) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 1);
			return __bnm__method__(sampler);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Unregister_4(BNM::IL2CPP::Il2CppObject* sampler) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 1);
			return __bnm__method__(sampler);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Register_5(BNM::IL2CPP::Il2CppObject* sampler) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 1);
			return __bnm__method__(sampler);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Unregister_5(BNM::IL2CPP::Il2CppObject* sampler) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 1);
			return __bnm__method__(sampler);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Register_6(BNM::IL2CPP::Il2CppObject* bones) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 1);
			return __bnm__method__(bones);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Unregister_6(BNM::IL2CPP::Il2CppObject* bones) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 1);
			return __bnm__method__(bones);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PreRegisterBehavior() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PreRegisterBehavior", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PostUnregisterBehavior() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PostUnregisterBehavior", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PreRegisterEffectorReactor() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PreRegisterEffectorReactor", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PostUnregisterEffectorReactor() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PostUnregisterEffectorReactor", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PreRegisterBones() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PreRegisterBones", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PostUnregisterBones() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PostUnregisterBones", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Execute(int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Execute", 1);
			return __bnm__method__(updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteBehaviors(int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteBehaviors", 1);
			return __bnm__method__(updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PullBehaviorResults(int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PullBehaviorResults", 1);
			return __bnm__method__(updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T RestoreBehaviors() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RestoreBehaviors", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T RefreshEffectorParams() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RefreshEffectorParams", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteReactors(int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteReactors", 1);
			return __bnm__method__(updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PullReactorResults(int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PullReactorResults", 1);
			return __bnm__method__(updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T RestoreReactors() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RestoreReactors", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T DispatchReactorFieldCompute() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DispatchReactorFieldCompute", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteBones(int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteBones", 1);
			return __bnm__method__(updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PullBonesResults(int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PullBonesResults", 1);
			return __bnm__method__(updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T RestoreBones() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RestoreBones", 0);
			return __bnm__method__();
		}
		
	};
}
