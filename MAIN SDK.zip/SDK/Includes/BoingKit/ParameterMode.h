#pragma once
#include <BNMIncludes.hpp>

#undef Exponential
#undef OscillationByHalfLife
#undef OscillationByDampingRatio
namespace BoingKit {
	enum class ParameterMode : int
	{
		Exponential = 0,
		OscillationByHalfLife = 1,
		OscillationByDampingRatio = 2
	};
}
