#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class VectorUtil : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "VectorUtil", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T Min() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Min");
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		static void set_Min(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("Min");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T Max() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Max");
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		static void set_Max(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("Max");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T Rotate2D(BNM::Structures::Unity::Vector3 v, float angle) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Rotate2D", 2);
			return __bnm__method__(v, angle);
		}
		/* @brief Orig Type: UnityEngine.Vector4 */
		template <typename T = BNM::Structures::Unity::Vector4> static T NormalizeSafe(BNM::Structures::Unity::Vector4 v, BNM::Structures::Unity::Vector4 fallback) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("NormalizeSafe", 2);
			return __bnm__method__(v, fallback);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T FindOrthogonal(BNM::Structures::Unity::Vector3 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FindOrthogonal", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T FormOrthogonalBasis(BNM::Structures::Unity::Vector3 v, BNM::IL2CPP::Il2CppObject** a, BNM::IL2CPP::Il2CppObject** b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FormOrthogonalBasis", 3);
			return __bnm__method__(v, a, b);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T Slerp(BNM::Structures::Unity::Vector3 a, BNM::Structures::Unity::Vector3 b, float t) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Slerp", 3);
			return __bnm__method__(a, b, t);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T GetClosestPointOnSegment(BNM::Structures::Unity::Vector3 p, BNM::Structures::Unity::Vector3 segA, BNM::Structures::Unity::Vector3 segB) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetClosestPointOnSegment", 3);
			return __bnm__method__(p, segA, segB);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T TriLerp(BNM::IL2CPP::Il2CppObject* v000, BNM::IL2CPP::Il2CppObject* v001, BNM::IL2CPP::Il2CppObject* v010, BNM::IL2CPP::Il2CppObject* v011, BNM::IL2CPP::Il2CppObject* v100, BNM::IL2CPP::Il2CppObject* v101, BNM::IL2CPP::Il2CppObject* v110, BNM::IL2CPP::Il2CppObject* v111, float tx, float ty, float tz) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TriLerp", 11);
			return __bnm__method__(v000, v001, v010, v011, v100, v101, v110, v111, tx, ty, tz);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T TriLerp_1(BNM::IL2CPP::Il2CppObject* v000, BNM::IL2CPP::Il2CppObject* v001, BNM::IL2CPP::Il2CppObject* v010, BNM::IL2CPP::Il2CppObject* v011, BNM::IL2CPP::Il2CppObject* v100, BNM::IL2CPP::Il2CppObject* v101, BNM::IL2CPP::Il2CppObject* v110, BNM::IL2CPP::Il2CppObject* v111, bool lerpX, bool lerpY, bool lerpZ, float tx, float ty, float tz) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TriLerp", 14);
			return __bnm__method__(v000, v001, v010, v011, v100, v101, v110, v111, lerpX, lerpY, lerpZ, tx, ty, tz);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T TriLerp_2(BNM::IL2CPP::Il2CppObject* min, BNM::IL2CPP::Il2CppObject* max, bool lerpX, bool lerpY, bool lerpZ, float tx, float ty, float tz) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TriLerp", 8);
			return __bnm__method__(min, max, lerpX, lerpY, lerpZ, tx, ty, tz);
		}
		/* @brief Orig Type: UnityEngine.Vector4 */
		template <typename T = BNM::Structures::Unity::Vector4> static T TriLerp_3(BNM::IL2CPP::Il2CppObject* v000, BNM::IL2CPP::Il2CppObject* v001, BNM::IL2CPP::Il2CppObject* v010, BNM::IL2CPP::Il2CppObject* v011, BNM::IL2CPP::Il2CppObject* v100, BNM::IL2CPP::Il2CppObject* v101, BNM::IL2CPP::Il2CppObject* v110, BNM::IL2CPP::Il2CppObject* v111, bool lerpX, bool lerpY, bool lerpZ, float tx, float ty, float tz) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TriLerp", 14);
			return __bnm__method__(v000, v001, v010, v011, v100, v101, v110, v111, lerpX, lerpY, lerpZ, tx, ty, tz);
		}
		/* @brief Orig Type: UnityEngine.Vector4 */
		template <typename T = BNM::Structures::Unity::Vector4> static T TriLerp_4(BNM::IL2CPP::Il2CppObject* min, BNM::IL2CPP::Il2CppObject* max, bool lerpX, bool lerpY, bool lerpZ, float tx, float ty, float tz) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TriLerp", 8);
			return __bnm__method__(min, max, lerpX, lerpY, lerpZ, tx, ty, tz);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T ClampLength(BNM::Structures::Unity::Vector3 v, float minLen, float maxLen) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ClampLength", 3);
			return __bnm__method__(v, minLen, maxLen);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T MinComponent(BNM::Structures::Unity::Vector3 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MinComponent", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T MaxComponent(BNM::Structures::Unity::Vector3 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MaxComponent", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T ComponentWiseAbs(BNM::Structures::Unity::Vector3 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ComponentWiseAbs", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T ComponentWiseMult(BNM::Structures::Unity::Vector3 a, BNM::Structures::Unity::Vector3 b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ComponentWiseMult", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T ComponentWiseDiv(BNM::Structures::Unity::Vector3 num, BNM::Structures::Unity::Vector3 den) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ComponentWiseDiv", 2);
			return __bnm__method__(num, den);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T ComponentWiseDivSafe(BNM::Structures::Unity::Vector3 num, BNM::Structures::Unity::Vector3 den) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ComponentWiseDivSafe", 2);
			return __bnm__method__(num, den);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T ClampBend(BNM::Structures::Unity::Vector3 vector, BNM::Structures::Unity::Vector3 reference, float maxBendAngle) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ClampBend", 3);
			return __bnm__method__(vector, reference, maxBendAngle);
		}
		
	};
}
