#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingBase : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingBase", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.Version */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_currentVersion() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_currentVersion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.Version */
		void set_m_currentVersion(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_currentVersion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.Version */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_previousVersion() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_previousVersion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.Version */
		void set_m_previousVersion(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_previousVersion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.Version */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_initialVersion() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_initialVersion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.Version */
		void set_m_initialVersion(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_initialVersion");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: BoingKit.Version */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_CurrentVersion() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_CurrentVersion", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: BoingKit.Version */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_PreviousVersion() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_PreviousVersion", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: BoingKit.Version */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_InitialVersion() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_InitialVersion", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnUpgrade(BNM::IL2CPP::Il2CppObject* oldVersion, BNM::IL2CPP::Il2CppObject* newVersion) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnUpgrade", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](oldVersion, newVersion);
		}
		
	};
}
