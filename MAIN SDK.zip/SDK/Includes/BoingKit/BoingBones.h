#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingBones : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingBones", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.BoingBones/Bone[][] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T BoneData() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BoneData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBones/Bone[][] */
		void set_BoneData(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("BoneData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingBones/Chain[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T BoneChains() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BoneChains");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBones/Chain[] */
		void set_BoneChains(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("BoneChains");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TwistPropagation() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TwistPropagation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_TwistPropagation(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("TwistPropagation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxCollisionResolutionSpeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxCollisionResolutionSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxCollisionResolutionSpeed(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxCollisionResolutionSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingBoneCollider[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T BoingColliders() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BoingColliders");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBoneCollider[] */
		void set_BoingColliders(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("BoingColliders");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Collider[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T UnityColliders() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UnityColliders");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Collider[] */
		void set_UnityColliders(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("UnityColliders");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DebugDrawRawBones() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DebugDrawRawBones");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DebugDrawRawBones(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DebugDrawRawBones");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DebugDrawTargetBones() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DebugDrawTargetBones");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DebugDrawTargetBones(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DebugDrawTargetBones");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DebugDrawBoingBones() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DebugDrawBoingBones");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DebugDrawBoingBones(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DebugDrawBoingBones");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DebugDrawFinalBones() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DebugDrawFinalBones");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DebugDrawFinalBones(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DebugDrawFinalBones");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DebugDrawColliders() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DebugDrawColliders");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DebugDrawColliders(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DebugDrawColliders");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DebugDrawChainBounds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DebugDrawChainBounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DebugDrawChainBounds(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DebugDrawChainBounds");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DebugDrawBoneNames() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DebugDrawBoneNames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DebugDrawBoneNames(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DebugDrawBoneNames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DebugDrawLengthFromRoot() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("DebugDrawLengthFromRoot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_DebugDrawLengthFromRoot(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("DebugDrawLengthFromRoot");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_minScale() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_minScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_minScale(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_minScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> T get_MinScale() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MinScale", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Register() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Unregister() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnUpgrade(BNM::IL2CPP::Il2CppObject* oldVersion, BNM::IL2CPP::Il2CppObject* newVersion) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnUpgrade", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](oldVersion, newVersion);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnValidate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnValidate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDisable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T RescanBoneChains() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RescanBoneChains", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateCollisionRadius() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateCollisionRadius", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reboot() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reboot", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reboot_1(int iChain) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reboot", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](iChain);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PrepareExecute() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PrepareExecute", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AccumulateTarget(BNM::IL2CPP::Il2CppObject* effector, float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AccumulateTarget", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](effector, dt);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EndAccumulateTargets() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EndAccumulateTargets", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Restore() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Restore", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
