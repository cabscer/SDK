#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingReactor : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingReactor", BNM::Image("Assembly-CSharp.dll"));
		}
		
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Register() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Unregister() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PrepareExecute() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PrepareExecute", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
