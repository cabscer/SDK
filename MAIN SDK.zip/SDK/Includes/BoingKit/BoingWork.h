#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingWork

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingWork", BNM::Image("Assembly-CSharp.dll"));
		}
		
		
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T ComputeTranslationalResults(BNM::IL2CPP::Il2CppObject* t, BNM::Structures::Unity::Vector3 src, BNM::Structures::Unity::Vector3 dst, BNM::IL2CPP::Il2CppObject* b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ComputeTranslationalResults", 4);
			return __bnm__method__(t, src, dst, b);
		}
		
	};
}
