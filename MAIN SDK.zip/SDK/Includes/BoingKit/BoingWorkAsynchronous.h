#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingWorkAsynchronous

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingWorkAsynchronous", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T s_behaviorJobNeedsGather() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_behaviorJobNeedsGather");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		static void set_s_behaviorJobNeedsGather(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("s_behaviorJobNeedsGather");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Unity.Jobs.JobHandle */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T s_hBehaviorJob() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_hBehaviorJob");
			return __bnm__field__();
		}
		/* @param value Orig Type: Unity.Jobs.JobHandle */
		static void set_s_hBehaviorJob(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("s_hBehaviorJob");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingWork/Params> */
		template <typename T = void* /*GENERICTYPE*/> static T s_aBehaviorParams() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aBehaviorParams");
			return __bnm__field__();
		}
		/* @param value Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingWork/Params> */
		static void set_s_aBehaviorParams(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_aBehaviorParams");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingWork/Output> */
		template <typename T = void* /*GENERICTYPE*/> static T s_aBehaviorOutput() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aBehaviorOutput");
			return __bnm__field__();
		}
		/* @param value Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingWork/Output> */
		static void set_s_aBehaviorOutput(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_aBehaviorOutput");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T s_reactorJobNeedsGather() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_reactorJobNeedsGather");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		static void set_s_reactorJobNeedsGather(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("s_reactorJobNeedsGather");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Unity.Jobs.JobHandle */
		template <typename T = BNM::IL2CPP::Il2CppObject*> static T s_hReactorJob() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_hReactorJob");
			return __bnm__field__();
		}
		/* @param value Orig Type: Unity.Jobs.JobHandle */
		static void set_s_hReactorJob(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("s_hReactorJob");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingEffector/Params> */
		template <typename T = void* /*GENERICTYPE*/> static T s_aEffectors() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aEffectors");
			return __bnm__field__();
		}
		/* @param value Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingEffector/Params> */
		static void set_s_aEffectors(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_aEffectors");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingWork/Params> */
		template <typename T = void* /*GENERICTYPE*/> static T s_aReactorExecParams() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aReactorExecParams");
			return __bnm__field__();
		}
		/* @param value Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingWork/Params> */
		static void set_s_aReactorExecParams(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_aReactorExecParams");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingWork/Output> */
		template <typename T = void* /*GENERICTYPE*/> static T s_aReactorExecOutput() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("s_aReactorExecOutput");
			return __bnm__field__();
		}
		/* @param value Orig Type: Unity.Collections.NativeArray`1<BoingKit.BoingWork/Output> */
		static void set_s_aReactorExecOutput(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("s_aReactorExecOutput");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PostUnregisterBehaviorCleanUp() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PostUnregisterBehaviorCleanUp", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PostUnregisterEffectorReactorCleanUp() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PostUnregisterEffectorReactorCleanUp", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteBehaviors(void* /*GENERICTYPE*/ behaviorMap, int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteBehaviors", 2);
			return __bnm__method__(behaviorMap, updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteReactors(void* /*GENERICTYPE*/ effectorMap, void* /*GENERICTYPE*/ reactorMap, void* /*GENERICTYPE*/ fieldMap, void* /*GENERICTYPE*/ cpuSamplerMap, int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteReactors", 5);
			return __bnm__method__(effectorMap, reactorMap, fieldMap, cpuSamplerMap, updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T ExecuteBones(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* aEffectorParams, void* /*GENERICTYPE*/ bonesMap, int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ExecuteBones", 3);
			return __bnm__method__(aEffectorParams, bonesMap, updateMode);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T PullBonesResults(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* aEffectorParams, void* /*GENERICTYPE*/ bonesMap, int updateMode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PullBonesResults", 3);
			return __bnm__method__(aEffectorParams, bonesMap, updateMode);
		}
		
	};
}
