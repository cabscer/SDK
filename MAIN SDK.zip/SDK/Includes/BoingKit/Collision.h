#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class Collision : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "Collision", BNM::Image("Assembly-CSharp.dll"));
		}
		
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T SphereSphere(BNM::Structures::Unity::Vector3 centerA, float radiusA, BNM::Structures::Unity::Vector3 centerB, float radiusB, BNM::IL2CPP::Il2CppObject** push) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SphereSphere", 5);
			return __bnm__method__(centerA, radiusA, centerB, radiusB, push);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T SphereSphereInverse(BNM::Structures::Unity::Vector3 centerA, float radiusA, BNM::Structures::Unity::Vector3 centerB, float radiusB, BNM::IL2CPP::Il2CppObject** push) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SphereSphereInverse", 5);
			return __bnm__method__(centerA, radiusA, centerB, radiusB, push);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T SphereCapsule(BNM::Structures::Unity::Vector3 centerA, float radiusA, BNM::Structures::Unity::Vector3 headB, BNM::Structures::Unity::Vector3 tailB, float radiusB, BNM::IL2CPP::Il2CppObject** push) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SphereCapsule", 6);
			return __bnm__method__(centerA, radiusA, headB, tailB, radiusB, push);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T SphereCapsuleInverse(BNM::Structures::Unity::Vector3 centerA, float radiusA, BNM::Structures::Unity::Vector3 headB, BNM::Structures::Unity::Vector3 tailB, float radiusB, BNM::IL2CPP::Il2CppObject** push) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SphereCapsuleInverse", 6);
			return __bnm__method__(centerA, radiusA, headB, tailB, radiusB, push);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T SphereBox(BNM::Structures::Unity::Vector3 centerOffsetA, float radiusA, BNM::Structures::Unity::Vector3 halfExtentB, BNM::IL2CPP::Il2CppObject** push) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SphereBox", 4);
			return __bnm__method__(centerOffsetA, radiusA, halfExtentB, push);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T SphereBoxInverse(BNM::Structures::Unity::Vector3 centerOffsetA, float radiusA, BNM::Structures::Unity::Vector3 halfExtentB, BNM::IL2CPP::Il2CppObject** push) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SphereBoxInverse", 4);
			return __bnm__method__(centerOffsetA, radiusA, halfExtentB, push);
		}
		
	};
}
