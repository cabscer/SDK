#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct Version
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "Version", BNM::Image("Assembly-CSharp.dll"));
		}
		
		static BoingKit::Version* Invalid;
		static BoingKit::Version* FirstTracked;
		static BoingKit::Version* LastUntracked;
		int $MajorVersion$;
		int $MinorVersion$;
		int $Revision$;
		
		
	};
}
