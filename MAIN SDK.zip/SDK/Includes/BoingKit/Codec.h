#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class Codec : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "Codec", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T FnvDefaultBasis() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FnvDefaultBasis");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_FnvDefaultBasis(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("FnvDefaultBasis");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T FnvPrime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("FnvPrime");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_FnvPrime(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("FnvPrime");
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T PackSaturated(float a, float b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PackSaturated", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T PackSaturated_1(BNM::Structures::Unity::Vector2 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PackSaturated", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: UnityEngine.Vector2 */
		template <typename T = BNM::Structures::Unity::Vector2> static T UnpackSaturated(float f) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UnpackSaturated", 1);
			return __bnm__method__(f);
		}
		/* @brief Orig Type: UnityEngine.Vector2 */
		template <typename T = BNM::Structures::Unity::Vector2> static T OctWrap(BNM::Structures::Unity::Vector2 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OctWrap", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T PackNormal(BNM::Structures::Unity::Vector3 n) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PackNormal", 1);
			return __bnm__method__(n);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T UnpackNormal(float f) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UnpackNormal", 1);
			return __bnm__method__(f);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T PackRgb(BNM::Structures::Unity::Color color) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PackRgb", 1);
			return __bnm__method__(color);
		}
		/* @brief Orig Type: UnityEngine.Color */
		template <typename T = BNM::Structures::Unity::Color> static T UnpackRgb(BNM::Types::uint i) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UnpackRgb", 1);
			return __bnm__method__(i);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T PackRgba(BNM::Structures::Unity::Color color) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PackRgba", 1);
			return __bnm__method__(color);
		}
		/* @brief Orig Type: UnityEngine.Color */
		template <typename T = BNM::Structures::Unity::Color> static T UnpackRgba(BNM::Types::uint i) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UnpackRgba", 1);
			return __bnm__method__(i);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T Pack8888(BNM::Types::uint x, BNM::Types::uint y, BNM::Types::uint z, BNM::Types::uint w) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Pack8888", 4);
			return __bnm__method__(x, y, z, w);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T Unpack8888(BNM::Types::uint i, BNM::IL2CPP::Il2CppObject** x, BNM::IL2CPP::Il2CppObject** y, BNM::IL2CPP::Il2CppObject** z, BNM::IL2CPP::Il2CppObject** w) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unpack8888", 5);
			return __bnm__method__(i, x, y, z, w);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T IntReinterpret(float f) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IntReinterpret", 1);
			return __bnm__method__(f);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat(int hash, int i) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, i);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_1(int hash, int64_t i) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, i);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_2(int hash, float f) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, f);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_3(int hash, bool b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_4(int hash, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* ints) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, ints);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_5(int hash, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* floats) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, floats);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_6(int hash, BNM::Structures::Unity::Vector2 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, v);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_7(int hash, BNM::Structures::Unity::Vector3 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, v);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_8(int hash, BNM::Structures::Unity::Vector4 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, v);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_9(int hash, BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, q);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_10(int hash, BNM::Structures::Unity::Color c) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, c);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashConcat_11(int hash, BNM::IL2CPP::Il2CppObject* t) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashConcat", 2);
			return __bnm__method__(hash, t);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash(int i) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(i);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_1(int64_t i) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(i);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_2(float f) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(f);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_3(bool b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(b);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_4(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* ints) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(ints);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_5(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* floats) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(floats);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_6(BNM::Structures::Unity::Vector2 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_7(BNM::Structures::Unity::Vector3 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_8(BNM::Structures::Unity::Vector4 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_9(BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(q);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T Hash_10(BNM::Structures::Unity::Color c) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Hash", 1);
			return __bnm__method__(c);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashTransformHierarchyRecurvsive(int hash, BNM::IL2CPP::Il2CppObject* t) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashTransformHierarchyRecurvsive", 2);
			return __bnm__method__(hash, t);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T HashTransformHierarchy(BNM::IL2CPP::Il2CppObject* t) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("HashTransformHierarchy", 1);
			return __bnm__method__(t);
		}
		
	};
}
