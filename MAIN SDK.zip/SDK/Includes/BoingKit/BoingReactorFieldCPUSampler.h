#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingReactorFieldCPUSampler : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingReactorFieldCPUSampler", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.BoingReactorField */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ReactorField() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ReactorField");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField */
		void set_ReactorField(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("ReactorField");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/UpdateMode */
		template <typename T = int> T UpdateMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UpdateMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/UpdateMode */
		void set_UpdateMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("UpdateMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T PositionSampleMultiplier() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PositionSampleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_PositionSampleMultiplier(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("PositionSampleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T RotationSampleMultiplier() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RotationSampleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_RotationSampleMultiplier(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("RotationSampleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_objPosition() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_objPosition");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_objPosition(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_objPosition");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> T m_objRotation() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_objRotation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Quaternion */
		void set_m_objRotation(BNM::Structures::Unity::Quaternion value) {
			static BNM::Field<BNM::Structures::Unity::Quaternion> __bnm__field__ = StaticClass().GetField("m_objRotation");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDisable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T SampleFromField() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SampleFromField", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Restore() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Restore", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
