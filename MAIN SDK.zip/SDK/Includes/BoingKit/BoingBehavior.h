#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingBehavior : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingBehavior", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.BoingManager/UpdateMode */
		template <typename T = int> T UpdateMode() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("UpdateMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/UpdateMode */
		void set_UpdateMode(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("UpdateMode");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TwoDDistanceCheck() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TwoDDistanceCheck");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_TwoDDistanceCheck(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("TwoDDistanceCheck");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TwoDPositionInfluence() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TwoDPositionInfluence");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_TwoDPositionInfluence(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("TwoDPositionInfluence");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TwoDRotationInfluence() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TwoDRotationInfluence");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_TwoDRotationInfluence(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("TwoDRotationInfluence");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnablePositionEffect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnablePositionEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnablePositionEffect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnablePositionEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnableRotationEffect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnableRotationEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnableRotationEffect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnableRotationEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T EnableScaleEffect() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("EnableScaleEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_EnableScaleEffect(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("EnableScaleEffect");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T GlobalReactionUpVector() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("GlobalReactionUpVector");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_GlobalReactionUpVector(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("GlobalReactionUpVector");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingManager/TranslationLockSpace */
		template <typename T = int> T TranslationLockSpace() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("TranslationLockSpace");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingManager/TranslationLockSpace */
		void set_TranslationLockSpace(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("TranslationLockSpace");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T LockTranslationX() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LockTranslationX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_LockTranslationX(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("LockTranslationX");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T LockTranslationY() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LockTranslationY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_LockTranslationY(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("LockTranslationY");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T LockTranslationZ() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LockTranslationZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_LockTranslationZ(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("LockTranslationZ");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.BoingWork/Params */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Params() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Params");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingWork/Params */
		void set_Params(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Params");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.SharedBoingParams */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T SharedParams() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("SharedParams");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.SharedBoingParams */
		void set_SharedParams(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("SharedParams");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T PositionSpringDirty() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PositionSpringDirty");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_PositionSpringDirty(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("PositionSpringDirty");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T RotationSpringDirty() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RotationSpringDirty");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_RotationSpringDirty(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("RotationSpringDirty");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T ScaleSpringDirty() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ScaleSpringDirty");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_ScaleSpringDirty(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("ScaleSpringDirty");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T CachedTransformValid() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CachedTransformValid");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_CachedTransformValid(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("CachedTransformValid");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T CachedPositionLs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CachedPositionLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_CachedPositionLs(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("CachedPositionLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T CachedPositionWs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CachedPositionWs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_CachedPositionWs(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("CachedPositionWs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T RenderPositionWs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RenderPositionWs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_RenderPositionWs(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("RenderPositionWs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> T CachedRotationLs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CachedRotationLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Quaternion */
		void set_CachedRotationLs(BNM::Structures::Unity::Quaternion value) {
			static BNM::Field<BNM::Structures::Unity::Quaternion> __bnm__field__ = StaticClass().GetField("CachedRotationLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> T CachedRotationWs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CachedRotationWs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Quaternion */
		void set_CachedRotationWs(BNM::Structures::Unity::Quaternion value) {
			static BNM::Field<BNM::Structures::Unity::Quaternion> __bnm__field__ = StaticClass().GetField("CachedRotationWs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> T RenderRotationWs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RenderRotationWs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Quaternion */
		void set_RenderRotationWs(BNM::Structures::Unity::Quaternion value) {
			static BNM::Field<BNM::Structures::Unity::Quaternion> __bnm__field__ = StaticClass().GetField("RenderRotationWs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T CachedScaleLs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("CachedScaleLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_CachedScaleLs(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("CachedScaleLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T RenderScaleLs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RenderScaleLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_RenderScaleLs(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("RenderScaleLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T InitRebooted() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("InitRebooted");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_InitRebooted(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("InitRebooted");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: BoingKit.Vector3Spring */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_PositionSpring() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_PositionSpring", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_PositionSpring(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_PositionSpring", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: BoingKit.QuaternionSpring */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_RotationSpring() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RotationSpring", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_RotationSpring(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_RotationSpring", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: BoingKit.Vector3Spring */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_ScaleSpring() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScaleSpring", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T set_ScaleSpring(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScaleSpring", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Reboot() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Reboot", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDisable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Register() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Register", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Unregister() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unregister", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateFlags() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateFlags", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PrepareExecute() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PrepareExecute", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PrepareExecute_1(bool accumulateEffectors) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PrepareExecute", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](accumulateEffectors);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Execute(float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Execute", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dt);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PullResults() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PullResults", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T GatherOutput(BNM::IL2CPP::Il2CppObject* o) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GatherOutput", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](o);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T PullResults_1(BNM::IL2CPP::Il2CppObject* p) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PullResults", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](p);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Restore() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Restore", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
