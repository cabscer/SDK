#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class UFOController : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "UFOController", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> T LinearThrust() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LinearThrust");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_LinearThrust(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("LinearThrust");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxLinearSpeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxLinearSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxLinearSpeed(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxLinearSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T LinearDrag() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("LinearDrag");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_LinearDrag(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("LinearDrag");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T Tilt() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Tilt");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_Tilt(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Tilt");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T AngularThrust() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AngularThrust");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_AngularThrust(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("AngularThrust");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MaxAngularSpeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MaxAngularSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MaxAngularSpeed(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MaxAngularSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T AngularDrag() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("AngularDrag");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_AngularDrag(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("AngularDrag");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T Hover() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Hover");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_Hover(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Hover");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Eyes() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Eyes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_Eyes(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Eyes");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T BlinkInterval() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BlinkInterval");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_BlinkInterval(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("BlinkInterval");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_blinkTimer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_blinkTimer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_blinkTimer(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_blinkTimer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T m_lastBlinkWasDouble() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_lastBlinkWasDouble");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set_m_lastBlinkWasDouble(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("m_lastBlinkWasDouble");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_eyeInitScale() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_eyeInitScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_eyeInitScale(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_eyeInitScale");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_eyeInitPositionLs() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_eyeInitPositionLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_eyeInitPositionLs(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_eyeInitPositionLs");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.Vector3Spring */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_eyeScaleSpring() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_eyeScaleSpring");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.Vector3Spring */
		void set_m_eyeScaleSpring(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_eyeScaleSpring");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: BoingKit.Vector3Spring */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_eyePositionLsSpring() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_eyePositionLsSpring");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.Vector3Spring */
		void set_m_eyePositionLsSpring(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_eyePositionLsSpring");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T Motor() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Motor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_Motor(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Motor");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MotorBaseAngularSpeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MotorBaseAngularSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MotorBaseAngularSpeed(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MotorBaseAngularSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T MotorMaxAngularSpeed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("MotorMaxAngularSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_MotorMaxAngularSpeed(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("MotorMaxAngularSpeed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.ParticleSystem */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T BubbleEmitter() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BubbleEmitter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.ParticleSystem */
		void set_BubbleEmitter(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("BubbleEmitter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T BubbleBaseEmissionRate() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BubbleBaseEmissionRate");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_BubbleBaseEmissionRate(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("BubbleBaseEmissionRate");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T BubbleMaxEmissionRate() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BubbleMaxEmissionRate");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_BubbleMaxEmissionRate(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("BubbleMaxEmissionRate");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_linearVelocity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_linearVelocity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_linearVelocity(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_linearVelocity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_angularVelocity() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_angularVelocity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_angularVelocity(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_angularVelocity");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_yawAngle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_yawAngle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_yawAngle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_yawAngle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T m_hoverCenter() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_hoverCenter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_m_hoverCenter(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("m_hoverCenter");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_hoverPhase() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_hoverPhase");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_hoverPhase(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_hoverPhase");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T m_motorAngle() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_motorAngle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_m_motorAngle(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("m_motorAngle");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T FixedUpdate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FixedUpdate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
