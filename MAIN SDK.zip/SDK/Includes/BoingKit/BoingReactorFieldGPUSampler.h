#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingReactorFieldGPUSampler : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingReactorFieldGPUSampler", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.BoingReactorField */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ReactorField() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ReactorField");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingReactorField */
		void set_ReactorField(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("ReactorField");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T PositionSampleMultiplier() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("PositionSampleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_PositionSampleMultiplier(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("PositionSampleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T RotationSampleMultiplier() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("RotationSampleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_RotationSampleMultiplier(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("RotationSampleMultiplier");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.MaterialPropertyBlock */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T m_matProps() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_matProps");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.MaterialPropertyBlock */
		void set_m_matProps(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("m_matProps");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T m_fieldResourceSetId() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("m_fieldResourceSetId");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_m_fieldResourceSetId(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("m_fieldResourceSetId");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnEnable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnEnable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDisable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDisable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
