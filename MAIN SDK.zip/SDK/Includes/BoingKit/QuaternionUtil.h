#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class QuaternionUtil : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "QuaternionUtil", BNM::Image("Assembly-CSharp.dll"));
		}
		
		
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T Magnitude(BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Magnitude", 1);
			return __bnm__method__(q);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T MagnitudeSqr(BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MagnitudeSqr", 1);
			return __bnm__method__(q);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T Normalize(BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Normalize", 1);
			return __bnm__method__(q);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T AxisAngle(BNM::Structures::Unity::Vector3 axis, float angle) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AxisAngle", 2);
			return __bnm__method__(axis, angle);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T GetAxis(BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAxis", 1);
			return __bnm__method__(q);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T GetAngle(BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetAngle", 1);
			return __bnm__method__(q);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T FromAngularVector(BNM::Structures::Unity::Vector3 v) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromAngularVector", 1);
			return __bnm__method__(v);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> static T ToAngularVector(BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToAngularVector", 1);
			return __bnm__method__(q);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T Pow(BNM::Structures::Unity::Quaternion q, float exp) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Pow", 2);
			return __bnm__method__(q, exp);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T Integrate(BNM::Structures::Unity::Quaternion q, BNM::Structures::Unity::Quaternion v, float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Integrate", 3);
			return __bnm__method__(q, v, dt);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T Integrate_1(BNM::Structures::Unity::Quaternion q, BNM::Structures::Unity::Vector3 omega, float dt) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Integrate", 3);
			return __bnm__method__(q, omega, dt);
		}
		/* @brief Orig Type: UnityEngine.Vector4 */
		template <typename T = BNM::Structures::Unity::Vector4> static T ToVector4(BNM::Structures::Unity::Quaternion q) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToVector4", 1);
			return __bnm__method__(q);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T FromVector4(BNM::Structures::Unity::Vector4 v, bool normalize) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FromVector4", 2);
			return __bnm__method__(v, normalize);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> static T DecomposeSwingTwist(BNM::Structures::Unity::Quaternion q, BNM::Structures::Unity::Vector3 twistAxis, BNM::IL2CPP::Il2CppObject** swing, BNM::IL2CPP::Il2CppObject** twist) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DecomposeSwingTwist", 4);
			return __bnm__method__(q, twistAxis, swing, twist);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T Sterp(BNM::Structures::Unity::Quaternion a, BNM::Structures::Unity::Quaternion b, BNM::Structures::Unity::Vector3 twistAxis, float t, int mode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Sterp", 5);
			return __bnm__method__(a, b, twistAxis, t, mode);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T Sterp_1(BNM::Structures::Unity::Quaternion a, BNM::Structures::Unity::Quaternion b, BNM::Structures::Unity::Vector3 twistAxis, float t, BNM::IL2CPP::Il2CppObject** swing, BNM::IL2CPP::Il2CppObject** twist, int mode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Sterp", 7);
			return __bnm__method__(a, b, twistAxis, t, swing, twist, mode);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T Sterp_2(BNM::Structures::Unity::Quaternion a, BNM::Structures::Unity::Quaternion b, BNM::Structures::Unity::Vector3 twistAxis, float tSwing, float tTwist, int mode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Sterp", 6);
			return __bnm__method__(a, b, twistAxis, tSwing, tTwist, mode);
		}
		/* @brief Orig Type: UnityEngine.Quaternion */
		template <typename T = BNM::Structures::Unity::Quaternion> static T Sterp_3(BNM::Structures::Unity::Quaternion a, BNM::Structures::Unity::Quaternion b, BNM::Structures::Unity::Vector3 twistAxis, float tSwing, float tTwist, BNM::IL2CPP::Il2CppObject** swing, BNM::IL2CPP::Il2CppObject** twist, int mode) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Sterp", 8);
			return __bnm__method__(a, b, twistAxis, tSwing, tTwist, swing, twist, mode);
		}
		
	};
}
