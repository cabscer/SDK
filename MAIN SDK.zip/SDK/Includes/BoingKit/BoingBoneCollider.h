#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	class BoingBoneCollider : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "BoingBoneCollider", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: BoingKit.BoingBoneCollider/Type */
		template <typename T = int> T Shape() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Shape");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: BoingKit.BoingBoneCollider/Type */
		void set_Shape(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("Shape");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T Radius() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Radius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_Radius(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Radius");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T Height() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Height");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_Height(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("Height");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Vector3 */
		template <typename T = BNM::Structures::Unity::Vector3> T Dimensions() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Dimensions");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Vector3 */
		void set_Dimensions(BNM::Structures::Unity::Vector3 value) {
			static BNM::Field<BNM::Structures::Unity::Vector3> __bnm__field__ = StaticClass().GetField("Dimensions");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: UnityEngine.Bounds */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Bounds() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Bounds", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T Collide(BNM::Structures::Unity::Vector3 boneCenter, float boneRadius, BNM::IL2CPP::Il2CppObject** push) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Collide", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](boneCenter, boneRadius, push);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnValidate() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnValidate", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T OnDrawGizmos() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OnDrawGizmos", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T DrawGizmos() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DrawGizmos", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
