#pragma once
#include <BNMIncludes.hpp>

#undef XY
#undef XZ
#undef YZ
namespace BoingKit {
	enum class TwoDPlaneEnum : int
	{
		XY = 0,
		XZ = 1,
		YZ = 2
	};
}
