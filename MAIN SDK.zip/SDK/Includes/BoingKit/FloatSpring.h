#pragma once
#include <BNMIncludes.hpp>

namespace BoingKit {
	struct FloatSpring
	{
		static BNM::Class StaticClass() {
			return BNM::Class("BoingKit", "FloatSpring", BNM::Image("Assembly-CSharp.dll"));
		}
		
		static int Stride;
		float Value;
		float Velocity;
		
		
	};
}
