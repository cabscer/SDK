#pragma once
#include <BNMIncludes.hpp>

#undef Default
#undef Legacy
namespace GlobalNamespace {
	enum class AttachPointCompatibilityMode : int
	{
		Default = 0,
		Legacy = 1
	};
}
