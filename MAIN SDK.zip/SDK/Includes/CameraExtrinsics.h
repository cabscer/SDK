#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct CameraExtrinsics
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "CameraExtrinsics", BNM::Image("Oculus.VR.dll"));
		}
		
		int IsValid;
		double LastChangedTimeSeconds;
		int CameraStatusData;
		int AttachedToNode;
		BNM::IL2CPP::Il2CppObject* RelativePose;
		
		
	};
}
