#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BufferedAudioStream : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BufferedAudioStream", BNM::Image("Oculus.Platform.dll"));
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T VerboseLogging() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("VerboseLogging");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		static void set_VerboseLogging(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("VerboseLogging");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.AudioSource */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T audio() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("audio");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AudioSource */
		void set_audio(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("audio");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T audioBuffer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("audioBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single[] */
		void set_audioBuffer(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("audioBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T writePos() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("writePos");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_writePos(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("writePos");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T bufferLengthSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bufferLengthSeconds");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_bufferLengthSeconds(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("bufferLengthSeconds");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T sampleRate() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("sampleRate");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_sampleRate(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("sampleRate");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> static T bufferSize() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("bufferSize");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		static void set_bufferSize(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("bufferSize");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> static T playbackDelayTimeSeconds() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("playbackDelayTimeSeconds");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		static void set_playbackDelayTimeSeconds(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("playbackDelayTimeSeconds");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T playbackDelayRemaining() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("playbackDelayRemaining");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_playbackDelayRemaining(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("playbackDelayRemaining");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single */
		template <typename T = float> T remainingBufferTime() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("remainingBufferTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single */
		void set_remainingBufferTime(float value) {
			static BNM::Field<float> __bnm__field__ = StaticClass().GetField("remainingBufferTime");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Update() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Update", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Stop() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Stop", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AddData(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* samples) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddData", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](samples);
		}
		
	};
}
