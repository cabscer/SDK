#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef MenuButton
#undef Trigger
#undef Grip
#undef TriggerButton
#undef GripButton
#undef PrimaryButton
#undef PrimaryTouch
#undef SecondaryButton
#undef SecondaryTouch
#undef Primary2DAxisTouch
#undef Primary2DAxisClick
#undef Secondary2DAxisTouch
#undef Secondary2DAxisClick
#undef PrimaryAxis2DUp
#undef PrimaryAxis2DDown
#undef PrimaryAxis2DLeft
#undef PrimaryAxis2DRight
#undef SecondaryAxis2DUp
#undef SecondaryAxis2DDown
#undef SecondaryAxis2DLeft
#undef SecondaryAxis2DRight
#undef TriggerPressed
#undef GripPressed
namespace GlobalNamespace {
	enum class Button : int
	{
		None = 0,
		MenuButton = 1,
		Trigger = 2,
		Grip = 3,
		TriggerButton = 4,
		GripButton = 5,
		PrimaryButton = 6,
		PrimaryTouch = 7,
		SecondaryButton = 8,
		SecondaryTouch = 9,
		Primary2DAxisTouch = 10,
		Primary2DAxisClick = 11,
		Secondary2DAxisTouch = 12,
		Secondary2DAxisClick = 13,
		PrimaryAxis2DUp = 14,
		PrimaryAxis2DDown = 15,
		PrimaryAxis2DLeft = 16,
		PrimaryAxis2DRight = 17,
		SecondaryAxis2DUp = 18,
		SecondaryAxis2DDown = 19,
		SecondaryAxis2DLeft = 20,
		SecondaryAxis2DRight = 21,
		TriggerPressed = 4,
		GripPressed = 5
	};
}
