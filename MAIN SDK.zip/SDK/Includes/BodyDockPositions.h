#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BodyDockPositions : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BodyDockPositions", BNM::Image("Assembly-CSharp.dll"));
		}
		
		/* @brief Orig Type: VRRig */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T myRig() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("myRig");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: VRRig */
		void set_myRig(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("myRig");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T leftHandThrowable() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("leftHandThrowable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject */
		void set_leftHandThrowable(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("leftHandThrowable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.GameObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T rightHandThrowable() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rightHandThrowable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.GameObject */
		void set_rightHandThrowable(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("rightHandThrowable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: TransferrableObject[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T allObjects() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("allObjects");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: TransferrableObject[] */
		void set_allObjects(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("allObjects");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<System.Int32> */
		template <typename T = void* /*GENERICTYPE*/> T objectsToEnable() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("objectsToEnable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<System.Int32> */
		void set_objectsToEnable(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("objectsToEnable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<System.Int32> */
		template <typename T = void* /*GENERICTYPE*/> T objectsToDisable() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("objectsToDisable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<System.Int32> */
		void set_objectsToDisable(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("objectsToDisable");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T leftHandTransform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("leftHandTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_leftHandTransform(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("leftHandTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T rightHandTransform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rightHandTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_rightHandTransform(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("rightHandTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T chestTransform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("chestTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_chestTransform(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("chestTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T leftArmTransform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("leftArmTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_leftArmTransform(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("leftArmTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T rightArmTransform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rightArmTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_rightArmTransform(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("rightArmTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T leftBackTransform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("leftBackTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_leftBackTransform(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("leftBackTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: UnityEngine.Transform */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T rightBackTransform() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("rightBackTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.Transform */
		void set_rightBackTransform(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("rightBackTransform");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T IsPositionLeft(int pos) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("IsPositionLeft", 1);
			return __bnm__method__(pos);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T DropZoneStorageUsed(int dropPosition) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DropZoneStorageUsed", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dropPosition);
		}
		/* @brief Orig Type: TransferrableObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ItemPositionInUse(int dropPosition) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ItemPositionInUse", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dropPosition);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T EnableTransferrableItem(int allItemsIndex, int startingPosition, int startingState) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableTransferrableItem", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex, startingPosition, startingState);
		}
		/* @brief Orig Type: BodyDockPositions/DropPositions */
		template <typename T = int> static T OfflineItemActive(int allItemsIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OfflineItemActive", 1);
			return __bnm__method__(allItemsIndex);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T DisableTransferrableItem(int index) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DisableTransferrableItem", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](index);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T AllItemsIndexValid(int allItemsIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AllItemsIndexValid", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T PositionAvailable(int allItemIndex, int startPos) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("PositionAvailable", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemIndex, startPos);
		}
		/* @brief Orig Type: BodyDockPositions/DropPositions */
		template <typename T = int> T FirstAvailablePosition(int allItemIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("FirstAvailablePosition", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemIndex);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T TransferrableItemDisable(int allItemsIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableItemDisable", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T TransferrableItemDisableAtPosition(int dropPositions) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableItemDisableAtPosition", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dropPositions);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T TransferrableItemEnableAtPosition(BNM::Structures::Mono::String* itemName, int dropPosition) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableItemEnableAtPosition", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](itemName, dropPosition);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TransferrableItemActive(BNM::Structures::Mono::String* transferrableItemName) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableItemActive", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](transferrableItemName);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TransferrableItemActiveAtPos(BNM::Structures::Mono::String* transferrableItemName, int dropPosition) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableItemActiveAtPos", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](transferrableItemName, dropPosition);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T TransferrableItemActive_1(int allItemsIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableItemActive", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex);
		}
		/* @brief Orig Type: TransferrableObject */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T TransferrableItem(int allItemsIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableItem", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex);
		}
		/* @brief Orig Type: BodyDockPositions/DropPositions */
		template <typename T = int> T TransferrableItemPosition(int allItemsIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableItemPosition", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T DisableTransferrableItem_1(BNM::Structures::Mono::String* transferrableItemName) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("DisableTransferrableItem", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](transferrableItemName);
		}
		/* @brief Orig Type: BodyDockPositions/DropPositions */
		template <typename T = int> T OppositePosition(int pos) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("OppositePosition", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](pos);
		}
		/* @brief Orig Type: BodyDockPositions/DockingResult */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ToggleWithHandedness(BNM::Structures::Mono::String* transferrableItemName, bool isLeftHand, bool bothHands) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToggleWithHandedness", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](transferrableItemName, isLeftHand, bothHands);
		}
		/* @brief Orig Type: BodyDockPositions/DockingResult */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ToggleTransferrableItem(BNM::Structures::Mono::String* transferrableItemName, int startingPos, bool bothHands) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToggleTransferrableItem", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](transferrableItemName, startingPos, bothHands);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T MoveTransferableItem(int allItemsIndex, int newPosition, int newPositionState) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MoveTransferableItem", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex, newPosition, newPositionState);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T EnableTransferrableGameObject(int allItemsIndex, int dropZone, int startingPosition) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("EnableTransferrableGameObject", 3);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex, dropZone, startingPosition);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T RefreshTransferrableItems() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("RefreshTransferrableItems", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T ReturnTransferrableItemIndex(int allItemsIndex) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReturnTransferrableItemIndex", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](allItemsIndex);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<System.Int32> */
		template <typename T = void* /*GENERICTYPE*/> T TransferrableObjectIndexFromName(BNM::Structures::Mono::String* transObjectName) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("TransferrableObjectIndexFromName", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](transObjectName);
		}
		/* @brief Orig Type: TransferrableObject/PositionState */
		template <typename T = int> T MapDropPositionToState(int pos) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MapDropPositionToState", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](pos);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T UpdateHandState() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("UpdateHandState", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
