#pragma once
#include <BNMIncludes.hpp>

#undef Play
#undef Pause
#undef FastForward
#undef Rewind
#undef SkipForward
#undef SkipBack
#undef Stop
namespace GlobalNamespace {
	enum class ButtonType : int
	{
		Play = 0,
		Pause = 1,
		FastForward = 2,
		Rewind = 3,
		SkipForward = 4,
		SkipBack = 5,
		Stop = 6
	};
}
