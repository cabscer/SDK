#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct Boundsf
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "Boundsf", BNM::Image("Oculus.VR.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* Pos;
		BNM::IL2CPP::Il2CppObject* Size;
		
		
	};
}
