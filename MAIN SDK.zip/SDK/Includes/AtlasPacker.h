#pragma once
#include <BNMIncludes.hpp>

#undef Default
#undef xatlas
#undef Auto
namespace GlobalNamespace {
	enum class AtlasPacker : int
	{
		Default = 0,
		xatlas = 1,
		Auto = 1000
	};
}
