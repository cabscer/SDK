#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class Bmi1

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "Bmi1", BNM::Image("Unity.Burst.dll"));
		}
		
		
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> static T get_IsBmi1Supported() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsBmi1Supported", 0);
			return __bnm__method__();
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T andn_u32(BNM::Types::uint a, BNM::Types::uint b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("andn_u32", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T andn_u64(BNM::Types::ulong a, BNM::Types::ulong b) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("andn_u64", 2);
			return __bnm__method__(a, b);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T bextr_u32(BNM::Types::uint a, BNM::Types::uint start, BNM::Types::uint len) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("bextr_u32", 3);
			return __bnm__method__(a, start, len);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T bextr_u64(BNM::Types::ulong a, BNM::Types::uint start, BNM::Types::uint len) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("bextr_u64", 3);
			return __bnm__method__(a, start, len);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T bextr2_u32(BNM::Types::uint a, BNM::Types::uint control) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("bextr2_u32", 2);
			return __bnm__method__(a, control);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T bextr2_u64(BNM::Types::ulong a, BNM::Types::ulong control) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("bextr2_u64", 2);
			return __bnm__method__(a, control);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T blsi_u32(BNM::Types::uint a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("blsi_u32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T blsi_u64(BNM::Types::ulong a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("blsi_u64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T blsmsk_u32(BNM::Types::uint a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("blsmsk_u32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T blsmsk_u64(BNM::Types::ulong a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("blsmsk_u64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T blsr_u32(BNM::Types::uint a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("blsr_u32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T blsr_u64(BNM::Types::ulong a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("blsr_u64", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.UInt32 */
		template <typename T = BNM::Types::uint> static T tzcnt_u32(BNM::Types::uint a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("tzcnt_u32", 1);
			return __bnm__method__(a);
		}
		/* @brief Orig Type: System.UInt64 */
		template <typename T = BNM::Types::ulong> static T tzcnt_u64(BNM::Types::ulong a) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("tzcnt_u64", 1);
			return __bnm__method__(a);
		}
		
	};
}
