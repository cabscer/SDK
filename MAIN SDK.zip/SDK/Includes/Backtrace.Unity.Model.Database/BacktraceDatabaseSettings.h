#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Database {
				class BacktraceDatabaseSettings : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Database", "BacktraceDatabaseSettings", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: Backtrace.Unity.Model.BacktraceConfiguration */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T _configuration() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_configuration");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.BacktraceConfiguration */
					void set__configuration(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_configuration");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.UInt32 */
					template <typename T = BNM::Types::uint> T _retryInterval() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_retryInterval");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.UInt32 */
					void set__retryInterval(BNM::Types::uint value) {
						static BNM::Field<BNM::Types::uint> __bnm__field__ = StaticClass().GetField("_retryInterval");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T $DatabasePath$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$DatabasePath$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_$DatabasePath$(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$DatabasePath$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_DatabasePath() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DatabasePath", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_DatabasePath(BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DatabasePath", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.UInt32 */
					template <typename T = BNM::Types::uint> T get_MaxRecordCount() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaxRecordCount", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Int64 */
					template <typename T = int64_t> T get_MaxDatabaseSize() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MaxDatabaseSize", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T get_AutoSendMode() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_AutoSendMode", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.UInt32 */
					template <typename T = BNM::Types::uint> T get_RetryInterval() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RetryInterval", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.UInt32 */
					template <typename T = BNM::Types::uint> T get_RetryLimit() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RetryLimit", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: Backtrace.Unity.Types.DeduplicationStrategy */
					template <typename T = int> T get_DeduplicationStrategy() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DeduplicationStrategy", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T get_GenerateScreenshotOnException() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_GenerateScreenshotOnException", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T get_AddUnityLogToReport() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_AddUnityLogToReport", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: Backtrace.Unity.Types.RetryOrder */
					template <typename T = int> T get_RetryOrder() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RetryOrder", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: Backtrace.Unity.Types.MiniDumpType */
					template <typename T = BNM::Types::uint> T get_MinidumpType() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_MinidumpType", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
