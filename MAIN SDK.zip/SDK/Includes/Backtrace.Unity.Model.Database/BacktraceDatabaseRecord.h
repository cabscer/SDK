#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Database {
				class BacktraceDatabaseRecord : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Database", "BacktraceDatabaseRecord", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.Guid */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T Id() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Id");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Guid */
					void set_Id(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("Id");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T Locked() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Locked");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Boolean */
					void set_Locked(bool value) {
						static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("Locked");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T $RecordPath$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$RecordPath$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_$RecordPath$(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$RecordPath$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T $DiagnosticDataPath$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$DiagnosticDataPath$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_$DiagnosticDataPath$(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$DiagnosticDataPath$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Int64 */
					template <typename T = int64_t> T $Size$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Size$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Int64 */
					void set_$Size$(int64_t value) {
						static BNM::Field<int64_t> __bnm__field__ = StaticClass().GetField("$Size$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T Hash() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Hash");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_Hash(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Hash");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.BacktraceData */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T $Record$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Record$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.BacktraceData */
					void set_$Record$(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$Record$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Collections.Generic.ICollection`1<System.String> */
					template <typename T = void* /*GENERICTYPE*/> T $Attachments$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$Attachments$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Collections.Generic.ICollection`1<System.String> */
					void set_$Attachments$(void* /*GENERICTYPE*/ value) {
						static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("$Attachments$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T $DiagnosticDataJson$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$DiagnosticDataJson$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set_$DiagnosticDataJson$(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("$DiagnosticDataJson$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T _count() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_count");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Int32 */
					void set__count(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("_count");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_RecordPath() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_RecordPath", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_RecordPath(BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_RecordPath", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_DiagnosticDataPath() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DiagnosticDataPath", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_DiagnosticDataPath(BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DiagnosticDataPath", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Int64 */
					template <typename T = int64_t> T get_Size() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Size", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Size(int64_t $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Size", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.BacktraceData */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T get_Record() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Record", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Record(BNM::IL2CPP::Il2CppObject* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Record", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Collections.Generic.ICollection`1<System.String> */
					template <typename T = void* /*GENERICTYPE*/> T get_Attachments() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Attachments", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_Attachments(void* /*GENERICTYPE*/ $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_Attachments", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T get_DiagnosticDataJson() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_DiagnosticDataJson", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_DiagnosticDataJson(BNM::Structures::Mono::String* $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_DiagnosticDataJson", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Boolean */
					template <typename T = bool> T get_Duplicated() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Duplicated", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T get_Count() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Count", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T BacktraceDataJson() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("BacktraceDataJson", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: Backtrace.Unity.Model.BacktraceData */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T get_BacktraceData() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_BacktraceData", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T ToJson() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ToJson", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
					template <typename T = Backtrace::Unity::Model::Database::BacktraceDatabaseRecord*> static T Deserialize(BNM::Structures::Mono::String* json) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Deserialize", 1);
						return __bnm__method__(json);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Increment() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Increment", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseRecord */
					template <typename T = Backtrace::Unity::Model::Database::BacktraceDatabaseRecord*> static T ReadFromFile(BNM::IL2CPP::Il2CppObject* file) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ReadFromFile", 1);
						return __bnm__method__(file);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T Unlock() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Unlock", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					
				};
			}
		}
	}
}
