#pragma once
#include <BNMIncludes.hpp>

namespace Backtrace {
	namespace Unity {
		namespace Model {
			namespace Database {
				class BacktraceDatabaseAttachmentManager : public BNM::IL2CPP::Il2CppObject
				{
					public:
					static BNM::Class StaticClass() {
						return BNM::Class("Backtrace.Unity.Model.Database", "BacktraceDatabaseAttachmentManager", BNM::Image("Backtrace.Unity.dll"));
					}
					
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T $ScreenshotMaxHeight$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$ScreenshotMaxHeight$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Int32 */
					void set_$ScreenshotMaxHeight$(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$ScreenshotMaxHeight$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T $ScreenshotQuality$() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$ScreenshotQuality$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Int32 */
					void set_$ScreenshotQuality$(int value) {
						static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$ScreenshotQuality$");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseSettings */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T _settings() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_settings");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: Backtrace.Unity.Model.Database.BacktraceDatabaseSettings */
					void set__settings(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_settings");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Single */
					template <typename T = float> T _lastScreenTime() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_lastScreenTime");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Single */
					void set__lastScreenTime(float value) {
						static BNM::Field<float> __bnm__field__ = StaticClass().GetField("_lastScreenTime");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T _lastScreenPath() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_lastScreenPath");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.String */
					void set__lastScreenPath(BNM::Structures::Mono::String* value) {
						static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("_lastScreenPath");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					/* @brief Orig Type: System.Object */
					template <typename T = BNM::IL2CPP::Il2CppObject*> T _lock() {
						static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_lock");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						return __bnm__field__();
					}
					/* @param value Orig Type: System.Object */
					void set__lock(BNM::IL2CPP::Il2CppObject* value) {
						static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_lock");
						__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
						__bnm__field__.Set(value);
					}
					
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T get_ScreenshotMaxHeight() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotMaxHeight", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_ScreenshotMaxHeight(int $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotMaxHeight", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Int32 */
					template <typename T = int> T get_ScreenshotQuality() {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_ScreenshotQuality", 0);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T set_ScreenshotQuality(int $value) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("set_ScreenshotQuality", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
					}
					/* @brief Orig Type: System.Collections.Generic.IEnumerable`1<System.String> */
					template <typename T = void* /*GENERICTYPE*/> T GetReportAttachments(BNM::IL2CPP::Il2CppObject* data) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetReportAttachments", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](data);
					}
					/* @brief Orig Type: System.Void */
					template <typename T = void> T AddIfPathIsNotEmpty(void* /*GENERICTYPE*/ source, BNM::Structures::Mono::String* attachmentPath) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddIfPathIsNotEmpty", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](source, attachmentPath);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T GetMinidumpPath(BNM::IL2CPP::Il2CppObject* backtraceData, BNM::Structures::Mono::String* dataPrefix) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetMinidumpPath", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceData, dataPrefix);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T GetScreenshotPath(BNM::Structures::Mono::String* dataPrefix) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetScreenshotPath", 1);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](dataPrefix);
					}
					/* @brief Orig Type: System.String */
					template <typename T = BNM::Structures::Mono::String*> T GetUnityPlayerLogFile(BNM::IL2CPP::Il2CppObject* backtraceData, BNM::Structures::Mono::String* dataPrefix) {
						static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetUnityPlayerLogFile", 2);
						return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](backtraceData, dataPrefix);
					}
					
				};
			}
		}
	}
}
