#pragma once
#include <BNMIncludes.hpp>

#undef AllExceptSelector
#undef OnlySelector
namespace GlobalNamespace {
	enum class BlockMode : int
	{
		AllExceptSelector = 0,
		OnlySelector = 1
	};
}
