#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AvailableDevice
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AvailableDevice", BNM::Image("Unity.InputSystem.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* description;
		int deviceId;
		bool isNative;
		bool isRemoved;
		
		
	};
}
