#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AnnotationType

	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AnnotationType", BNM::Image("Oculus.VR.dll"));
		}
		
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T BlockId() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BlockId");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_BlockId(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("BlockId");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T BlockName() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("BlockName");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_BlockName(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("BlockName");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T InstanceId() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("InstanceId");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_InstanceId(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("InstanceId");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T Version() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Version");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_Version(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Version");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T ActionTrigger() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("ActionTrigger");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_ActionTrigger(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("ActionTrigger");
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> static T Error() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("Error");
			return __bnm__field__();
		}
		/* @param value Orig Type: System.String */
		static void set_Error(BNM::Structures::Mono::String* value) {
			static BNM::Field<BNM::Structures::Mono::String*> __bnm__field__ = StaticClass().GetField("Error");
			__bnm__field__.Set(value);
		}
		
		
	};
}
