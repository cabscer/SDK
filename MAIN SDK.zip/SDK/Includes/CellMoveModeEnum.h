#pragma once
#include <BNMIncludes.hpp>

#undef Follow
#undef WrapAround
namespace GlobalNamespace {
	enum class CellMoveModeEnum : int
	{
		Follow = 0,
		WrapAround = 1
	};
}
