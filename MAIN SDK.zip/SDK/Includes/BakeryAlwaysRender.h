#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class BakeryAlwaysRender : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "BakeryAlwaysRender", BNM::Image("BakeryRuntimeAssembly.dll"));
		}
		
		
		
	};
}
