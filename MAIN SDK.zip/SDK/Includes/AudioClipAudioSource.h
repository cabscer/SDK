#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AudioClipAudioSource : public BNM::UnityEngine::MonoBehaviour
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AudioClipAudioSource", BNM::Image("Meta.WitAi.dll"));
		}
		
		/* @brief Orig Type: UnityEngine.AudioSource */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T _audioSource() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_audioSource");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: UnityEngine.AudioSource */
		void set__audioSource(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("_audioSource");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<UnityEngine.AudioClip> */
		template <typename T = void* /*GENERICTYPE*/> T _audioClips() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_audioClips");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<UnityEngine.AudioClip> */
		void set__audioClips(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_audioClips");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T _loopRequests() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_loopRequests");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set__loopRequests(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_loopRequests");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T _isRecording() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_isRecording");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Boolean */
		void set__isRecording(bool value) {
			static BNM::Field<bool> __bnm__field__ = StaticClass().GetField("_isRecording");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.Queue`1<System.Int32> */
		template <typename T = void* /*GENERICTYPE*/> T _audioQueue() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("_audioQueue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.Queue`1<System.Int32> */
		void set__audioQueue(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("_audioQueue");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T clipIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("clipIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_clipIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("clipIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T activeClip() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("activeClip");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single[] */
		void set_activeClip(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("activeClip");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T activeClipIndex() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("activeClipIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_activeClipIndex(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("activeClipIndex");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Single[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T activeClipBuffer() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("activeClipBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Single[] */
		void set_activeClipBuffer(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* value) {
			static BNM::Field<BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> __bnm__field__ = StaticClass().GetField("activeClipBuffer");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<System.Single[]> */
		template <typename T = void* /*GENERICTYPE*/> T clipData() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("clipData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<System.Single[]> */
		void set_clipData(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("clipData");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T OnStartRecording() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnStartRecording");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action */
		void set_OnStartRecording(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnStartRecording");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T OnStartRecordingFailed() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnStartRecordingFailed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action */
		void set_OnStartRecordingFailed(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnStartRecordingFailed");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action`3<System.Int32,System.Single[],System.Single> */
		template <typename T = void* /*GENERICTYPE*/> T OnSampleReady() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnSampleReady");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action`3<System.Int32,System.Single[],System.Single> */
		void set_OnSampleReady(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("OnSampleReady");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Action */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T OnStopRecording() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("OnStopRecording");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Action */
		void set_OnStopRecording(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("OnStopRecording");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Start() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Start", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T SendSample(BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* sample) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SendSample", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](sample);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T add_OnStartRecording(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("add_OnStartRecording", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T remove_OnStartRecording(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("remove_OnStartRecording", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T add_OnStartRecordingFailed(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("add_OnStartRecordingFailed", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T remove_OnStartRecordingFailed(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("remove_OnStartRecordingFailed", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T add_OnSampleReady(void* /*GENERICTYPE*/ $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("add_OnSampleReady", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T remove_OnSampleReady(void* /*GENERICTYPE*/ $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("remove_OnSampleReady", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T add_OnStopRecording(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("add_OnStopRecording", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T remove_OnStopRecording(BNM::IL2CPP::Il2CppObject* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("remove_OnStopRecording", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]($value);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T StartRecording(int sampleLen) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StartRecording", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](sampleLen);
		}
		/* @brief Orig Type: System.Collections.IEnumerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T ProcessClip(BNM::IL2CPP::Il2CppObject* clip, BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* clipData) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("ProcessClip", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clip, clipData);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T StopRecording() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("StopRecording", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsRecording() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsRecording", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: Meta.WitAi.Data.AudioEncoding */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T get_AudioEncoding() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_AudioEncoding", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T get_IsInputAvailable() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_IsInputAvailable", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T CheckForInput() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("CheckForInput", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T SetActiveClip(BNM::Structures::Mono::String* clipName) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("SetActiveClip", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clipName);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AddClip(BNM::IL2CPP::Il2CppObject* clip) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddClip", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clip);
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T AddClipData(BNM::IL2CPP::Il2CppObject* clip) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("AddClipData", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](clip);
		}
		
	};
}
