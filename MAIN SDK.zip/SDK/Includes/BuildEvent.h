#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BuildEvent
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BuildEvent", BNM::Image("Unity.XR.Management.dll"));
		}
		
		BNM::Structures::Mono::String* buildGuid;
		BNM::Structures::Mono::String* buildTarget;
		BNM::Structures::Mono::String* buildTargetGroup;
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* assigned_loaders;
		
		
	};
}
