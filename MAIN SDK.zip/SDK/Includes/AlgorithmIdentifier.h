#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AlgorithmIdentifier
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AlgorithmIdentifier", BNM::Image("System.dll"));
		}
		
		BNM::Structures::Mono::String* AlgorithmId;
		BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>* Parameters;
		
		
	};
}
