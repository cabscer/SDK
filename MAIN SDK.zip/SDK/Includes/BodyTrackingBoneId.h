#pragma once
#include <BNMIncludes.hpp>

#undef Body_Start
#undef Body_Root
#undef Body_Hips
#undef Body_SpineLower
#undef Body_SpineMiddle
#undef Body_SpineUpper
#undef Body_Chest
#undef Body_Neck
#undef Body_Head
#undef Body_LeftShoulder
#undef Body_LeftScapula
#undef Body_LeftArmUpper
#undef Body_LeftArmLower
#undef Body_LeftHandWristTwist
#undef Body_RightShoulder
#undef Body_RightScapula
#undef Body_RightArmUpper
#undef Body_RightArmLower
#undef Body_RightHandWristTwist
#undef Body_LeftHandPalm
#undef Body_LeftHandWrist
#undef Body_LeftHandThumbMetacarpal
#undef Body_LeftHandThumbProximal
#undef Body_LeftHandThumbDistal
#undef Body_LeftHandThumbTip
#undef Body_LeftHandIndexMetacarpal
#undef Body_LeftHandIndexProximal
#undef Body_LeftHandIndexIntermediate
#undef Body_LeftHandIndexDistal
#undef Body_LeftHandIndexTip
#undef Body_LeftHandMiddleMetacarpal
#undef Body_LeftHandMiddleProximal
#undef Body_LeftHandMiddleIntermediate
#undef Body_LeftHandMiddleDistal
#undef Body_LeftHandMiddleTip
#undef Body_LeftHandRingMetacarpal
#undef Body_LeftHandRingProximal
#undef Body_LeftHandRingIntermediate
#undef Body_LeftHandRingDistal
#undef Body_LeftHandRingTip
#undef Body_LeftHandLittleMetacarpal
#undef Body_LeftHandLittleProximal
#undef Body_LeftHandLittleIntermediate
#undef Body_LeftHandLittleDistal
#undef Body_LeftHandLittleTip
#undef Body_RightHandPalm
#undef Body_RightHandWrist
#undef Body_RightHandThumbMetacarpal
#undef Body_RightHandThumbProximal
#undef Body_RightHandThumbDistal
#undef Body_RightHandThumbTip
#undef Body_RightHandIndexMetacarpal
#undef Body_RightHandIndexProximal
#undef Body_RightHandIndexIntermediate
#undef Body_RightHandIndexDistal
#undef Body_RightHandIndexTip
#undef Body_RightHandMiddleMetacarpal
#undef Body_RightHandMiddleProximal
#undef Body_RightHandMiddleIntermediate
#undef Body_RightHandMiddleDistal
#undef Body_RightHandMiddleTip
#undef Body_RightHandRingMetacarpal
#undef Body_RightHandRingProximal
#undef Body_RightHandRingIntermediate
#undef Body_RightHandRingDistal
#undef Body_RightHandRingTip
#undef Body_RightHandLittleMetacarpal
#undef Body_RightHandLittleProximal
#undef Body_RightHandLittleIntermediate
#undef Body_RightHandLittleDistal
#undef Body_RightHandLittleTip
#undef Body_End
#undef NoOverride
#undef Remove
namespace GlobalNamespace {
	enum class BodyTrackingBoneId : int
	{
		Body_Start = 0,
		Body_Root = 0,
		Body_Hips = 1,
		Body_SpineLower = 2,
		Body_SpineMiddle = 3,
		Body_SpineUpper = 4,
		Body_Chest = 5,
		Body_Neck = 6,
		Body_Head = 7,
		Body_LeftShoulder = 8,
		Body_LeftScapula = 9,
		Body_LeftArmUpper = 10,
		Body_LeftArmLower = 11,
		Body_LeftHandWristTwist = 12,
		Body_RightShoulder = 13,
		Body_RightScapula = 14,
		Body_RightArmUpper = 15,
		Body_RightArmLower = 16,
		Body_RightHandWristTwist = 17,
		Body_LeftHandPalm = 18,
		Body_LeftHandWrist = 19,
		Body_LeftHandThumbMetacarpal = 20,
		Body_LeftHandThumbProximal = 21,
		Body_LeftHandThumbDistal = 22,
		Body_LeftHandThumbTip = 23,
		Body_LeftHandIndexMetacarpal = 24,
		Body_LeftHandIndexProximal = 25,
		Body_LeftHandIndexIntermediate = 26,
		Body_LeftHandIndexDistal = 27,
		Body_LeftHandIndexTip = 28,
		Body_LeftHandMiddleMetacarpal = 29,
		Body_LeftHandMiddleProximal = 30,
		Body_LeftHandMiddleIntermediate = 31,
		Body_LeftHandMiddleDistal = 32,
		Body_LeftHandMiddleTip = 33,
		Body_LeftHandRingMetacarpal = 34,
		Body_LeftHandRingProximal = 35,
		Body_LeftHandRingIntermediate = 36,
		Body_LeftHandRingDistal = 37,
		Body_LeftHandRingTip = 38,
		Body_LeftHandLittleMetacarpal = 39,
		Body_LeftHandLittleProximal = 40,
		Body_LeftHandLittleIntermediate = 41,
		Body_LeftHandLittleDistal = 42,
		Body_LeftHandLittleTip = 43,
		Body_RightHandPalm = 44,
		Body_RightHandWrist = 45,
		Body_RightHandThumbMetacarpal = 46,
		Body_RightHandThumbProximal = 47,
		Body_RightHandThumbDistal = 48,
		Body_RightHandThumbTip = 49,
		Body_RightHandIndexMetacarpal = 50,
		Body_RightHandIndexProximal = 51,
		Body_RightHandIndexIntermediate = 52,
		Body_RightHandIndexDistal = 53,
		Body_RightHandIndexTip = 54,
		Body_RightHandMiddleMetacarpal = 55,
		Body_RightHandMiddleProximal = 56,
		Body_RightHandMiddleIntermediate = 57,
		Body_RightHandMiddleDistal = 58,
		Body_RightHandMiddleTip = 59,
		Body_RightHandRingMetacarpal = 60,
		Body_RightHandRingProximal = 61,
		Body_RightHandRingIntermediate = 62,
		Body_RightHandRingDistal = 63,
		Body_RightHandRingTip = 64,
		Body_RightHandLittleMetacarpal = 65,
		Body_RightHandLittleProximal = 66,
		Body_RightHandLittleIntermediate = 67,
		Body_RightHandLittleDistal = 68,
		Body_RightHandLittleTip = 69,
		Body_End = 70,
		NoOverride = 71,
		Remove = 72
	};
}
