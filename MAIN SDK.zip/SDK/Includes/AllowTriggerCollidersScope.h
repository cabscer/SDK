#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct AllowTriggerCollidersScope
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "AllowTriggerCollidersScope", BNM::Image("Unity.XR.Interaction.Toolkit.dll"));
		}
		
		bool m_Disposed;
		bool m_OldValue;
		
		
	};
}
