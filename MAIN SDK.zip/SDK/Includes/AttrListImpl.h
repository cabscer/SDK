#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class AttrListImpl : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "AttrListImpl", BNM::Image("mscorlib.dll"));
		}
		
		/* @brief Orig Type: System.Collections.Generic.List`1<System.String> */
		template <typename T = void* /*GENERICTYPE*/> T attrNames() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("attrNames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<System.String> */
		void set_attrNames(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("attrNames");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.Generic.List`1<System.String> */
		template <typename T = void* /*GENERICTYPE*/> T attrValues() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("attrValues");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.Generic.List`1<System.String> */
		void set_attrValues(void* /*GENERICTYPE*/ value) {
			static BNM::Field<void* /*GENERICTYPE*/> __bnm__field__ = StaticClass().GetField("attrValues");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T get_Length() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Length", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T GetName(int i) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetName", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](i);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T GetValue(int i) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetValue", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](i);
		}
		/* @brief Orig Type: System.String */
		template <typename T = BNM::Structures::Mono::String*> T GetValue_1(BNM::Structures::Mono::String* name) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("GetValue", 1);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](name);
		}
		/* @brief Orig Type: System.String[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T get_Names() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Names", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.String[] */
		template <typename T = BNM::Structures::Mono::Array<BNM::IL2CPP::Il2CppObject*>*> T get_Values() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("get_Values", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Clear() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Clear", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T Add(BNM::Structures::Mono::String* name, BNM::Structures::Mono::String* $value) {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("Add", 2);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this](name, $value);
		}
		
	};
}
