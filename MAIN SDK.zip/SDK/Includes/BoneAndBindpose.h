#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct BoneAndBindpose
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "BoneAndBindpose", BNM::Image("MeshBakerCore.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* bone;
		BNM::IL2CPP::Il2CppObject* bindPose;
		
		
	};
}
