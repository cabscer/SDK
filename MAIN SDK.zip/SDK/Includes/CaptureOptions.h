#pragma once
#include <BNMIncludes.hpp>

#undef None
#undef IgnoreSyncCtx
#undef OptimizeDefaultCase
namespace GlobalNamespace {
	enum class CaptureOptions : int
	{
		None = 0,
		IgnoreSyncCtx = 1,
		OptimizeDefaultCase = 2
	};
}
