#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	struct bucket
	{
		static BNM::Class StaticClass() {
			return BNM::Class("", "bucket", BNM::Image("mscorlib.dll"));
		}
		
		BNM::IL2CPP::Il2CppObject* key;
		BNM::IL2CPP::Il2CppObject* val;
		int hash_coll;
		
		
	};
}
