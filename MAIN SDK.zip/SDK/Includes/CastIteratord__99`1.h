#pragma once
#include <BNMIncludes.hpp>

namespace GlobalNamespace {
	class $CastIterator$d__99$1 : public BNM::IL2CPP::Il2CppObject
	{
		public:
		static BNM::Class StaticClass() {
			return BNM::Class("", "<CastIterator>d__99`1", BNM::Image("System.Core.dll"));
		}
		
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T $$1__state() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$1__state");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_$$1__state(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$$1__state");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: TResult */
		template <typename T = void*> T $$2__current() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$2__current");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: TResult */
		void set_$$2__current(void* value) {
			static BNM::Field<void*> __bnm__field__ = StaticClass().GetField("$$2__current");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Int32 */
		template <typename T = int> T $$l__initialThreadId() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$l__initialThreadId");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Int32 */
		void set_$$l__initialThreadId(int value) {
			static BNM::Field<int> __bnm__field__ = StaticClass().GetField("$$l__initialThreadId");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.IEnumerable */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T source() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("source");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.IEnumerable */
		void set_source(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("source");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.IEnumerable */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $$3__source() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$3__source");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.IEnumerable */
		void set_$$3__source(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$$3__source");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		/* @brief Orig Type: System.Collections.IEnumerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T $$7__wrap1() {
			static BNM::Field<T> __bnm__field__ = StaticClass().GetField("$$7__wrap1");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			return __bnm__field__();
		}
		/* @param value Orig Type: System.Collections.IEnumerator */
		void set_$$7__wrap1(BNM::IL2CPP::Il2CppObject* value) {
			static BNM::Field<BNM::IL2CPP::Il2CppObject*> __bnm__field__ = StaticClass().GetField("$$7__wrap1");
			__bnm__field__.SetInstance((BNM::IL2CPP::Il2CppObject*)this);
			__bnm__field__.Set(value);
		}
		
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_IDisposable_Dispose() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.IDisposable.Dispose", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Boolean */
		template <typename T = bool> T MoveNext() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("MoveNext", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T m__Finally1() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("<>m__Finally1", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: TResult */
		template <typename T = void*> T System_Collections_Generic_IEnumeratorTResult_get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.Generic.IEnumerator<TResult>.get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Void */
		template <typename T = void> T System_Collections_IEnumerator_Reset() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.IEnumerator.Reset", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Object */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T System_Collections_IEnumerator_get_Current() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.IEnumerator.get_Current", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Collections.Generic.IEnumerator`1<TResult> */
		template <typename T = void* /*GENERICTYPE*/> T System_Collections_Generic_IEnumerableTResult_GetEnumerator() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.Generic.IEnumerable<TResult>.GetEnumerator", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		/* @brief Orig Type: System.Collections.IEnumerator */
		template <typename T = BNM::IL2CPP::Il2CppObject*> T System_Collections_IEnumerable_GetEnumerator() {
			static BNM::Method<T> __bnm__method__ = StaticClass().GetMethod("System.Collections.IEnumerable.GetEnumerator", 0);
			return __bnm__method__[(BNM::IL2CPP::Il2CppObject*)this]();
		}
		
	};
}
