#pragma once
#include <BNMIncludes.hpp>

#undef AND
#undef OR
#undef XOR
namespace GlobalNamespace {
	enum class ActiveStateGroupLogicOperator : int
	{
		AND = 0,
		OR = 1,
		XOR = 2
	};
}
